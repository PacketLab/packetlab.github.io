// test_pktif_dns.c
// PacketLab UDP Experiment Controller Example Program
// Use pktlab measurement endpoint to issue DNS request
//

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>

#include <arpa/inet.h>
#include <assert.h>
#include <netinet/ip.h>
#include <pktif.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

#include <netdb.h>
#include <regex.h>
#include <signal.h>

#define ADDRSTRLEN 64
#define BUFSZ 0x10000

static void UDP_experiment(char *domain, char *ip);

static void print_dns_response (
	const void * buf, unsigned long len, uint_fast16_t ID,
	const char * epaddrstr, pktlab_time_t resptime);

static void putchars(const char * ptr, size_t len);
static int putname(const char * buf, unsigned int off, unsigned int len, bool first);
static void putip4addr(const void * ptr);
static void putip4addr(const void * ptr);
static void putip6addr(const void * ptr);

static ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID,
                                uint8_t RD, char *domain, size_t domainlen);
static bool is_good_fd(int fd);

static char * getepaddrstr(void);
static char * extractipaddr(char * str);

static void exithandler(void);

static void install_sighandler(void);
static void sighandler(int sig);

static struct pktif * pktif = NULL;
static char servaddrstr[INET6_ADDRSTRLEN];

int main(int argc, char *argv[]) {
    int econnfd;
    struct sockaddr_in sa;
    char domain[BUFSZ] = {};
    char sample_domain[] = "www.example.com";
    char sample_ip[] = "8.8.8.8";

    install_sighandler();

    if (argc == 3 && inet_pton(AF_INET, argv[2], &(sa.sin_addr.s_addr)) == 1) {
        strncpy(servaddrstr, argv[2], sizeof(servaddrstr));
        servaddrstr[sizeof(servaddrstr)-1] = '\0';
    } else {
        strncpy(servaddrstr, sample_ip, sizeof(servaddrstr));
        servaddrstr[sizeof(servaddrstr)-1] = '\0';
    }

    if (argc >= 2) {
        strncpy(domain, argv[1], sizeof(domain) - 1);
    } else {
        strncpy(domain, sample_domain, sizeof(domain) - 1);
    }

    if (getenv("EPADDR") == NULL) {
        fprintf(stderr, "EPADDR not set " \
            "(are you running this mlet using pktxpmgr?)\n");
        exit(EXIT_FAILURE);
    }

    fprintf(stderr,
            "> PacketLab Measurement Applet: DNS query example (with pktif)"
            " (querying '%s' for domain '%s') using pktxpmgr\n",
			servaddrstr, domain);

    econnfd = 0;
    assert(is_good_fd(econnfd));

    pktif = pktif_init(econnfd, NULL);
    atexit(&exithandler);

    alarm(5);
    UDP_experiment(domain, servaddrstr);

    pktif_teardown(pktif);
    pktif = NULL;

    fprintf(stderr, "> Terminating\n");

    return 0;
}

bool is_good_fd(int fd) { return (fcntl(fd, F_GETFD) >= 0); }

void UDP_experiment(char *domain, char *ip) {
    const char * epaddrstr;
	pktlab_time_t me_recv_time;
    uint8_t sktid = 1;
    uint8_t proto = PKTLAB_UDP_PROTO;
    uint32_t rbufsize = 0x1000;
    int rv;
    struct sockaddr_in laddr = {.sin_family = AF_INET};
    // inet_pton(AF_INET, "192.168.137.108", &laddr.sin_addr.s_addr);
    laddr.sin_addr.s_addr = INADDR_ANY;
    laddr.sin_port = 0;

    uint8_t buf[BUFSZ];
    rv = pktif_connect_sync(pktif, sktid, proto, (struct sockaddr *)&laddr,
                            NULL, rbufsize, NULL);
    assert(rv == 0);

    //
    // Create and send nsend msg
    // Receive status
    //

    fprintf(stderr, "> Sending nsend msg\n");

    uint16_t tag = 15;
    pktlab_time_t time = 0;
    pktlab_time_t ec_nsend_time;
    pktlab_time_t me_send_time;
    pktlab_time_t ec_npoll_time;
    uint8_t payload[BUFSZ];
    ssize_t payloadlen;
    uint16_t ID = 5566;
    uint8_t RD = 1;
    struct sockaddr_in raddr = {.sin_family = AF_INET};
    inet_pton(AF_INET, ip, &raddr.sin_addr.s_addr);
    raddr.sin_port = htons(53);

    payloadlen =
        create_dns_query(payload, BUFSZ, ID, RD, domain, strlen(domain));
    ec_nsend_time = pktlab_time_now();
    rv = pktif_send_sync(pktif, sktid, payload, payloadlen, proto, time, tag,
                         (struct sockaddr *)&raddr, &me_send_time);
    assert(rv == payloadlen);

    //
    // Create and send npoll msg
    // Receive ndata and nstat
    //

    fprintf(stderr, "> Receiving msg\n");
    size_t len =
        pktif_recv_sync(pktif, sktid, buf, sizeof(buf), NULL, &me_recv_time);
    ec_npoll_time = pktlab_time_now();
    //
    // Create and send nclose msg
    // Receive status
    //

    fprintf(stderr, "> Sending nclose msg\n");
    rv = pktif_close_sync(pktif, sktid);
    assert(rv == 0);

    fprintf(stderr, "\n---->Results<----\n");
    fprintf(stderr, "Received data length: %lu\n", len);
    fprintf(stderr, "ME send time: %lu\n", me_send_time);
    fprintf(stderr, "Spent time at ME: %.3f ms\n",
            (float)(me_recv_time - me_send_time) / 1000000);
    fprintf(stderr, "Spent time at EC: %.3f ms\n",
            (float)(ec_npoll_time - ec_nsend_time) / 1000000);
    fprintf(stderr, "\n-->Content<--\n");

    size_t i;
    for (i = 0; i < len; ++i) {
        fprintf(stderr, "%02x ", buf[i]);
        if (i % 8 == 7)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");

    epaddrstr = getepaddrstr();
    if (epaddrstr == NULL)
    	epaddrstr = getenv("EPADDR");
    if (epaddrstr == NULL)
    	epaddrstr = "unknown";

    print_dns_response(buf, len, ID, epaddrstr, me_recv_time - me_send_time);
    return;
}

void print_dns_response (
	const void * buf, unsigned long len, uint_fast16_t ID,
	const char * epaddrstr, pktlab_time_t resptime)
{
    uint16_t id_local = ID; // first word expected value (no byte order change)
    uint_fast16_t status; // second word, host (native( byte order
    uint_fast16_t qdcount; // third word, number of answers, host byte order
    uint_fast16_t ancount; // fourth word, number of answers, host byte order
    uint_fast8_t lenbyte;
    unsigned int off;
    int line = 0;
    int skip;

    uint_fast16_t type;
    uint_fast16_t cls;
    uint_fast32_t ttl;
    uint_fast16_t rdlen;

    (void)ttl;

    if (len < 6*2) {
        fprintf(stderr, "DNS packet too short (%lu bytes)\n", len);
        return;
    }

    if (memcmp(&id_local, buf, 2) != 0) {
        fprintf(stderr, "DNS packet ID mismatch\n");
        return;
    }

    status = pktlab_get16n(buf+2);

    if ((status >> 15) == 0) {
        fprintf(stderr, "DNS packet not a response\n");
        return;
    }

    qdcount = pktlab_get16n(buf+4);
    ancount = pktlab_get16n(buf+6);

    if ((status & 0xF) != 0) {
        if ((status & 0xF) == 3 && qdcount > 0 && len > 6*2) {
            putname(buf, 6*2, len, true);
            printf(" does not exist (%u ms from %s via %s)\n",
            	(unsigned int)(resptime / (PKTLAB_TICKS_PER_SECOND / 1000)),
				servaddrstr, epaddrstr);
        } else
            fprintf(stderr, "RCODE == %u != 0\n", (unsigned int)status & 0xF);
        return;
    }

    if (ancount == 0) {
        fprintf(stderr, "ANCOUNT == 0\n");
        return;
    }

    // Skip query data

    off = 6*2;
    while (qdcount > 0) {
        for (;;) {
            if (len <= off) {
                line = __LINE__;
                goto malformed;
            }

            lenbyte = pktlab_get8(buf+off); off += 1;

            if (lenbyte == 0)
                break;

            if ((lenbyte >> 6) == 3) {
                off += 1;
                break;
            }

            off += lenbyte;
        }

        // Skip QTYPE and QCLASS words

        off += 2*2;
        qdcount -= 1;
    }

    // Print response

    while (ancount > 0) {
        skip = putname(buf, off, len, true);

        if (skip < 0) {
            line = -skip;
            goto malformed;
        }

        off += skip;
        fputs(" is ", stdout);

        if (len < off + 5*2) {
            line = __LINE__;
            goto malformed;
        }

        type = pktlab_get16n(buf+off); off += 2;
        cls = pktlab_get16n(buf+off); off += 2;
        ttl = pktlab_get32n(buf+off); off += 4;
        rdlen = pktlab_get16n(buf+off); off += 2;

        if (len < off+rdlen) {
            line = __LINE__;
            goto malformed;
        }

        if (cls == 1) {
            switch (type) {
            case 1: // A record
                if (rdlen != 4) {
                    line = __LINE__;
                    goto malformed;
                } else
                    putip4addr(buf+off);
                break;
            case 28: // AAAA record
                if (rdlen != 16) {
                    line = __LINE__;
                    goto malformed;
                } else
                    putip6addr(buf+off);
                break;
            case 5: // CNAME record
                skip = putname(buf, off, len, true);
                if (skip < 0) {
                    line = -skip;
                    goto malformed;
                } else if (skip != rdlen) {
                    line = __LINE__;
                    goto malformed;
                }
                break;
            default:
                break;
            }
        }

        printf(" (%u ms from %s via %s)\n",
        	(unsigned int)(resptime / (PKTLAB_TICKS_PER_SECOND / 1000)),
			servaddrstr, epaddrstr);
        off += rdlen;
        ancount -= 1;
    }

    return;

malformed:
    fprintf(stderr, "Malformed DNS packet (%s:%d)\n", __FILE__, line);
    return;
}

void putchars(const char * str, size_t len) {
    fwrite(str, len, 1, stdout);
}

int putname(const char * buf, unsigned int off, unsigned int len, bool first) {
    unsigned int off0 = off; // initial offset; we return off - off0
    uint_fast8_t lenbyte;
    uint_fast8_t tmpoff;
    int skip;

    for (;;) {
        if (len <= off)
            return -__LINE__;

        lenbyte = pktlab_get8(buf+off);
        off += 1;

        if (lenbyte == 0)
            break;

        if ((lenbyte >> 6) == 3) {
            if (off == len)
                return -__LINE__;

            tmpoff = (uint_fast16_t)(lenbyte & 0x3F) << 8;
            tmpoff |= pktlab_get8(buf+off);
            off += 1;

            if (len <= tmpoff)
                return -__LINE__;

            skip = putname(buf, tmpoff, len, first);
            if (skip < 0)
                return skip;
            break;
        }

        if (!first)
            putchar('.');
        else
            first = false;

        putchars(buf+off, lenbyte);
        off += lenbyte;
    }

    return off - off0;
}

void putip4addr(const void * ptr) {
    char strbuf[INET_ADDRSTRLEN];
    const char * addrstr;

    addrstr = inet_ntop(AF_INET, ptr, strbuf, sizeof(strbuf));

    if (addrstr != NULL)
        fputs(addrstr, stdout);
    else
        puts("ERROR");
}

void putip6addr(const void * ptr) {
    char strbuf[INET6_ADDRSTRLEN];
    const char * addrstr;

    addrstr = inet_ntop(AF_INET6, ptr, strbuf, sizeof(strbuf));

    if (addrstr != NULL)
        fputs(addrstr, stdout);
    else
        puts("ERROR");
}

ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t RD,
                         char *domain, size_t domainlen) {
    /*
     * Refer to RFC 1035 for more information on the fields of DNS msgs
     *
     *                                 1  1  1  1  1  1
     *   0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                      ID                       |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    QDCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ANCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    NSCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ARCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    //
    // Create DNS query header
    //

    if (buflen < 12 + domainlen + 2 + 4)
        return -1;

    uint16_t tmp;

    memcpy(buf, &ID, sizeof(ID));

    tmp = htons(0 | ((uint16_t)RD) << 8);
    memcpy(buf + 2, &tmp, sizeof(tmp));

    // printf("%u %u", *(buf + 2), *(buf + 3));

    tmp = htons(1);
    memcpy(buf + 4, &tmp, sizeof(tmp));

    tmp = 0;
    memcpy(buf + 6, &tmp, sizeof(tmp));
    memcpy(buf + 8, &tmp, sizeof(tmp));
    memcpy(buf + 10, &tmp, sizeof(tmp));

    //
    // Create query content
    //

    char *ptr;
    size_t off = 12;
    size_t toklen;
    for (ptr = strtok(domain, "."); ptr != NULL; ptr = strtok(NULL, ".")) {
        toklen = strlen(ptr);

        *(buf + off) = toklen;
        memcpy(buf + off + 1, ptr, toklen);
        off += toklen + 1;
    }

    *(buf + off) = '\0';

    tmp = htons(1);
    memcpy(buf + off + 1, &tmp, sizeof(tmp));
    memcpy(buf + off + 3, &tmp, sizeof(tmp));

    return off + 5;
}

#define IPADDRSERVICE "api.ipify.org"
#define IPRESPBUFSZ 10*1024

char * getepaddrstr(void) {
	static const char * const ipreqstr =
	"GET / HTTP/1.1\r\n"
	"Host: " IPADDRSERVICE "\r\n"
	"Connection: close\r\n"
	"\r\n";

	char * iprespbuf = NULL;
	char * epaddrstr = NULL;

	struct addrinfo hints;
	struct addrinfo * aihead;
	struct addrinfo * ainode;
	struct sockaddr_in lsa;
	size_t ipreqstrlen;
	pktlab_time_t senttime;
	pktlab_time_t rcvdtime;
	struct in_addr epaddr;
	ssize_t resultlen;

	int result;

	// Lookup address using whatismyip-type service. Note: the DNS lookup will
	// come from the controller, not the endpoint, but that's okay here.

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_flags = AI_NUMERICSERV;

	result = getaddrinfo(IPADDRSERVICE, "80", &hints, &aihead);

	if (result != 0) {
		fprintf(stderr, "%s: %s\n", IPADDRSERVICE, gai_strerror(result));
		exit(EXIT_FAILURE);
	}

	// Initialize local socket address and payload length

	memset(&lsa, 0, sizeof(lsa));
	lsa.sin_family = AF_INET;
	lsa.sin_addr.s_addr = INADDR_ANY;
	lsa.sin_port = 0;

	ipreqstrlen = strlen(ipreqstr);
	iprespbuf = malloc(IPRESPBUFSZ);

	if (iprespbuf == NULL) {
		perror("malloc()");
		exit(EXIT_FAILURE);
	}

	// Try each address in turn. If connect fails, we try another address.

	for (ainode = aihead; ainode != NULL; ainode = ainode->ai_next) {
		result = pktif_connect_sync (
			pktif, /* sktid */ 2, PKTLAB_TCP_PROTO,
			(struct sockaddr*) &lsa, (struct sockaddr*) ainode->ai_addr,
			/* rbufsz */ 1*1024*1024, /* recv_cb */ NULL);

		if (result != 0) {
			fprintf(stderr, "pktif_connect_sync() returned %d\n", result);
			continue;
		}

		resultlen = pktif_send_sync(pktif, /* sktid */ 2,
			(void*)ipreqstr, ipreqstrlen, PKTLAB_TCP_PROTO,
			/* send_time*/ 0, /* tag */ 1,
			/* rudpaddr */ NULL, &senttime);

		if (resultlen != ipreqstrlen) {
			fprintf(stderr, "pktif_send_sync() returned %ld\n", (long)resultlen);
			exit(EXIT_FAILURE);
		}

		resultlen = pktif_recv_sync(pktif, /* sktid */ 2,
			iprespbuf, IPRESPBUFSZ, /* raddr */ NULL, &rcvdtime);

		if (resultlen < 0) {
			fprintf(stderr, "pktif_recv_sync() returned %ld\n", (long)resultlen);
			exit(EXIT_FAILURE);
		}

		if (resultlen == 0) {
			fprintf(stderr,	"Empty (EOF) response from %s\n", IPADDRSERVICE);

			result = pktif_close_sync(pktif, /* sktid */ 2);

			if (result != 0) {
				fprintf(stderr, "pktif_close_sync() returned %d\n", result);
				exit(EXIT_FAILURE);
			}

			continue;
		}

		// Make response a null-terminated string

		if (resultlen < IPRESPBUFSZ)
			iprespbuf[resultlen] = '\0';
		else
			iprespbuf[IPRESPBUFSZ-1] = '\0';

		epaddrstr = extractipaddr(iprespbuf);

		if (epaddrstr != NULL) {
			result = inet_pton(AF_INET, epaddrstr, &epaddr);

			if (result != 1) {
				perror(epaddrstr);
				epaddrstr = NULL;
			}
		}

		result = pktif_close_sync(pktif, /* sktid */ 2);

		if (result != 0) {
			fprintf(stderr, "pktif_close_sync() returned %d\n", result);
			exit(EXIT_FAILURE);
		}

		if (epaddrstr != NULL) {
			epaddrstr = strdup(epaddrstr);
			if (epaddrstr == NULL) {
				perror("strdup()");
				exit(EXIT_FAILURE);
			}

			break;
		}
	}

	freeaddrinfo(aihead);
	free(iprespbuf);

	return epaddrstr;
}

// Find an IP address substring in string. Modifies str to null-terminate the
// IP address substring and returns a pointer to start of IP address. Returns
// NULL on error.

char * extractipaddr(char * str) {
	char errbuf[80];
	char * start;
	regmatch_t match;
	regex_t re;
	int result;

	result = regcomp(&re, "([0-9]{1,3}\\.){3}[0-9]{1,3}", REG_EXTENDED);

	if (result != 0) {
		regerror(result, &re, errbuf, sizeof(errbuf));
		fprintf(stderr, "regcomp(): %s", errbuf);
		exit(EXIT_FAILURE);
	}

	// Skip HTTP header

	start = strstr(str, "\r\n\r\n");
	if (start != NULL)
		start += 4;
	else
		start = str;

	result = regexec(&re, start, /* nmatch */ 1, &match, /* eflags */ 0);

	if (result != 0) {
		if (result != REG_NOMATCH) {
			regerror(result, &re, errbuf, sizeof(errbuf));
			fprintf(stderr, "regexec(): %s\n", errbuf);
			exit(EXIT_FAILURE);
		} else
			return NULL;
	}

	start[match.rm_eo] = '\0';
	return start + match.rm_so;
}

void exithandler(void) {
	fputs("test_pktif_dns exit handler called\n", stderr);
	if (pktif != NULL) {
		pktif_teardown(pktif);
		pktif = NULL;
	}
}

#define perror_exit_if(cond,msg) do { if (cond) { perror(msg); exit(EXIT_FAILURE); } } while (0)

void install_sighandler(void) {
    struct sigaction sa;
    int result;

    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = &sighandler;
    sa.sa_flags = SA_RESETHAND;

    result = sigemptyset(&sa.sa_mask);
    perror_exit_if(result != 0, __func__);

    result = sigaddset(&sa.sa_mask, SIGTERM);
    perror_exit_if(result != 0, __func__);

    result = sigaddset(&sa.sa_mask, SIGINT);
    perror_exit_if(result != 0, __func__);

    result = sigaddset(&sa.sa_mask, SIGHUP);
    perror_exit_if(result != 0, __func__);

    result = sigaddset(&sa.sa_mask, SIGQUIT);
    perror_exit_if(result != 0, __func__);

    result = sigaddset(&sa.sa_mask, SIGALRM);
    perror_exit_if(result != 0, __func__);

    result = sigaction(SIGTERM, &sa, NULL);
    perror_exit_if(result != 0, __func__);

    result = sigaction(SIGINT, &sa, NULL);
    perror_exit_if(result != 0, __func__);

    result = sigaction(SIGHUP, &sa, NULL);
    perror_exit_if(result != 0, __func__);

    result = sigaction(SIGQUIT, &sa, NULL);
    perror_exit_if(result != 0, __func__);

    result = sigaction(SIGALRM, &sa, NULL);
    perror_exit_if(result != 0, __func__);
}

void sighandler(int sig) {
    exit(EXIT_SUCCESS);
}


