// test_single_mlet.c
// Test by using single mlet mode to run multi-mlets
//

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <fcntl.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>

//
// CONSTANTS
//

#define EPADDR_ENV_STR "EPADDR="

//
// CHECK CMSG MACRO
//

// Check if required macros are defined and set flag
// Note only the ones not in POSIX.1-2004 are checked
#if defined(CMSG_SPACE) && defined(CMSG_LEN)
#define CMSG_MACRO_SUPPORT 1
#else
#define CMSG_MACRO_SUPPORT 0

// placeholder to suppress compilation warning,
// should never be called, i.e. a bug if called
#include <stddef.h> // size_t
static inline size_t dummy_cmsg_macro(size_t i) { assert(0); };

#undef CMSG_SPACE(i)
#define CMSG_SPACE(i) dummy_cmsg_macro(i)
#undef CMSG_LEN(i)
#define CMSG_LEN(i) dummy_cmsg_macro(i)

#endif

//
// STATIC FUNCTION DECLARATIONS
//

static void check_cmsg_macro_support(void);
static int get_new_mlet_fd(int * err, char * addrstr);
static void spawn_mlet (
    char ** mlet_path_n_args, int mlet_fd, char * addrstr);

//
// MAIN FUNCTION
//

int main(int argc, char * argv[]) {
    int new_mlet_fd, err;
    char addrstr[INET6_ADDRSTRLEN];

    if (argc <= 1) {
        fputs("At least 1 argument must be provided\n", stderr);
        exit(EXIT_FAILURE);
    }

    while (1) {
        new_mlet_fd = get_new_mlet_fd(&err, addrstr);
        if (new_mlet_fd == -2) {
            fputs("Detected xpmgr EOF\n", stderr);
            break;
        } else if (new_mlet_fd < 0) {
            fprintf(stderr, "Failed to receive new fd (%d)\n", new_mlet_fd);
            if (new_mlet_fd == -1)
                fprintf(stderr, "Failed with %s\n", strerror(err));

            exit(EXIT_FAILURE);
        } else if (new_mlet_fd <= 2) {
            fprintf(stderr, "Got invalid new fd: %d\n", new_mlet_fd);
            exit(EXIT_FAILURE);
        }

        fprintf(stderr, "Got new fd %d, spawning mlet\n", new_mlet_fd);
        spawn_mlet(argv+1, new_mlet_fd, addrstr);
    }

    return 0;
}

//
// STATIC FUNCTION DEFINITIONS
//

void check_cmsg_macro_support(void) {
    if (CMSG_MACRO_SUPPORT)
        return;

    fputs(
        "test_single_mlet failed to run"
        " due to platform not supporting required cmsg macros\n",
        stderr);
    exit(EXIT_FAILURE);
}

int get_new_mlet_fd(int * err, char * addrstr) {
    int ret, got_fd;
    struct msghdr fd_msg = {};
    struct cmsghdr * cmsg;
    struct iovec iov;
    ssize_t rst;
    size_t recvlen;
    uint8_t cmsgbuf[CMSG_SPACE(sizeof(ret))];

    assert(err != NULL && addrstr != NULL);

    check_cmsg_macro_support();

    got_fd = recvlen = 0;

    while (1) {
        iov.iov_base = addrstr+recvlen;
        iov.iov_len = INET6_ADDRSTRLEN-recvlen;

        fd_msg.msg_iov = &iov;
        fd_msg.msg_iovlen = 1;
        fd_msg.msg_control = cmsgbuf;
        fd_msg.msg_controllen = sizeof(cmsgbuf);

        rst = recvmsg(0, &fd_msg, 0);
        if (rst < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
                continue;

            *err = errno;
            return -1;
        } else if (rst == 0)
            return -2; // EOF

        cmsg = CMSG_FIRSTHDR(&fd_msg);
        if (cmsg != NULL &&
            cmsg->cmsg_level == SOL_SOCKET &&
            cmsg->cmsg_type == SCM_RIGHTS &&
            cmsg->cmsg_len == CMSG_LEN(sizeof(ret))) {
            assert(!got_fd); // multiple valid fd for a single addrstr

            // deal with valid cmsg if there is any
            memcpy(&ret, CMSG_DATA(cmsg), sizeof(ret));
            got_fd = 1;
        }

        assert(rst + recvlen <= INET6_ADDRSTRLEN);

        recvlen += rst;

        if (addrstr[recvlen-1] == '\0') {
            if (got_fd)
                return ret;
            return -3; // got no fd for addrstr
        } else if (recvlen >= INET6_ADDRSTRLEN)
            return -4; // xpmgr passed non-addrstr
    }

}

void spawn_mlet(char ** mlet_path_n_args, int mlet_fd, char * addrstr) {
    char epaddr_str[sizeof(EPADDR_ENV_STR)+INET6_ADDRSTRLEN] = {};
    char * mlet_path;
    char ** mlet_envp;
    char * ptr;
    pid_t mlet_pid;

    assert(mlet_path_n_args != NULL && mlet_fd >= 0 && addrstr != NULL);

    mlet_pid = fork();
    if (mlet_pid == 0) { // child
        mlet_envp = calloc(2, sizeof(*mlet_envp));
        if (mlet_envp == NULL) {
            fprintf(stderr, "calloc failed (%s)\n", strerror(errno));
            exit(EXIT_FAILURE);
        }

        if (strlen(addrstr) > 0) {
            if (snprintf(
                    epaddr_str, sizeof(epaddr_str),
                    "%s%s", EPADDR_ENV_STR, addrstr) < 0) {
                fprintf(stderr, "snprintf failed (%s)\n", strerror(errno));
                exit(EXIT_FAILURE);
            }

            mlet_envp[0] = epaddr_str;
        }

        if (dup2(mlet_fd, 0) < 0) {
            fprintf(stderr, "Failed to move fd to 0 (%s)\n", strerror(errno));
            exit(EXIT_FAILURE);
        }

        close(mlet_fd);

        // modification to mlet_path_n_args here is fine as it is a new copy
        mlet_path = mlet_path_n_args[0];
        ptr = strrchr(mlet_path_n_args[0], '/');
        if (ptr != NULL)
            mlet_path_n_args[0] = ptr+1; // remove string prior to '/'

        // note it is possible for new mlet_path_n_args[0] to be 0 len
        // bad bin though, will fail next step
        if (execve(mlet_path, mlet_path_n_args, mlet_envp) < 0) {
            fprintf(stderr, "Failed to run %s (%s)\n", mlet_path, strerror(errno));
            exit(EXIT_FAILURE);
        }

        // note we do not do any cleanup for child
    } else if (mlet_pid < 0)
        fprintf(stderr, "Failed to fork (%s)\n", strerror(errno));

    close(mlet_fd);
    return;
}