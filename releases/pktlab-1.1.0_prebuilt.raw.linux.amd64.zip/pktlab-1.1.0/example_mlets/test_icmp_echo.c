// test_icmp_echo.c
// PacketLab ICMP Echo Experiment Controller Example Program
// Use pktlab measurement endpoint to send ICMP echo request
// Should be used with pktxpmgr
//

#include <assert.h>
#include <errno.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>

#include "pktlab.h"
#include "pktctrl.h"

//
// INTERNAL MACROS
//

#define BUFSZ 0x10000
#define CBPF_INSTR_SZ 8
#define IPHDR_LEN 20
#define ICMPHDR_LEN 8
#define IP4_ADDRLEN PKTLAB_IPV4_WO_MSK_ADDR_LEN
#define ICMP_PROTO 1

#define ID_BYTE1 0x15
#define ID_BYTE2 0xbe
#define ID_WHOLE ID_BYTE1 * 256 + ID_BYTE2

#define EBPF_ICMP_ECHO_REPLY_FILTER(b0) \
    { \
        {0xbf, 0x6, 0x1, 0x0,        0x0}, \
        {0xb7, 0x7, 0x0, 0x0,        0x0}, \
        {0x30, 0x0, 0x0, 0x0,        0x0}, \
        {0x57, 0x0, 0x0, 0x0, 0xfffffff0}, \
        {0x55, 0x0, 0x0, 0x8,       0x40}, \
        {0x30, 0x0, 0x0, 0x0,        0x9}, \
        {0x55, 0x0, 0x0, 0x6,        0x1}, \
        {0x28, 0x0, 0x0, 0x0,       0x14}, \
        {0x55, 0x0, 0x0, 0x4,        0x0}, \
        {0x28, 0x0, 0x0, 0x0,       0x18}, \
        {0xb7, 0x7, 0x0, 0x0,     0xffff}, \
        {0x15, 0x0, 0x0, 0x1,         b0}, \
        {0xb7, 0x7, 0x0, 0x0,        0x0}, \
        {0xbf, 0x0, 0x7, 0x0,        0x0}, \
        {0x95, 0x0, 0x0, 0x0,        0x0} \
    }

//
// TYPE DEFINITIONS
//

struct iphdr {
    uint8_t ihl : 4;
    uint8_t ver : 4;
    uint8_t tos;
    uint16_t len;
    uint16_t id;
    uint16_t frag;
    uint8_t ttl;
    uint8_t proto;
    uint16_t cksum;
    uint32_t src;
    uint32_t dst;
};

struct icmphdr {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint16_t id;
    uint16_t sequence;
};

//
// FUNCTION DECLARATIONS
//

static bool is_good_fd(int fd);
static int create_nopen(struct pktlab_message *msg, uint8_t *laddrptr,
                        uint8_t *lportptr, uint8_t *raddrptr, uint8_t *rportptr,
                        uint8_t sktid, uint8_t family, uint8_t proto,
                        uint32_t rbufsize, const char *localip,
                        uint16_t localport, const char *ip,
                        uint16_t remoteport);
static int create_ncap(struct pktlab_message *msg, uint8_t sktid,
                       uint8_t family, uint8_t proto, pktlab_time_t endtime,
                       const void *filter, uint32_t filterlen);
static int create_nsend(struct pktlab_message *msg, uint8_t sktid,
                        uint8_t family, uint8_t proto, uint16_t tag,
                        pktlab_time_t time, uint32_t len, const void *ptr);
static int create_nclose(struct pktlab_message *msg, uint8_t sktid);
static int try_send(struct pktctrl_obj *obj, const struct pktlab_message *msg);
static void send_n_print_err(struct pktctrl_obj *obj,
                             const struct pktlab_message *send_msg);
static void recv_msg_until_type(int type, struct pktctrl_obj *obj,
                                struct pktlab_message **recv_msg);
static ssize_t create_ip4_pkt(uint8_t *buf, size_t buflen, uint16_t ID,
                              uint8_t ttl, uint8_t proto, uint16_t payloadlen,
                              const void *src, const void *dst);
static ssize_t create_icmp_echo(uint8_t *buf, size_t buflen, uint16_t ID,
                                uint16_t seq);
static uint16_t comp_cksum(const uint8_t *buf, size_t len);
static void ICMP_experiment(struct pktctrl_obj *obj, char *domain);
static void perror_exit(const char *str, int exit_val);
static void print_err_exit(int exit_val, const char *fmt, ...);

//
// FUNCTION DEFINITIONS
//

int main(int argc, char *argv[]) {
    int rst, econnfd;
    struct pktctrl_obj *endpoint_obj;
    char domain[BUFSZ] = {};
    char sample_domain[] = "www.example.com";

    if (argc >= 2) {
        strncpy(domain, argv[1], sizeof(domain)-1);
    } else {
        strncpy(domain, sample_domain, sizeof(domain)-1);
    }

    if (getenv("EPADDR") == NULL) {
        fprintf(stderr, "EPADDR not set " \
            "(are you running this mlet using pktxpmgr?)\n");
        exit(EXIT_FAILURE);
    }

    fprintf(
        stderr,
        "> PacketLab Measurement Applet: ICMP echo example %s using pktxpmgr\n",
        domain);

    econnfd = 0;
    assert(is_good_fd(econnfd));

    endpoint_obj = pktctrl_create_obj();
    assert(endpoint_obj != NULL);

    rst = pktctrl_raw_session(0, endpoint_obj);
    assert(rst == PKTCTRL_SUCCESS);

    ICMP_experiment(endpoint_obj, domain);

    fprintf(stderr, "> Terminating\n");
    pktctrl_close(endpoint_obj);
    close(econnfd);

    return 0;
}

bool is_good_fd(int fd) { return (fcntl(fd, F_GETFD) >= 0); }

int create_nopen(struct pktlab_message *msg, uint8_t *laddrptr,
                 uint8_t *lportptr, uint8_t *raddrptr, uint8_t *rportptr,
                 uint8_t sktid, uint8_t family, uint8_t proto,
                 uint32_t rbufsize, const char *localip, uint16_t localport,
                 const char *ip, uint16_t remoteport) {
    uint8_t transproto = proto;

    msg->type = PKTLAB_NOPEN_MESSAGE;
    msg->nopen.family = family;
    msg->nopen.sktid = sktid;
    msg->nopen.proto = proto;
    msg->nopen.rbufsz = rbufsize;

    if (transproto == PKTLAB_RAW_PROTO) {
        if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, localip,
                      laddrptr) != 1)
            return -1;

        msg->nopen.laddrlen = (family == PKTLAB_IP4_PROTO) ? 4 : 16;
        msg->nopen.laddrptr = laddrptr;
    } else if (transproto == PKTLAB_TCP_PROTO ||
               transproto == PKTLAB_UDP_PROTO) {
        if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, ip,
                      raddrptr) != 1)
            return -1;

        if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, localip,
                      laddrptr) != 1)
            return -1;

        msg->nopen.raddrlen = (family == PKTLAB_IP4_PROTO) ? 4 : 16;
        msg->nopen.raddrptr = raddrptr;

        pktlab_set16n(rportptr, remoteport);
        msg->nopen.rportlen = 2;
        msg->nopen.rportptr = rportptr;

        msg->nopen.laddrlen = (family == PKTLAB_IP4_PROTO) ? 4 : 16;
        msg->nopen.laddrptr = laddrptr;
        pktlab_set16n(lportptr, localport);
        msg->nopen.lportlen = 2;
        msg->nopen.lportptr = lportptr;
    }

    return 0;
}

int create_ncap(struct pktlab_message *msg, uint8_t sktid, uint8_t family,
                uint8_t proto, pktlab_time_t endtime,
                const void *filter, uint32_t filterlen) {
    msg->type = PKTLAB_NCAP_MESSAGE;
    msg->ncap.sktid = sktid;
    msg->ncap.family = family;
    msg->ncap.proto = proto;
    msg->ncap.endtime = endtime;
    msg->ncap.filter = filter;
    msg->ncap.filterlen = filterlen;
    return 0;
}

int create_nsend(struct pktlab_message *msg, uint8_t sktid, uint8_t family,
                 uint8_t proto, uint16_t tag, pktlab_time_t time, uint32_t len,
                 const void *ptr) {
    msg->type = PKTLAB_NSEND_MESSAGE;
    msg->nsend.sktid = sktid;
    msg->nsend.family = family;
    msg->nsend.proto = proto;
    msg->nsend.time = time;
    msg->nsend.tag = tag;

    switch (proto) {
    case PKTLAB_RAW_PROTO:
    case PKTLAB_TCP_PROTO:
        msg->nsend.len = len;
        msg->nsend.ptr = ptr;
        break;
    default:
        return -1;
    }

    return 0;
}

int create_nclose(struct pktlab_message *msg, uint8_t sktid) {
    msg->type = PKTLAB_NCLOSE_MESSAGE;
    msg->nclose.sktid = sktid;
    return 0;
}

int try_send(struct pktctrl_obj *obj, const struct pktlab_message *msg) {
    int rst;
    int i;
    struct timespec time = {.tv_sec = 0, .tv_nsec = 100000000};

    rst = pktctrl_write_message(obj, msg);

    for (i = 0; i < 2 && rst == 0; ++i) {
        nanosleep(&time, NULL); // sleep 0.1 sec
        rst = pktctrl_write_message(obj, msg);
    }

    return rst;
}

void send_n_print_err(struct pktctrl_obj *obj,
                      const struct pktlab_message *send_msg) {
    if (try_send(obj, send_msg) != 1)
        perror_exit("try_send", -1);
}

void recv_msg_until_type(int type, struct pktctrl_obj *obj,
                         struct pktlab_message **recv_msg) {

    while (true) {
        if (pktctrl_read_message(obj, recv_msg) < 0)
            print_err_exit(-1, "pktctrl_read_message failed\n");

        if (recv_msg == NULL) {
            print_err_exit(-1, "pktctrl_read_message: sock EOF\n");
        } else if ((*recv_msg)->type != type) {
            fprintf(stderr, ">> Got unexpected msg: %d, expecting %d\n",
                    (*recv_msg)->type, type);
            free(*recv_msg);
            continue;
        }

        break;
    }

    return;
}

ssize_t create_ip4_pkt(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t ttl,
                       uint8_t proto, uint16_t payloadlen, const void *src,
                       const void *dst) {
    /*
     * Refer to RFC 791 for more information on the fields of ipv4
     *
     *   0                   1                   2                   3
     *   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |Version|  IHL  |Type of Service|          Total Length         |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |         Identification        |Flags|      Fragment Offset    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |  Time to Live |    Protocol   |         Header Checksum       |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                       Source Address                          |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Destination Address                        |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Options                    |    Padding    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */

    if (buflen < IPHDR_LEN)
        return -1;

    struct iphdr *iphdr = (struct iphdr *)buf;
    iphdr->ihl = 5;
    iphdr->ver = 4;
    iphdr->tos = 0;
    iphdr->len = pktlab_hton16(IPHDR_LEN + payloadlen);
    iphdr->id = pktlab_hton16(ID);
    iphdr->frag = 0;
    iphdr->ttl = 30;
    iphdr->proto = proto;
    iphdr->cksum = 0;
    memcpy(&iphdr->src, src, IP4_ADDRLEN);
    memcpy(&iphdr->dst, dst, IP4_ADDRLEN);
    iphdr->cksum = comp_cksum(buf, IPHDR_LEN);

    return IPHDR_LEN;
}

ssize_t create_icmp_echo(uint8_t *buf, size_t buflen, uint16_t ID,
                         uint16_t seq) {
    /*
     * Refer to RFC 792 for more information on the fields of icmp echos
     *
     *   0                   1                   2                   3
     *   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |     Type      |     Code      |          Checksum             |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |           Identifier          |        Sequence Number        |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |     Data ...
     *  +-+-+-+-+-
     */

    if (buflen < ICMPHDR_LEN)
        return -1;

    struct icmphdr *icmphdr = (struct icmphdr *)buf;
    icmphdr->type = 8;
    icmphdr->code = 0;
    icmphdr->checksum = 0;
    icmphdr->id = pktlab_hton16(ID);
    icmphdr->sequence = pktlab_hton16(seq);
    icmphdr->checksum = comp_cksum(buf, ICMPHDR_LEN);

    return ICMPHDR_LEN;
}

uint16_t comp_cksum(const uint8_t *buf, size_t len) {
    uint32_t rst = 0xffff;
    uint16_t tmp;
    size_t i;

    for (i = 0; i < len - 1; i += 2) {
        memcpy(&tmp, buf + i, 2);
        rst = (rst + pktlab_ntoh16(tmp)) % 0xffff;
    }

    // Handle any partial block at the end of the data.
    if (len % 2 == 1) {
        tmp = 0;
        memcpy(&tmp, buf + len - 1, 1);
        rst = (rst + pktlab_ntoh16(tmp)) % 0xffff;
    }

    // Return the checksum in network byte order.
    return pktlab_hton16(~rst);
}

void ICMP_experiment(struct pktctrl_obj *obj, char *domain) {
    //
    // Create and send nopen msg
    // Receive result
    //

    fprintf(stderr, "> Sending nopen msg\n");

    struct pktlab_message send_msg;
    uint8_t sktid = 1;
    uint8_t family = PKTLAB_IP4_PROTO;
    uint8_t proto = PKTLAB_RAW_PROTO;
    uint32_t rbufsize = 0x1000;
    const char localip[] = "0.0.0.0";
    uint8_t localaddr[PKTLAB_ADDRLEN_MAX];
    char ip[INET6_ADDRSTRLEN];
    uint8_t remoteaddr[PKTLAB_ADDRLEN_MAX];
    struct pktlab_message *recv_msg;
    struct addrinfo hint = {.ai_family=AF_INET};
    struct addrinfo *res;
    struct addrinfo *aiptr;
    bool addr_found;

    // Note we do the domain name resolution at the controller-side
    // One may want to do it at the endpoint side instead
    if (getaddrinfo(domain, NULL, &hint, &res) != 0)
        print_err_exit(-1, "error: getaddrinfo failed with %s\n", strerror(errno));

    addr_found = false;
    for (aiptr = res; aiptr != NULL; aiptr = aiptr->ai_next) {
        if (aiptr->ai_family != AF_INET)
            continue;

        if (inet_ntop(aiptr->ai_family,
                      &((struct sockaddr_in *) aiptr->ai_addr)->sin_addr.s_addr,
                      ip, sizeof(ip))) {
            fprintf(stderr, ">> Resolved IPv4 address: %s\n", ip);
            memcpy(remoteaddr,
                   &((struct sockaddr_in *) aiptr->ai_addr)->sin_addr.s_addr,
                   sizeof(remoteaddr));
            addr_found = true;
            break;
        }
    }

    freeaddrinfo(res);

    if (!addr_found)
        print_err_exit(-1, "error: cannot resolve domain\n");

    if (create_nopen(&send_msg, localaddr, NULL, NULL, NULL, sktid, family,
                     proto, rbufsize, localip, 0, NULL, 0) < 0)
        print_err_exit(-1, "error: create_nopen\n");

    send_n_print_err(obj, &send_msg);
    recv_msg_until_type(PKTLAB_RESULT_MESSAGE, obj, &recv_msg);

    if (recv_msg->result.errid != PKTLAB_SUCCESS) // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);

    fprintf(stderr, ">> result msg id: %d\n", (int)recv_msg->result.errid);

    free(recv_msg);

    //
    // Create and send ncap msg
    // Receive result
    //

    fprintf(stderr, "> Sending ncap msg\n");

    struct pktlab_ebpf_instr filter[] = \
        EBPF_ICMP_ECHO_REPLY_FILTER(ID_WHOLE);
    size_t filterlen = sizeof(filter);

    uint8_t *encoded_filter;
    uint_fast32_t encoded_filter_len;
    pktlab_time_t endtime = PKTLAB_TIME_MAX; // cap to the end of time

    if (pktlab_encode_program(PKTLAB_EBPF, filter, filterlen,
                              (void**)&encoded_filter, &encoded_filter_len) != 0)
        print_err_exit(-1, "error: encode_ebpf_filter\n");

    if (create_ncap(&send_msg, sktid, family, proto, endtime,
                    encoded_filter, encoded_filter_len) < 0)
        print_err_exit(-1, "error: create_ncap\n");

    send_n_print_err(obj, &send_msg);
    free(encoded_filter);
    recv_msg_until_type(PKTLAB_RESULT_MESSAGE, obj, &recv_msg);

    if (recv_msg->result.errid != 0) // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);

    fprintf(stderr, ">> result msg id: %d\n", (int)recv_msg->result.errid);

    free(recv_msg);

    //
    // Create and send nsend msg
    // Receive result
    //

    fprintf(stderr, "> Sending nsend msg\n");

    pktlab_time_t sendtime = 0;
    uint16_t tag = 1234;
    pktlab_time_t ec_nsend_time;
    uint8_t icmp_echo_req[BUFSZ];

    if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, ip,
                  remoteaddr) != 1)
        perror_exit("inet_pton", -1);

    if (create_icmp_echo(icmp_echo_req + IPHDR_LEN,
                         sizeof(icmp_echo_req) - IPHDR_LEN, ID_WHOLE, 0) < 0)
        print_err_exit(-1, "error: create_icmp_echo\n");

    if (create_ip4_pkt(icmp_echo_req, IPHDR_LEN, ID_WHOLE, 40, ICMP_PROTO,
                       ICMPHDR_LEN, localaddr, remoteaddr) < 0)
        print_err_exit(-1, "error: create_ip4_pkt\n");

    if (create_nsend(&send_msg, sktid, family, proto, tag, sendtime,
                     IPHDR_LEN + ICMPHDR_LEN, icmp_echo_req) < 0)
        print_err_exit(-1, "error: create_nsend\n");

    send_n_print_err(obj, &send_msg);
    ec_nsend_time = pktlab_time_now();
    recv_msg_until_type(PKTLAB_RESULT_MESSAGE, obj, &recv_msg);

    if (recv_msg->result.errid != 0) // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);

    fprintf(stderr, ">> result msg id: %d\n", (int)recv_msg->result.errid);

    free(recv_msg);

    //
    // Receive ndata stuffs
    //

    uint_fast32_t cnt = 0;
    uint8_t buf[BUFSZ];
    pktlab_time_t me_recv_time;
    pktlab_time_t ec_recv_time;
    pktlab_time_t me_send_time;
    bool got_ntag = false;
    bool got_ndata = false;

    while (!(got_ntag && got_ndata)) {
        if (pktctrl_read_message(obj, &recv_msg) < 0)
            perror_exit("pktctrl_read_message", -1);
        if (recv_msg == NULL)
            print_err_exit(-1, "pktctrl_read_message: sock EOF\n");

        fprintf(stderr, ">> Got message type: %d\n", recv_msg->type);
        switch (recv_msg->type) {
        case PKTLAB_NTAG_MESSAGE:
            assert(tag == recv_msg->ntag.tag);
            assert(recv_msg->ntag.errid == PKTLAB_SUCCESS);

            me_send_time = recv_msg->ntag.time;
            got_ntag = true;
            break;
        case PKTLAB_NDATA_MESSAGE:
            if (recv_msg->ndata.sktid != sktid)
                print_err_exit(-1, "Got ndata from uknown socket: %d\n",
                               recv_msg->ndata.sktid);

            memcpy(buf + cnt, recv_msg->ndata.ptr, recv_msg->ndata.len);
            cnt += recv_msg->ndata.len;

            me_recv_time = recv_msg->ndata.time;
            ec_recv_time = pktlab_time_now();

            got_ndata = true;
            break;
        case PKTLAB_SUSPD_MESSAGE:
            fprintf(stderr, "experiment suspended\n");
            free(recv_msg);
            return;
            // break;
        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }

        free(recv_msg);
    }

    //
    // Create and send nclose msg
    // Receive result
    //

    fprintf(stderr, "> Sending nclose msg\n");

    if (create_nclose(&send_msg, sktid) < 0)
        print_err_exit(-1, "error: create_nclose\n");

    send_n_print_err(obj, &send_msg);
    recv_msg_until_type(PKTLAB_RESULT_MESSAGE, obj, &recv_msg);

    if (recv_msg->result.errid != 0) // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);

    free(recv_msg);

    //
    // Print rst
    //

    fprintf(stderr, "\n---->Results<----\n");
    fprintf(stderr, "Received data length: %u\n", (unsigned)cnt);
    printf("Spent time (in ns) at endpoint (endpoint RTT): %" PRIu64 "\n",
            me_recv_time - me_send_time);
    printf("Spent time (in ns) at controller: %" PRIu64 "\n",
            ec_recv_time - ec_nsend_time);
    fprintf(stderr, "\n-->Content<--\n");

    size_t i;
    for (i = 0; i < cnt; ++i) {
        fprintf(stderr, "%02x ", buf[i]);
        if (i % 8 == 7)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");

    printf("\n(ICMP echo to %s (%s) via %s)\n", domain, ip, getenv("EPADDR"));
    return;
}

void perror_exit(const char *str, int exit_val) {
    perror(str);
    exit(exit_val);
}

void print_err_exit(int exit_val, const char *fmt, ...) {
    static char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s", buf);

    exit(exit_val);
}
