// test_fd.c
//

#include <errno.h>
#include <stdio.h>
#include <string.h>

#include <fcntl.h>

int main(void) {
    int rst;

    rst = fcntl(0, F_GETFD);
    if (rst >= 0) {
        fprintf(stderr, "fd 0 is open\n");
    } else {
        fprintf(stderr, "fd 0 is not available (%s)\n",
            strerror(errno));
    }

    rst = fcntl(1, F_GETFD);
    if (rst >= 0) {
        fprintf(stderr, "fd 1 is open\n");
    } else {
        fprintf(stderr, "fd 1 is not available (%s)\n",
            strerror(errno));
    }

    return 0;
}