// test_pktif_dns.c
// PacketLab UDP Experiment Controller Example Program
// Use pktlab measurement endpoint to issue DNS request
//

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>

#include <arpa/inet.h>
#include <assert.h>
#include <netinet/ip.h>
#include <pktif.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

#define ADDRSTRLEN 64
#define BUFSZ 0x10000

static void UDP_experiment(struct pktif *pktif, char *domain, char *ip);

static void print_dns_response(const void * buf, unsigned long len, uint_fast16_t ID);

static void putchars(const char * ptr, size_t len);
static int putname(const char * buf, unsigned int off, unsigned int len, bool first);
static void putip4addr(const void * ptr);
static void putip4addr(const void * ptr);
static void putip6addr(const void * ptr);

static ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID,
                                uint8_t RD, char *domain, size_t domainlen);
static bool is_good_fd(int fd);

int main(int argc, char *argv[]) {
    int econnfd;
    struct sockaddr_in sa;
    char domain[BUFSZ] = {};
    char ip[INET6_ADDRSTRLEN] = {}; // INET_ADDRSTRLEN is smaller
    char sample_domain[] = "www.example.com";
    char sample_ip[] = "8.8.8.8";

    if (argc == 3 && inet_pton(AF_INET, argv[2], &(sa.sin_addr.s_addr)) == 1) {
        strncpy(ip, argv[2], sizeof(ip) - 1);
    } else {
        strncpy(ip, sample_ip, sizeof(ip) - 1);
    }

    if (argc >= 2) {
        strncpy(domain, argv[1], sizeof(domain) - 1);
    } else {
        strncpy(domain, sample_domain, sizeof(domain) - 1);
    }

    if (getenv("EPADDR") == NULL) {
        fprintf(stderr, "EPADDR not set " \
            "(are you running this mlet using pktxpmgr?)\n");
        exit(EXIT_FAILURE);
    }

    fprintf(stderr,
            "> PacketLab Measurement Applet: DNS query example (with pktif)"
            " (querying '%s' for domain '%s') using pktxpmgr\n",
            ip, domain);

    econnfd = 0;
    assert(is_good_fd(econnfd));

    struct pktif *pktif = pktif_init(econnfd, NULL);

    UDP_experiment(pktif, domain, ip);

    pktif_teardown(pktif);

    fprintf(stderr, "> Terminating\n");

    return 0;
}

bool is_good_fd(int fd) { return (fcntl(fd, F_GETFD) >= 0); }

void UDP_experiment(struct pktif *pktif, char *domain, char *ip) {
    pktlab_time_t me_recv_time;
    uint8_t sktid = 1;
    uint8_t proto = PKTLAB_UDP_PROTO;
    uint32_t rbufsize = 0x1000;
    int rv;
    struct sockaddr_in laddr = {.sin_family = AF_INET};
    // inet_pton(AF_INET, "192.168.137.108", &laddr.sin_addr.s_addr);
    laddr.sin_addr.s_addr = INADDR_ANY;
    laddr.sin_port = 0;

    uint8_t buf[BUFSZ];
    rv = pktif_connect_sync(pktif, sktid, proto, (struct sockaddr *)&laddr,
                            NULL, rbufsize, NULL);
    assert(rv == 0);

    //
    // Create and send nsend msg
    // Receive status
    //

    fprintf(stderr, "> Sending nsend msg\n");

    uint16_t tag = 15;
    pktlab_time_t time = 0;
    pktlab_time_t ec_nsend_time;
    pktlab_time_t me_send_time;
    pktlab_time_t ec_npoll_time;
    uint8_t payload[BUFSZ];
    ssize_t payloadlen;
    uint16_t ID = 5566;
    uint8_t RD = 1;
    struct sockaddr_in raddr = {.sin_family = AF_INET};
    inet_pton(AF_INET, ip, &raddr.sin_addr.s_addr);
    raddr.sin_port = htons(53);

    payloadlen =
        create_dns_query(payload, BUFSZ, ID, RD, domain, strlen(domain));
    ec_nsend_time = pktlab_time_now();
    rv = pktif_send_sync(pktif, sktid, payload, payloadlen, proto, time, tag,
                         (struct sockaddr *)&raddr, &me_send_time);
    assert(rv == payloadlen);

    //
    // Create and send npoll msg
    // Receive ndata and nstat
    //

    fprintf(stderr, "> Receiving msg\n");
    size_t len =
        pktif_recv_sync(pktif, sktid, buf, sizeof(buf), NULL, &me_recv_time);
    ec_npoll_time = pktlab_time_now();
    //
    // Create and send nclose msg
    // Receive status
    //

    fprintf(stderr, "> Sending nclose msg\n");
    rv = pktif_close_sync(pktif, sktid);
    assert(rv == 0);

    fprintf(stderr, "\n---->Results<----\n");
    fprintf(stderr, "Received data length: %lu\n", len);
    fprintf(stderr, "ME send time: %lu\n", me_send_time);
    fprintf(stderr, "Spent time at ME: %.3f ms\n",
            (float)(me_recv_time - me_send_time) / 1000000);
    fprintf(stderr, "Spent time at EC: %.3f ms\n",
            (float)(ec_npoll_time - ec_nsend_time) / 1000000);
    fprintf(stderr, "\n-->Content<--\n");

    size_t i;
    for (i = 0; i < len; ++i) {
        fprintf(stderr, "%02x ", buf[i]);
        if (i % 8 == 7)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");

    print_dns_response(buf, len, ID);
    return;
}

void print_dns_response(const void * buf, unsigned long len, uint_fast16_t ID) {
    uint16_t id_local = ID; // first word expected value (no byte order change)
    uint_fast16_t status; // second word, host (native( byte order
    uint_fast16_t qdcount; // third word, number of answers, host byte order
    uint_fast16_t ancount; // fourth word, number of answers, host byte order
    uint_fast8_t lenbyte;
    unsigned int off;
    int line = 0;
    int skip;

    uint_fast16_t type;
    uint_fast16_t cls;
    uint_fast32_t ttl;
    uint_fast16_t rdlen;

    (void)ttl;

    if (len < 6*2) {
        fprintf(stderr, "DNS packet too short (%lu bytes)\n", len);
        return;
    }

    if (memcmp(&id_local, buf, 2) != 0) {
        fprintf(stderr, "DNS packet ID mismatch\n");
        return;
    }

    status = pktlab_get16n(buf+2);

    if ((status >> 15) == 0) {
        fprintf(stderr, "DNS packet not a response\n");
        return;
    }

    qdcount = pktlab_get16n(buf+4);
    ancount = pktlab_get16n(buf+6);

    if ((status & 0xF) != 0) {
        if ((status & 0xF) == 3 && qdcount > 0 && len > 6*2) {
            putname(buf, 6*2, len, true);
            printf(" does not exist (via %s)\n", getenv("EPADDR"));
        } else
            fprintf(stderr, "RCODE == %u != 0\n", (unsigned int)status & 0xF);
        return;
    }

    if (ancount == 0) {
        fprintf(stderr, "ANCOUNT == 0\n");
        return;
    }

    // Skip query data

    off = 6*2;
    while (qdcount > 0) {
        for (;;) {
            if (len <= off) {
                line = __LINE__;
                goto malformed;
            }

            lenbyte = pktlab_get8(buf+off); off += 1;

            if (lenbyte == 0)
                break;

            if ((lenbyte >> 6) == 3) {
                off += 1;
                break;
            }

            off += lenbyte;
        }

        // Skip QTYPE and QCLASS words

        off += 2*2;
        qdcount -= 1;
    }

    // Print response

    while (ancount > 0) {
        skip = putname(buf, off, len, true);

        if (skip < 0) {
            line = -skip;
            goto malformed;
        }

        off += skip;
        fputs(" is ", stdout);

        if (len < off + 5*2) {
            line = __LINE__;
            goto malformed;
        }

        type = pktlab_get16n(buf+off); off += 2;
        cls = pktlab_get16n(buf+off); off += 2;
        ttl = pktlab_get32n(buf+off); off += 4;
        rdlen = pktlab_get16n(buf+off); off += 2;

        if (len < off+rdlen) {
            line = __LINE__;
            goto malformed;
        }

        if (cls == 1) {
            switch (type) {
            case 1: // A record
                if (rdlen != 4) {
                    line = __LINE__;
                    goto malformed;
                } else
                    putip4addr(buf+off);
                break;
            case 28: // AAAA record
                if (rdlen != 16) {
                    line = __LINE__;
                    goto malformed;
                } else
                    putip6addr(buf+off);
                break;
            case 5: // CNAME record
                skip = putname(buf, off, len, true);
                if (skip < 0) {
                    line = -skip;
                    goto malformed;
                } else if (skip != rdlen) {
                    line = __LINE__;
                    goto malformed;
                }
                break;
            default:
                break;
            }
        }

        printf(" (via %s)\n", getenv("EPADDR"));
        off += rdlen;
        ancount -= 1;
    }

    return;

malformed:
    fprintf(stderr, "Malformed DNS packet (%s:%d)\n", __FILE__, line);
    return;
}

void putchars(const char * str, size_t len) {
    fwrite(str, len, 1, stdout);
}

int putname(const char * buf, unsigned int off, unsigned int len, bool first) {
    unsigned int off0 = off; // initial offset; we return off - off0
    uint_fast8_t lenbyte;
    uint_fast8_t tmpoff;
    int skip;

    for (;;) {
        if (len <= off)
            return -__LINE__;

        lenbyte = pktlab_get8(buf+off);
        off += 1;

        if (lenbyte == 0)
            break;

        if ((lenbyte >> 6) == 3) {
            if (off == len)
                return -__LINE__;

            tmpoff = (uint_fast16_t)(lenbyte & 0x3F) << 8;
            tmpoff |= pktlab_get8(buf+off);
            off += 1;

            if (len <= tmpoff)
                return -__LINE__;

            skip = putname(buf, tmpoff, len, first);
            if (skip < 0)
                return skip;
            break;
        }

        if (!first)
            putchar('.');
        else
            first = false;

        putchars(buf+off, lenbyte);
        off += lenbyte;
    }

    return off - off0;
}

void putip4addr(const void * ptr) {
    char strbuf[INET_ADDRSTRLEN];
    const char * addrstr;

    addrstr = inet_ntop(AF_INET, ptr, strbuf, sizeof(strbuf));

    if (addrstr != NULL)
        fputs(addrstr, stdout);
    else
        puts("ERROR");
}

void putip6addr(const void * ptr) {
    char strbuf[INET6_ADDRSTRLEN];
    const char * addrstr;

    addrstr = inet_ntop(AF_INET6, ptr, strbuf, sizeof(strbuf));

    if (addrstr != NULL)
        fputs(addrstr, stdout);
    else
        puts("ERROR");
}

ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t RD,
                         char *domain, size_t domainlen) {
    /*
     * Refer to RFC 1035 for more information on the fields of DNS msgs
     *
     *                                 1  1  1  1  1  1
     *   0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                      ID                       |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    QDCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ANCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    NSCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ARCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    //
    // Create DNS query header
    //

    if (buflen < 12 + domainlen + 2 + 4)
        return -1;

    uint16_t tmp;

    memcpy(buf, &ID, sizeof(ID));

    tmp = htons(0 | ((uint16_t)RD) << 8);
    memcpy(buf + 2, &tmp, sizeof(tmp));

    // printf("%u %u", *(buf + 2), *(buf + 3));

    tmp = htons(1);
    memcpy(buf + 4, &tmp, sizeof(tmp));

    tmp = 0;
    memcpy(buf + 6, &tmp, sizeof(tmp));
    memcpy(buf + 8, &tmp, sizeof(tmp));
    memcpy(buf + 10, &tmp, sizeof(tmp));

    //
    // Create query content
    //

    char *ptr;
    size_t off = 12;
    size_t toklen;
    for (ptr = strtok(domain, "."); ptr != NULL; ptr = strtok(NULL, ".")) {
        toklen = strlen(ptr);

        *(buf + off) = toklen;
        memcpy(buf + off + 1, ptr, toklen);
        off += toklen + 1;
    }

    *(buf + off) = '\0';

    tmp = htons(1);
    memcpy(buf + off + 1, &tmp, sizeof(tmp));
    memcpy(buf + off + 3, &tmp, sizeof(tmp));

    return off + 5;
}