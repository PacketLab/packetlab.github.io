#ifndef _PKTIF_H
#define _PKTIF_H

#include <pktlab.h>
#include <pktctrl.h>
#include <stdint.h>
#include <sys/select.h>
#include <sys/socket.h>

/**
 * @brief record for an endpoint connection
 *
 */
struct pktif;

/**
 * @brief a generic callback function prototype \n
 * struct pktif *: the pktif that the cb is called from \n
 * struct pktlab_message *: the message received corresponding to the
 * registered \n
 * callback void *: a parameter the user can specify at register time
 */

typedef int (*pktif_cbfunc_t)(struct pktif *, struct pktlab_message *, void *);
/**
 * @brief a struct containing the callback function pointer and the parameter
 *
 */
typedef struct {
    pktif_cbfunc_t fn;
    void *param;
} pktif_cb_t;

/**
 * @brief Blockingly wait for an endpoint to connect
 *
 * @param addr (input) local address to bind to
 *             (output) incoming endpoint connection
 * @return int file descriptor number for the socket
 */
int pktif_ep_accept(struct sockaddr *addr);

/**
 * @brief direct connect to an endpoint (or to the controller address on the
 * pipeline server)
 *
 * @param addr address of the endpoint/pipeline server
 * @return int
 */
int pktif_ep_connect(struct sockaddr *addr);

/**
 * @brief intialize a pktif object representing an endpoint connection
 *
 * @param sock the socket descriptor as returned by pktif_ep_*
 * @param addr address of the endpoint
 * @return struct pktif* the endpoint connection \n
 *                      or NULL if failed during init
 */
struct pktif *pktif_init(int sock, struct sockaddr *addr);

/**
 * @brief teardown the pktif object, free all resouces and close the socket
 *
 * @param pktif the pktif struct pointer
 * @return int 0 for success \n
 *              -1 if the pointer is a null pointer
 */
int pktif_teardown(struct pktif *pktif);

/**
 * @brief returns the socket fd for the pktif
 *
 * @param pktif the pktif endpoint connection
 * @return int sockfd
 */
int pktif_get_fileno(struct pktif *pktif);

/**
 * @brief send nopen msg to the endpoint to open a socket to an address while
 * blockingly wait for its response. \n
 * Refer to pktif_connect_async for parameter descriptions
 *
 * @param pktif
 * @param sktid
 * @param proto
 * @param intf
 * @param addr
 * @param rbufsz
 * @return int 0 for success \n
 *              a enum pktlab_status for non-success
 */
int pktif_connect_sync(struct pktif *pktif, uint8_t sktid, uint8_t proto,
                       struct sockaddr *laddr, struct sockaddr *raddr,
                       uint32_t rbufsz, pktif_cb_t *recv_cb);
/**
 * @brief send nopen msg to the endpoint to open a socket to an address and
 * immediately returns
 *
 * @param pktif the pktif endpoint connection
 * @param sktid desired sktid
 * @param proto pktlab protocol
 * @param intf interface to open the connection on
 * @param addr address to connect to the socket to
 * @param rbufsz receiver buffer size
 * @param recv_cb handler for ndata messages received
 * @param con_cb callback function to handle the status message
 * @return int 0 for success \n
 *             -1 for failure, corresponding errno is set \n
 *              ENOMEM for failure in memory allocation \n
 *              otherwise refer to man writev
 */
int pktif_connect_async(struct pktif *pktif, uint8_t sktid, uint8_t proto,
                        struct sockaddr *laddr, struct sockaddr *raddr,
                        uint32_t rbufsz, pktif_cb_t *recv_cb,
                        pktif_cb_t *con_cb);

/**
 * @brief same as send a message on a blocking socket \n
 * refer to pktif_send_async for param
 *
 * @param pktif
 * @param sktid
 * @param buffer
 * @param len
 * @param send_time
 * @param tidx
 * @return ssize_t
 */
ssize_t pktif_send_sync(struct pktif *pktif, uint8_t sktid, void *buffer,
                       size_t len, uint8_t proto, pktlab_time_t send_time,
                       uint16_t tag, struct sockaddr *rudpaddr,
                       pktlab_time_t *ep_send_time);
/**
 * @brief send a msg from an endpoint socket to the other end asynchronously
 *
 * @param pktif the endpoint connection
 * @param sktid desired sktid
 * @param buffer send buffer
 * @param len send buffer length
 * @param send_time scheduled send time
 * @param tidx index to store send time
 * @param send_cb callback struct for nsend
 * @param time_cb callback struct for mread send time
 * @return int 0 for success \n
 *              -1 for failure with corresponding errno set
 */
ssize_t pktif_send_async(struct pktif *pktif, uint8_t sktid, void *buffer,
                        size_t len, uint8_t proto, pktlab_time_t send_time,
                        uint16_t tag, struct sockaddr *rudpaddr,
                        pktif_cb_t *send_cb, pktif_cb_t *time_cb);
/**
 * @brief blockingly waits for data available at the socket and returns the data
 * in the buffer
 *
 * @param pktif the endpoint connection
 * @param sktid desired sktid
 * @param buffer recv buffer
 * @param len recv buffer length
 * @param recv_time endpoint recv time
 * @return ssize_t number of bytes written to the buffer
 * @note sends npoll msgs internally
 */
ssize_t pktif_recv_sync(struct pktif *pktif, uint8_t sktid, void *buffer,
                       size_t len, struct sockaddr *raddr,
                       pktlab_time_t *recv_time);

/**
 * @brief checks for data available at the socket, copies avaiable data into the
 * buffer and returns immediately
 *
 * @param pktif the endpoint connection
 * @param sktid desired sktid
 * @param buffer recv buffer
 * @param len recv buffer length
 * @param recv_time endpoint recv time
 * @return ssize_t number of bytes written to the buffer
 */
ssize_t pktif_recv_async(struct pktif *pktif, uint8_t sktid, void *buffer,
                        size_t len, struct sockaddr *raddr,
                        pktlab_time_t *recv_time);

/**
 * @brief send nclose message for an endpoint socket and blockingly wait for
 * response. \n
 * Refer to pktif_close_async for param
 *
 * @param pktif
 * @param sktid
 * @return int representing an enum pktlab_status type
 */
int pktif_close_sync(struct pktif *pktif, uint8_t sktid);

/**
 * @brief send nclose message for an endpoint socket
 *
 * @param pktif the endpoint connection
 * @param sktid skt to close
 * @param close_cb callback function to handle the status message
 * @return int 0 if the message is successfully sent \n
 *              -1 for failure
 */
int pktif_close_async(struct pktif *pktif, uint8_t sktid, pktif_cb_t *close_cb);

// Interface for installing a capture filter
int pktif_ncap_sync(struct pktif *pktif, uint8_t sktid, uint8_t family,
                    uint8_t proto, pktlab_time_t endtime, const void *filter,
                    uint32_t filterlen);

int pktif_ncap_async(struct pktif *pktif, uint8_t sktid, uint8_t family,
                     uint8_t proto, pktlab_time_t endtime, const void *filter,
                     uint32_t filterlen, pktif_cb_t *ncap_cb);

// select/poll/epoll prototypes
#define PKTIF_SEL_READ 0x1
#define PKTIF_SEL_WRITE 0x2
#define PKTIF_SEL_EXCEPT 0x4

/**
 * @brief optionally set the controll socket in select fdsets passed in
 *
 * @param pktif the endpoint connection
 * @param set a bitmap created using PKTIF_SEL_* macros. Usually PKTIF_SEL_READ
 * is set.
 * @param nfds the highest-numbered fd in any of the three sets, plus 1.
 * @param readfds refer to select manual page
 * @param writefds refer to select manual page
 * @param exceptfds refer to select manual page
 * @param timeout refer to select manual page (not modified now)
 * @return int the highest-numbered fd in any of the three sets returned,
 * plus 1.
 */
int pktif_prepare_select(struct pktif *pktif, int set, int nfds,
                         fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
                         struct timeval *timeout);

/**
 * @brief perform appropriate operations if the controller socket is set in the
 * fd sets: \n
 * if ready for read, pktlab_read_message is called and appropriate cb function
 * is invoked
 *
 * @param pktif the endpoint connection
 * @param set the same bitmap used to prepare the select
 * @param nfds the number of file descriptors contained in the three returned
 * descriptor sets as returned by select syscall, modified if events are handled
 * for the controller socket
 * @param readfds refer to select manual page
 * @param writefds refer to select manual page
 * @param exceptfds refer to select manual page
 * @param timeout refer to select manual page
 * @return int return value from the callback function
 */
int pktif_process_select(struct pktif *pktif, int set, int *nfds,
                         fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
                         struct timeval *timeout);

/**
 * @brief process the received msg until the queue is empty
 *
 * @param pktif the endpoint connection
 * @return int 0 on success
 *              -1 if pktif is NULL
 */
int pktif_on_readable(struct pktif *pktif);

/**
 * @brief read the system time on the endpoint and blockingly wait for response
 *
 * @param pktif the endpoint connection
 * @param time the time read from the endpoint
 * @return int 0 for success \n
 *              -1 for failure
 */
int pktif_mread_systime_sync(struct pktif *pktif, pktlab_time_t *time);

/**
 * @brief read the system time on the endpoint, the mdata message is handled by
 * cb
 *
 * @param pktif the endpoint connection
 * @param cb callback function to handle the mdata message, or status message in
 * case of error
 * @return int 0 for success \n
 *              -1  for failure
 */
int pktif_mread_systime_async(struct pktif *pktif, pktif_cb_t *cb);

// get ipv4 intf no

// get ipv4 addr

// get ipv4 dns no

// get ipv4 dns addr

/**
 * @brief read the ipv4 dns server address at idx
 *
 * @param pktif the endpoint connection
 * @param idx dns server index
 * @param addr the socket address struct to store the server address
 * @return int 0 if success \n
 *              -1 if failure
 */
int pktif_mread_ipv4_dns_addr_sync(struct pktif *pktif, int idx,
                                   struct sockaddr_in *addr);

/**
 * @brief read the ipv4 dns server address at idx asynchronously
 *
 * @param pktif the endpoint connection
 * @param idx dns server index
 * @param cb callback function to handle the mdata message, or status message in
 * case of error
 * @return int 0 if mread send is success \n
 *              -1 for failure
 */
int pktif_mread_ipv4_dns_addr_async(struct pktif *pktif, int idx,
                                    pktif_cb_t *cb);
// skt get local address

// skt get remote address

/**
 * @brief read the send time at tidx
 *
 * @param pktif the endpoint connection
 * @param tidx index into the send timestamp array
 * @param time returned timestamp
 * @return int 0 for success \n
 *              -1 for failure
 */
int pktif_mread_sendtime_sync(struct pktif *pktif, uint16_t tidx,
                              pktlab_time_t *time);

/**
 * @brief read the send time at tidx async
 *
 * @param pktif the endpoint connection
 * @param tidx index into the send timestamp array
 * @param cb callback function to handle the timestamp mdata message, or status
 * message in case of error.
 * @return int 0 if mread send is successful \n
 *              -1 for failure
 */
int pktif_mread_sendtime_async(struct pktif *pktif, uint16_t tidx,
                               pktif_cb_t *cb);

/**
 * @brief read a specified region from the endpoint virtual memory
 *
 * @param pktif the endpoint connection
 * @param memaddr virtual memory addr to read from
 * @param bytecnt number of bytes to read
 * @param buffer buffer to copy the data to, in endpoint byte order (network
 * byte order), and must be at least bytecnt large
 * @return int 0 for success \n
 *              -1 for failure
 */
int pktif_mread_sync(struct pktif *pktif, uint32_t memaddr, uint32_t bytecnt,
                     void *buffer);

/**
 * @brief read a specified region from the endpoint virtual memory
 *
 * @param pktif the endpoint connection
 * @param memaddr virtual memory addr to read from
 * @param bytecnt number of bytes to read
 * @param cb callback function called when the mdata is available
 * @return int 0 for success \n
 *              -1 for failure
 */
int pktif_mread_async(struct pktif *pktif, uint32_t memaddr, uint32_t bytecnt,
                      pktif_cb_t *cb);
#endif
