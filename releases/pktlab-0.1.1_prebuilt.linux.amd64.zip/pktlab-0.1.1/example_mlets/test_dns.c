// test_dns.c
// PacketLab UDP Experiment Controller Example Program
// Use pktlab measurement endpoint to issue DNS request
// Should be used with pktlabec
//

#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "pktlab.h"
#include "pktctrl.h"

#define BUFSZ 0x10000

//
// FUNCTION DECLARATIONS
//

static bool is_good_fd(int fd);

static int create_nopen(struct pktlab_message *msg, uint8_t *laddrptr,
                        uint8_t *lportptr, uint8_t *raddrptr, uint8_t *rportptr,
                        uint8_t sktid, uint8_t family, uint8_t proto,
                        uint32_t rbufsize, const char *localip,
                        uint16_t localport, const char *ip,
                        uint16_t remoteport);
static int create_nsend(struct pktlab_message *msg, uint8_t sktid,
                        uint8_t family, uint8_t proto, uint16_t tag,
                        pktlab_time_t time, uint32_t len, const void *ptr,
                        uint32_t addrlen, const void *addrptr, uint32_t portlen,
                        const void *portptr);
static int create_nclose(struct pktlab_message *msg, uint8_t sktid);
static int try_send(struct pktctrl_obj *obj, const struct pktlab_message *msg);
static void send_n_recv(struct pktctrl_obj *obj,
                        const struct pktlab_message *send_msg,
                        struct pktlab_message **recv_msg);
static ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID,
                                uint8_t RD, char *domain, size_t domainlen);

static void UDP_experiment(struct pktctrl_obj *obj);

static void perror_exit(const char *str, int exit_val);
static void print_err_exit(int exit_val, const char *fmt, ...);

//
// FUNCTION DEFINITIONS
//

int main(void) {
    int econnfd, rst;
    struct pktctrl_obj *endpoint_obj;

    fprintf(stderr, "> PacketLab Experiment Controller: DNS query example "
                    "using pktlabec\n");

    econnfd = 0;
    assert(is_good_fd(econnfd));

    endpoint_obj = pktctrl_create_obj();
    assert(endpoint_obj != NULL);

    rst = pktctrl_raw_session(0, endpoint_obj);
    assert(rst == PKTCTRL_SUCCESS);

    UDP_experiment(endpoint_obj);
    pktctrl_close(endpoint_obj);

    fprintf(stderr, "> Terminating\n");

    return 0;
}

bool is_good_fd(int fd) { return (fcntl(fd, F_GETFD) >= 0); }

int create_nopen(struct pktlab_message *msg, uint8_t *laddrptr,
                 uint8_t *lportptr, uint8_t *raddrptr, uint8_t *rportptr,
                 uint8_t sktid, uint8_t family, uint8_t proto,
                 uint32_t rbufsize, const char *localip, uint16_t localport,
                 const char *ip, uint16_t remoteport) {
    uint8_t transproto = proto;

    msg->type = PKTLAB_NOPEN_MESSAGE;
    msg->nopen.family = family;
    msg->nopen.sktid = sktid;
    msg->nopen.proto = proto;
    msg->nopen.rbufsz = rbufsize;

    if (transproto == PKTLAB_TCP_PROTO || transproto == PKTLAB_UDP_PROTO) {
        if (localip) {
            if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6,
                          localip, laddrptr) != 1)
                return -1;

            msg->nopen.laddrlen = (family == PKTLAB_IP4_PROTO) ? 4 : 16;
            msg->nopen.laddrptr = laddrptr;
            pktlab_set16n(lportptr, localport);
            msg->nopen.lportlen = 2;
            msg->nopen.lportptr = lportptr;
        }
        if (ip && transproto == PKTLAB_TCP_PROTO) {
            if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, ip,
                          raddrptr) != 1)
                return -1;

            msg->nopen.raddrlen = (family == PKTLAB_IP4_PROTO) ? 4 : 16;
            msg->nopen.raddrptr = raddrptr;

            pktlab_set16n(rportptr, remoteport);
            msg->nopen.rportlen = 2;
            msg->nopen.rportptr = rportptr;
        }
    }

    return 0;
}

static int create_nsend(struct pktlab_message *msg, uint8_t sktid,
                        uint8_t family, uint8_t proto, uint16_t tag,
                        pktlab_time_t time, uint32_t len, const void *ptr,
                        uint32_t addrlen, const void *addrptr, uint32_t portlen,
                        const void *portptr) {
    msg->type = PKTLAB_NSEND_MESSAGE;
    msg->nsend.sktid = sktid;
    msg->nsend.family = family;
    msg->nsend.proto = proto;
    msg->nsend.time = time;
    msg->nsend.tag = tag;

    switch (proto) {
    case PKTLAB_TCP_PROTO:
        msg->nsend.len = len;
        msg->nsend.ptr = ptr;
        break;
    case PKTLAB_UDP_PROTO:
        assert(addrptr && portptr);
        msg->nsend.len = len;
        msg->nsend.ptr = ptr;
        msg->nsend.udp.raddrlen = addrlen;
        msg->nsend.udp.raddrptr = addrptr;
        msg->nsend.udp.rportlen = portlen;
        msg->nsend.udp.rportptr = portptr;
        break;
    default:
        return -1;
    }

    return 0;
}

int create_nclose(struct pktlab_message *msg, uint8_t sktid) {
    msg->type = PKTLAB_NCLOSE_MESSAGE;
    msg->nclose.sktid = sktid;
    return 0;
}

// todo: fix this
int try_send(struct pktctrl_obj *obj, const struct pktlab_message *msg) {
    int rst;
    int i;
    struct timespec time = {.tv_sec = 0, .tv_nsec = 100000000};

    rst = pktctrl_write_message(obj, msg);

    for (i = 0; i < 2 && rst == 0; ++i) {
        nanosleep(&time, NULL); // sleep 0.1 sec
        rst = pktctrl_write_message(obj, msg);
    }

    return rst;
}

void send_n_recv(struct pktctrl_obj *obj, const struct pktlab_message *send_msg,
                 struct pktlab_message **recv_msg) {
    if (try_send(obj, send_msg) != 1)
        perror_exit("try_send", -1);

    if (pktctrl_read_message(obj, recv_msg) < 0)
        perror_exit("pktlab_read_message", -1);
}

ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t RD,
                         char *domain, size_t domainlen) {
    /*
     * Refer to RFC 1035 for more information on the fields of DNS msgs
     *
     *                                 1  1  1  1  1  1
     *   0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                      ID                       |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    QDCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ANCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    NSCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ARCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    //
    // Create DNS query header
    //

    if (buflen < 12 + domainlen + 2 + 4)
        return -1;

    uint16_t tmp;

    memcpy(buf, &ID, sizeof(ID));

    tmp = htons(0 | ((uint16_t)RD) << 8);
    memcpy(buf + 2, &tmp, sizeof(tmp));

    tmp = htons(1);
    memcpy(buf + 4, &tmp, sizeof(tmp));

    tmp = 0;
    memcpy(buf + 6, &tmp, sizeof(tmp));
    memcpy(buf + 8, &tmp, sizeof(tmp));
    memcpy(buf + 10, &tmp, sizeof(tmp));

    //
    // Create query content
    //

    char *ptr;
    size_t off = 12;
    size_t toklen;
    for (ptr = strtok(domain, "."); ptr != NULL; ptr = strtok(NULL, ".")) {
        toklen = strlen(ptr);

        *(buf + off) = toklen;
        memcpy(buf + off + 1, ptr, toklen);
        off += toklen + 1;
    }

    *(buf + off) = '\0';

    tmp = htons(1);
    memcpy(buf + off + 1, &tmp, sizeof(tmp));
    memcpy(buf + off + 3, &tmp, sizeof(tmp));

    return off + 5;
}

void UDP_experiment(struct pktctrl_obj *obj) {
    //
    // Create and send nopen msg
    // Receive result
    //

    fprintf(stderr, "> Sending nopen msg\n");

    struct pktlab_message send_msg;
    uint8_t sktid = 1;
    uint8_t family = PKTLAB_IP4_PROTO;
    uint8_t proto = PKTLAB_UDP_PROTO;
    uint32_t rbufsize = 0x1000;
    const char ip[] = "8.8.8.8";
    const char localip[] = "0.0.0.0";
    uint16_t remoteport = 53;
    uint16_t localport = 0;
    uint8_t remoteaddr[PKTLAB_ADDRLEN_MAX];
    uint8_t localaddr[PKTLAB_ADDRLEN_MAX];
    uint8_t rports[2];
    uint8_t lports[2];
    struct pktlab_message *recv_msg;

    if (create_nopen(&send_msg, localaddr, lports, remoteaddr, rports, sktid,
                     family, proto, rbufsize, localip, localport, NULL, 0) < 0)
        perror_exit("error: create_nopen", -1);
    send_n_recv(obj, &send_msg, &recv_msg);
    if (recv_msg == NULL) {
        print_err_exit(-1, "pktctrl_read_message: sock EOF\n");
    } else if (recv_msg->type != PKTLAB_RESULT_MESSAGE) {
        print_err_exit(-1, "Got non-result msg: %d\n", recv_msg->type);
    } else if (recv_msg->result.errid !=
               PKTLAB_SUCCESS) { // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);
    }

    fprintf(stderr, ">> result msg id: %d\n", recv_msg->result.errid);
    free(recv_msg);

    //
    // Create and send nsend msg
    // Receive result
    //

    fprintf(stderr, "> Sending nsend msg\n");

    pktlab_time_t time = 0;
    uint16_t tag = 1234;
    pktlab_time_t ec_nsend_time;
    uint8_t payload[BUFSZ];
    ssize_t payloadlen;

    char domain[BUFSZ] = "www.example.com";
    uint16_t ID = 5566;
    uint8_t RD = 1;
    payloadlen =
        create_dns_query(payload, BUFSZ, ID, RD, domain, strlen(domain));
    if (payloadlen < 0)
        print_err_exit(-1, "create_dns_query: ret -1\n");

    if (inet_pton(family == PKTLAB_IP4_PROTO ? AF_INET : AF_INET6, ip,
                  remoteaddr) != 1)
        perror_exit("inet_pton", -1);

    pktlab_set16n(lports, remoteport);
    if (create_nsend(&send_msg, sktid, family, proto, tag, time, payloadlen,
                     payload, 4, remoteaddr, 2, lports) < 0)
        print_err_exit(-1, "create_nsend: ret -1\n");

    send_n_recv(obj, &send_msg, &recv_msg);
    ec_nsend_time = pktlab_time_now();

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktctrl_read_message: sock EOF\n");
    } else if (recv_msg->type != PKTLAB_RESULT_MESSAGE) {
        print_err_exit(-1, "Got non-result msg: %d\n", recv_msg->type);
    } else if (recv_msg->result.errid != 0) { // only 0 imply success
        print_err_exit(-1, "result msg %02x\n", (int)recv_msg->result.errid);
    }

    fprintf(stderr, ">> result msg id: %02x\n", recv_msg->result.errid);
    free(recv_msg);

    unsigned long cnt = 0;
    unsigned char buf[BUFSZ];
    pktlab_time_t me_recv_time;
    pktlab_time_t ec_recv_time;
    pktlab_time_t me_send_time;
    int done = 0;
    while (!done) {
        if (pktctrl_read_message(obj, &recv_msg) < 0)
            perror_exit("pktctrl_read_message", -1);
        if (recv_msg == NULL)
            print_err_exit(-1, "pktctrl_read_message: sock EOF\n");
        fprintf(stderr, ">> Got message type: %d\n", recv_msg->type);
        switch (recv_msg->type) {
        case PKTLAB_NTAG_MESSAGE:
            assert(tag == recv_msg->ntag.tag);
            assert(recv_msg->ntag.errid == PKTLAB_SUCCESS);
            me_send_time = recv_msg->ntag.time;
            break;
        case PKTLAB_NDATA_MESSAGE:
            if (recv_msg->ndata.sktid != sktid)
                print_err_exit(-1, "Got ndata from uknown socket: %d\n",
                               recv_msg->ndata.sktid);

            memcpy(buf + cnt, recv_msg->ndata.ptr, recv_msg->ndata.len);
            cnt += recv_msg->ndata.len;
            me_recv_time = recv_msg->ndata.time;
            ec_recv_time = pktlab_time_now();
            done = 1;
            break;
        case PKTLAB_NSTAT_MESSAGE:
            fprintf(stderr, "nstat msg id %d\n", recv_msg->nstat.code);
            break;
        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }
        free(recv_msg);
    }

    //
    // Create and send nclose msg
    // Receive result
    //

    fprintf(stderr, "> Sending nclose msg\n");

    create_nclose(&send_msg, sktid);
    send_n_recv(obj, &send_msg, &recv_msg);
    if (recv_msg == NULL) {
        print_err_exit(-1, "pktctrl_read_message: sock EOF\n");
    } else if (recv_msg->type != PKTLAB_RESULT_MESSAGE) {
        print_err_exit(-1, "Got non-result msg: %d\n", recv_msg->type);
    } else if (recv_msg->result.errid != 0) { // only 0 imply success
        print_err_exit(-1, "result msg %d\n", (int)recv_msg->result.errid);
    }

    free(recv_msg);

    //
    // Print rst
    //

    fprintf(stderr, "\n---->Results<----\n");
    fprintf(stderr, "Received data length: %lu\n", cnt);
    fprintf(stderr, "Spent time at ME: %lu\n", me_recv_time - me_send_time);
    fprintf(stderr, "Spent time at EC: %lu\n", ec_recv_time - ec_nsend_time);
    fprintf(stderr, "\n-->Content<--\n");
    size_t i;
    for (i = 0; i < cnt; ++i) {
        fprintf(stderr, "%02x ", buf[i]);
        if (i % 8 == 7)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
    return;
}

void perror_exit(const char *str, int exit_val) {
    perror(str);
    exit(exit_val);
}

void print_err_exit(int exit_val, const char *fmt, ...) {
    static char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s", buf);

    exit(exit_val);
}