#!/usr/bin/env python3

import os
import sys
import socket
import pexpect
import subprocess
import netifaces

PPKS_CONF_PATH = os.path.join(os.path.expanduser("~"), ".pktlab/ppks_conf")
PPKS_CERT_PATH = os.path.join(os.path.expanduser("~"), ".pktlab/certs")
PPKS_KEY_PATH = os.path.join(os.path.expanduser("~"), ".pktlab/keys")

KEY_LIST = ['k_exper', 'k_xc', 'k_eop', 'k_ep']
CERT_LIST = [
        ('k_xc', 'k_xc', 'agent'),
        ('k_ep', 'k_ep', 'agent'),
        ('k_eop', 'k_exper', 'exppriv'),
        ('k_exper', 'k_xc', 'pubcmd'),
        ('k_eop', 'k_ep', 'subcmd')
]

KEY_DESCRIPTION = {
        'k_exper': 'Experimenter Key',
        'k_xc': 'Experiment Controller Key',
        'k_eop': 'Endpoint Operator Key',
        'k_ep': 'Measurement Endpoint Key'
}

SETUP_AUX_PATH = os.path.dirname(os.path.realpath(__file__))
PREFIX_PATH = os.path.dirname(SETUP_AUX_PATH)
CONFIG_PATH = os.path.join(PREFIX_PATH, 'config')
CRED_PATH = os.path.join(PREFIX_PATH, 'cred')

BOP_KEY_PATH = os.path.join(CRED_PATH, 'caida_k_bop.pub')
BOP_KEY_PATH_COPY = os.path.join(PPKS_KEY_PATH, 'caida_k_bop.pub')
XM_EXAMPLE_CONF_PATH = os.path.join(CONFIG_PATH, 'example.xpmgr.conf')
EP_EXAMPLE_CONF_PATH = os.path.join(CONFIG_PATH, 'example.endpt.conf')
XM_CONF_PATH = os.path.join(os.path.expanduser("~"), ".pktlab/xpmgr.conf")
EP_CONF_PATH = os.path.join(os.path.expanduser("~"), ".pktlab/endpt.conf")

def ppks_init():
    p = pexpect.spawn(f'ppksman -g {PPKS_CONF_PATH} init')

    # Choose local key manager
    p.expect('0. LocalFSPPKSKeyManager')
    p.sendline('0')

    # Set key manager directory
    p.expect('Enter path to LocalFSPPKSKeyManager directory')
    p.sendline()

    # Choose local state manager
    p.expect('0. LocalFSPPKSStateManager')
    p.sendline('0')

    # Set state manager directory
    p.expect('Enter path to LocalFSPPKSStateManager directory')
    p.sendline()

    p.wait()

def do_ppks_keygen(keyname):
    p = pexpect.spawn(f'ppksman -g {PPKS_CONF_PATH} \
            generate key {keyname}')

    # Need passphrase for non-fake
    print(f'Now expecting passphrase for private key: {KEY_DESCRIPTION[keyname]} {keyname}...')
    p.interact()

def ppks_keygen():
    '''
    Generate the following keys using command:
    ppksman -g ~/.pktlab/ppks_config generate key TEST_KEY

    1. exper
    2. xc
    3. eop
    4. ep
    '''
    for k in KEY_LIST:
        do_ppks_keygen(k)

def do_ppks_sign(signee_pubkey, cert_type,
                signer_privkey, start_time, end_time, cert_file):
    '''
    Run command
    ppksman -g ~/.pktlab/ppks_config generate cert \
             subcmd ~/.pktlab/ppks_key/TEST_KEY -k ~/.pktlab/ppks_key/TEST_KEY.pub 0 1 CERT_TEST
    '''
    p = pexpect.spawn(f'ppksman -g {PPKS_CONF_PATH} generate \
            cert -k {signee_pubkey} {cert_type} {signer_privkey} {start_time} {end_time} {cert_file} -y')

    p.expect('Loading signer privkey')
    p.interact()
    print(f'Certificate stored in {cert_file}')
    p.wait()

def ppks_sign():
    '''
    TODO: Change expire time
    '''
    start_time = 0
    end_time = 2147483647

    for signer, signee, cert_type in CERT_LIST:
        signer_privkey = os.path.join(PPKS_KEY_PATH, signer)
        signee_pubkey = os.path.join(PPKS_KEY_PATH, f'{signee}.pub')
        print(f'Signing Certificate using private key {KEY_DESCRIPTION[signer]} {signer}')
        cert_name = f"{cert_type}_{signer.split('_')[1]}_{signee.split('_')[1]}.cert"
        cert_file = os.path.join(PPKS_CERT_PATH, cert_name)
        do_ppks_sign(signee_pubkey, cert_type,
                signer_privkey, start_time, end_time, cert_file)

def generate_credentials():
    ppks_init()
    ppks_keygen()
    ppks_sign()

def rewrite_conf_file(file_path):
    with open(file_path, 'r+') as f:
        data = f.read()
        data = data.replace('INSTALL_KEY_CRED_PATH', PPKS_KEY_PATH)
        data = data.replace('INSTALL_CERT_CRED_PATH', PPKS_CERT_PATH)
        f.seek(0)
        f.write(data)

def change_conf_fields(file_path, fields):
    with open(file_path, 'r+') as f:
        data = f.readlines()
        for idx, line in enumerate(data):
            if not line or ' ' not in line:
                continue
            k = line.split(' ')[0]
            if k in fields:
                data[idx] = f'{k} {fields[k]}\n'
        f.seek(0)
        f.writelines(data)

def get_local_ipaddr_info():
    try:
        ss = socket.socket()
        ss.settimeout(1) # timeout after 1 sec
        ss.connect(('8.8.8.8', 53))
        ipaddr = ss.getsockname()[0]
        ss.close()
        netif_info = [netifaces.ifaddresses(k) for k in netifaces.interfaces()]
        info_list = [j for v in netif_info for k in v.values() for j in k if 'addr' in j and j['addr'] == ipaddr]
        if not len(info_list):
            raise Exception('IP addr not found')
        netmask = info_list[0]['netmask']
        nm = sum(bin(int(x)).count('1') for x in netmask.split('.'))
        info = f'{ipaddr}/{nm}'
        return info
    except:
        print(
            'Warning: Failed to infer WAN interface address for endpoint config, '+
            'using 127.0.0.1/8 as fallback. '+
            'Please update the VMemLocalAddrStrIPv4 setting in ~/.pktlab/endpt.conf to fix this issue.',
            file=sys.stderr)
        return ''


def generate_configs():
    os.popen(f"cp {XM_EXAMPLE_CONF_PATH} {XM_CONF_PATH}").read()
    os.popen(f"cp {EP_EXAMPLE_CONF_PATH} {EP_CONF_PATH}").read()
    os.popen(f"cp {BOP_KEY_PATH} {BOP_KEY_PATH_COPY}").read()

    rewrite_conf_file(XM_CONF_PATH)
    rewrite_conf_file(EP_CONF_PATH)

    ipaddr_info = get_local_ipaddr_info()
    if ipaddr_info:
        change_conf_fields(EP_CONF_PATH, {'VMemLocalAddrStrIPv4' : ipaddr_info})

def check_ppks_installation():
    p = subprocess.Popen('ppksman', stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
    (output, error) = p.communicate()
    test_str = 'usage: PPKSMan [-h]'
    if test_str in output.decode() or test_str in error.decode():
        return True
    return False


if __name__ == "__main__":
    if os.path.exists(os.path.join(os.path.expanduser("~"), ".pktlab")):
        sys.exit(
            'Error: Local ~/.pktlab directory already exists. '+
            'The pktlab-init script can only be run once.')
    if not check_ppks_installation():
        sys.exit(
            'Error: Failed to run PPKSMan command. '+
            'Please install packages in requirements.txt and export $HOME/.local/bin to PATH.')

    generate_credentials()
    generate_configs()