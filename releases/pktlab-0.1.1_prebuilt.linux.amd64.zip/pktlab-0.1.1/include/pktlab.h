// pktlab.h
// General utilities for pktlab.
//

/**
 * @file pktlab.h
 * @brief General utilities for pktlab.
 */

#ifndef _PKTLAB_H_
#define _PKTLAB_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <time.h>

#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/uio.h>

//
// GENERAL CONSTANTS
//

#define PKTLAB_IP4_ADDR_LEN PKTLAB_IPV4_WO_MSK_ADDR_LEN
#define PKTLAB_IP4_MASK_LEN \
	(PKTLAB_IPV4_W_MSK_ADDR_LEN-PKTLAB_IPV4_W_MSK_ADDR_LEN)
#define PKTLAB_IP6_ADDR_LEN PKTLAB_IPV6_ADDR_LEN

#define PKTLAB_IPV4_W_MSK_ADDR_LEN 8
#define PKTLAB_IPV4_WO_MSK_ADDR_LEN 4
#define PKTLAB_IPV6_ADDR_LEN 16

#define PKTLAB_ADDRLEN_MAX PKTLAB_IP6_ADDR_LEN
#define PKTLAB_PORTLEN_MAX 2

#define PKTLAB_DEFAULT_ADDR_STR "127.0.0.1"

/**
 * @def PKTLAB_DEFAULT_EXP_PORT_STR
 * @brief Default controller experiment listening port string.
 */
#define PKTLAB_DEFAULT_EXP_PORT_STR "20556"
/**
 * @def PKTLAB_DEFAULT_PUB_PORT_STR
 * @brief Default broker experiment publication port string.
 */
#define PKTLAB_DEFAULT_PUB_PORT_STR "20556"
/**
 * @def PKTLAB_DEFAULT_SUB_PORT_STR
 * @brief Default broker experiment subscription port string.
 */
#define PKTLAB_DEFAULT_SUB_PORT_STR "20557"

#define PKTLAB_DEFAULT_SPEC_STR \
	PKTLAB_DEFAULT_ADDR_STR ":" PKTLAB_DEFAULT_EXP_PORT_STR

/**
 * @def PKTLAB_MAX_SKT_CNT
 * @brief Endpoint maximum pktlab socket count.
 */
#define PKTLAB_MAX_SKT_CNT      0x100

/**
 * @def PKTLAB_MAX_LADDR_CNT
 * @brief Endpoint maximum exportable local addresses.
 */
#define PKTLAB_MAX_LADDR_CNT    0x100

/**
 * @def PKTLAB_MAX_LDNSADDR_CNT
 * @brief Endpoint maximum exportable local DNS addresses.
 */
#define PKTLAB_MAX_LDNSADDR_CNT 0x10

#define PKTLAB_SHA256_DIGEST_LEN   32
#define PKTLAB_ED25519_SIG_LEN     64

//
// TIME-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @brief Variable type for pktlab time.
 *
 * Note pktlab time is in pktlab ticks (1 pktlab tick = 1 nanosecond) from the Unix Epoch.
 */
typedef uint64_t pktlab_time_t;

#define PKTLAB_TICKS_PER_SECOND UINT64_C(1000000000)
#define PKTLAB_TIME_MAX         UINT64_MAX

/**
 * @brief Get current pktlab time.
 * @return Current pktlab time.
 */
extern pktlab_time_t pktlab_time_now(void);

/**
 * @brief Convert seconds to pktlab ticks.
 * @param[in] sec The number of seconds to convert.
 * @return        Converted result in pktlab ticks.
 */
static inline pktlab_time_t pktlab_time_sec(uint_fast32_t sec);

/**
 * @brief Convert time period in struct timeval to pktlab ticks.
 * @param[in] tv Pointer to time period in struct timeval to convert.
 * @return       Converted result in pktlab ticks.
 */
static inline pktlab_time_t pktlab_timeval_to_time(const struct timeval * tv);

/**
 * @brief Convert time period in pktlab ticks to struct timeval.
 * @param[in]  t  The number of pktlab ticks to convert.
 * @param[out] tv Pointer to a timeval struct to store the converted result.
 */
static inline void pktlab_time_to_timeval(pktlab_time_t t, struct timeval * tv);

/**
 * @brief Convert a pktlab time to Unix time (in second precision).
 * @param[in] t The pktlab time to convert.
 * @return      The converted Unix time.
 */
static inline uint_fast32_t pktlab_time_to_unix_time(pktlab_time_t t);

/**
 * @brief Convert time in struct tm to pktlab time.
 * @param[in] tm Pointer to time in struct tm to convert.
 * @return       The converted pktlab time.
 */
extern pktlab_time_t pktlab_tm_to_time(const struct tm * tm);

//
// XDESCR/DATTR-RELATED DECLARATIONS & DEFINITIONS
//

#define PKTLAB_XDESCR_DATTR_PAIR_SEP      '='
#define PKTLAB_XDESCR_DATTR_PAIR_END      ';'

/**
 * @def PKTLAB_XDESCR_DATTR_NAMELEN_MIN
 * @brief Minimum xdescr/dattr pair name length.
 */
#define PKTLAB_XDESCR_DATTR_NAMELEN_MIN   0x1

/**
 * @def PKTLAB_XDESCR_DATTR_NAMELEN_MAX
 * @brief Maximum xdescr/dattr pair name length.
 */
#define PKTLAB_XDESCR_DATTR_NAMELEN_MAX   0x20

/**
 * @def PKTLAB_XDESCR_DATTR_VALUELEN_MIN
 * @brief Minimum xdescr/dattr pair value length.
 */
#define PKTLAB_XDESCR_DATTR_VALUELEN_MIN  0x1

/**
 * @def PKTLAB_XDESCR_DATTR_VALUELEN_MAX
 * @brief Maximum xdescr/dattr pair value length.
 */
#define PKTLAB_XDESCR_DATTR_VALUELEN_MAX  0x100

/**
 * @struct pktlab_xdescr_dattr_pair
 * @brief Structure for encoding/decoding experiment descriptor (xdescr)/endpoint attribute (dattr) in xpub and xsub messages.
 */
struct pktlab_xdescr_dattr_pair {
	const char * name;
	const char * value;
	uint_fast32_t namelen;
	uint_fast32_t valuelen;
};

/**
 * @brief Decode an encoded experiment descriptor (xdescr) string.
 * @param[in]  xdescr    Pointer to the encoded xdescr string.
 * @param[in]  xdescrlen Encoded xdescr string length.
 * @param[out] pairs     Pointer to return an allocated array of decoded xdescr name-value pair(s).
 * @param[out] paircnt   Pointer to return the number of xdescr name-value pair(s).
 * @return               0 for success, < 0 for failure. Decoded pairs are returned via pairs and paircnt upon success.
 *
 * - Note when xdescr is NULL, xdescrlen must be 0 and vice versa.
 * - The returned pairs should be freed with free() in stdlib.h.
 */
extern int pktlab_decode_xdescr (
	const char * xdescr, uint_fast32_t xdescrlen,
	struct pktlab_xdescr_dattr_pair ** pairs, uint_fast32_t * paircnt);
/**
 * @brief Encode an experiment descriptor (xdescr) string.
 * @param[in]  pairs   Pointer to an array of name-value pair(s) to encode.
 * @param[in]  paircnt Length of name-value pair array.
 * @param[out] buf     Pointer to buffer for storing the encoded xdescr string.
 * @param[in]  buflen  Size of buffer.
 * @param[out] used    Pointer to return the length of the encoded xdescr string.
 * @return             0 for success, < 0 for failure.
 *
 * - Note when pairs is NULL, paircnt must be 0 and vice versa.
 * - One can estimate the buffer size needed by summing up the name length and value length of all pairs, with an additional overhead of two characters per pair. I.e. with two pairs {name:"foo",value:"bar"} and {name:"hello",value:"world"}, the length needed is 3+3+2=8 for the first pair and 5+5+2=12 for the second pair.
 * - One would therefore need a buffer size of at least 20 characters for encoding.
 * - The returned xdescr string is NOT '\0'-terminated.
 */
extern int pktlab_encode_xdescr (
	const struct pktlab_xdescr_dattr_pair * pairs, uint_fast32_t paircnt,
	char * buf, uint_fast32_t buflen, uint_fast32_t * used);

/**
 * @brief Decode an encoded endpoint attribute (dattr) string.
 * @param[in]  dattr    Pointer to the encoded dattr string.
 * @param[in]  dattrlen Encoded dattr string length.
 * @param[out] pairs    Pointer to return an allocated array of decoded dattr name-value pair(s).
 * @param[out] paircnt  Pointer to return the number of dattr name-value pair(s).
 * @return              0 for success, < 0 for failure.
 *
 * - Note when dattr is NULL, dattrlen must be 0 and vice versa.
 * - The returned pairs should be freed with free() in stdlib.h.
 */
extern int pktlab_decode_dattr (
	const char * dattr, uint_fast32_t dattrlen,
	struct pktlab_xdescr_dattr_pair ** pairs, uint_fast32_t * paircnt);
/**
 * @brief Encode an endpoint attribute (dattr) string.
 * @param[in]  pairs   Pointer to an array of name-value pair(s) to encode.
 * @param[in]  paircnt Length of name-value pair array.
 * @param[out] buf     Pointer to buffer for storing the encoded dattr string.
 * @param[in]  buflen  Size of buffer.
 * @param[out] used    Pointer to return the length of the encoded dattr string.
 * @return             0 for success, < 0 for failure.
 *
 * - Note when pairs is NULL, paircnt must be 0 and vice versa.
 * - One can estimate the buffer size the same way as described for pktlab_encode_xdescr().
 * - The returned dattr string is NOT '\0'-terminated.
 */
extern int pktlab_encode_dattr (
	const struct pktlab_xdescr_dattr_pair * pairs, uint_fast32_t paircnt,
	char * buf, uint_fast32_t buflen, uint_fast32_t * used);

/**
 * @brief Match an experiment descriptor (xdescr) string to an endpoint attribute (dattr) string.
 * @param[in] xdescr    xdescr string as the matching pattern.
 * @param[in] xdescrlen Length of xdescr string.
 * @param[in] dattr     dattr string as the matching target.
 * @param[in] dattrlen  Length of dattr string.
 * @return              When both xdescr and dattr are well-formed (can be decoded),
 *                      true for a match between the two, false otherwise.
 *                      If either is malformed, false is returned.
 *
 * - This function is used by the broker/rendezvous server to match between experiment publication and subscription and decide whether an experiment notification should be sent to an endpoint. A notification is sent iff when there is a match.
 * - Note when xdescr is NULL, xdescrlen must be 0 and vice versa. The same applies to dattr and dattrlen.
 * - Whether there is a match between (the well-formed) xdescr and dattr is decided based on the following:
 *  -# If dattr is empty (0-length/no pairs), it is a match.
 *  -# Otherwise, for all pairs in dattr, look for pairs in xdescr with the same name.
 *  -# If there is no such pair in xdescr, it is considered a match for this dattr pair.
 *  -# Else, if among all pairs in xdescr that have the same name, there exist at least one pair that has a value string matching the dattr pair value string (after wildcard matching), it is a match for this dattr pair. If no such pair exists, it is a no match for this dattr pair.
 *  -# The overall matching result is the logical AND of per-dattr-pair matching results.
 */
extern bool pktlab_xdescr_dattr_match (
	const char * xdescr, uint_fast32_t xdescrlen,
	const char * dattr, uint_fast32_t dattrlen);

//
// CHANNEL-RELATED DECLARATIONS & DEFINITIONS
//

#define PKTLAB_CHANNELID_LEN_MIN 1
#define PKTLAB_CHANNELID_LEN_MAX PKTLAB_SHA256_DIGEST_LEN

/**
 * @struct pktlab_channel
 * @brief Structure for encoding/decoding channel lists in xpub and xsub messages.
 */
struct pktlab_channel {
	void * channel;
	uint_fast32_t channellen;
	struct pktlab_channel * next;
};

/**
 * @brief Encode a channel list.
 * @param[in]  channels  Linked list of channels to encode.
 * @param[out] chlistptr Pointer to return the allocated encoded channel list.
 * @param[out] chlistlen Length of encoded channel list returned.
 * @return
 *  -# 0 for success.
 *  -# -1 for bad argument.
 *  -# -2 for bad channel in channels.
 *  -# Other < 0 values for unknown errors.
 *
 * - The returned chlistptr should be freed with free() in stdlib.h.
 */
extern int pktlab_encode_chlist (
	const struct pktlab_channel * channels,
	void ** chlistptr, uint_fast32_t * chlistlen);
/**
 * @brief Decode a channel list.
 * @param[in]  chlistptr Encoded channel list to decode.
 * @param[in]  chlistlen Length of encoded channel list.
 * @param[out] channels  Pointer to return the allocated decoded channel linked list.
 * @return
 *  -# 0 for success.
 *  -# -1 for bad argument.
 *  -# -2 for malformed chlist.
 *  -# Other < 0 values for unknown errors.
 *
 * - The returned channels should be freed with pktlab_free_channels().
 */
extern int pktlab_decode_chlist (
	const void * chlistptr, uint_fast32_t chlistlen,
	struct pktlab_channel ** channels);

/**
 * @brief Free an allocated channel linked list.
 * @param[in,out] channels  Allocated channel linked list to free.
 */
extern void pktlab_free_channels (
	struct pktlab_channel * channels);

//
// FILTER-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @enum pktlab_filter_type
 * @brief pktlab defined filter types.
 */
enum pktlab_filter_type {
	PKTLAB_CBPF = 0x0, /**< Classic BPF */
	PKTLAB_EBPF = 0x1  /**< Extended BPF (not supported yet) */
};

// TODO: filter support
//extern int pktlab_encode_filter (
//	int type, const void * filter, uint_fast32_t filterlen,
//	void * buf, uint_fast32_t * buflen);
//extern int pktlab_decode_filter (
//	int type, const void * filter, uint_fast32_t filterlen,
//	void * buf, uint_fast32_t * buflen);

//
// URI-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @enum pktlab_uri_type
 * @brief pktlab defined URI types.
 */
enum pktlab_uri_type {
	EXP_URI_TYPE       = 0,   /**< Experiment controller URI type. In URI: "exp" */
	BROKER_URI_TYPE    = 1,   /**< Broker URI type. In URI: "broker" */
	MALFORMED_URI_TYPE = -1,  /**< Malformed/unknown URI type. */
};

/**
 * @struct pktlab_uri
 * @brief Structure for storing decoded pktlab URI information.
 */
struct pktlab_uri {
	enum pktlab_uri_type type;      /**< Decoded URI type. */
	union {
		struct {
			const char * ptr;
			uint_fast32_t len;
		} malformed;                /**< Malformed data. */

		struct {
			const char * host;
			uint_fast32_t hostlen;
			uint16_t port;
		} uri;                      /**< Decoded URI information. */
	};
};

/**
 * @brief Decode a pktlab URI.
 * @param[out] uri_info Pointer to a struct for storing the decoded result.
 * @param[in]  ptr      pktlab URI to decode.
 * @param[in]  len      Length of pktlab URI.
 * @return
 *  -# 0 for success.
 *  -# -1 for bad argument.
 *  -# -2 for malformed URI.
 *  -# Other < 0 values for unknown errors.
 *
 * - Note the uri_info is set only when either the decoding is successful, or the URI is malformed. When the decoding is successful, type is set to the decoded URI type with the decoded information being set in the uri struct. Otherwise, the malformed struct is set with the type set to MALFORMED_URI_TYPE.
 * - Note the uri_info fields rely on the passed ptr. If the content in ptr is changed after the call to pktlab_parse_uri(), the uri_info fields may change as well.
 * - The expected URI format: "pktlab://HOST[:PORT]/exp|broker/".
 */
extern int pktlab_parse_uri (
	struct pktlab_uri * restrict uri_info,
	const void * restrict ptr, uint_fast32_t len);

//
// ENDPOINT-VMEM-RELATED DECLARATIONS & DEFINITIONS
//

// endpoint vmem field address/len macros
//

// current pkt
#define PKTLAB_VMEMADDR_CURPKT                  (0x0)
#define PKTLAB_VMEMADDR_CURPKT_DATA             (PKTLAB_VMEMADDR_CURPKT)
#define PKTLAB_VMEMADDR_CURPKT_LEN              (PKTLAB_VMEMADDR_CURPKT+0x1000000)
#define PKTLAB_VMEMADDR_CURPKT_SKTID            (PKTLAB_VMEMADDR_CURPKT+0x1000010)

#define PKTLAB_VMEMADDR_CURPKT_SL               (0x1000011)
#define PKTLAB_VMEMADDR_CURPKT_DATA_FL          (sizeof(uint8_t)*0x1000000)
#define PKTLAB_VMEMADDR_CURPKT_LEN_FL           (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_CURPKT_SKTID_FL         (sizeof(uint8_t))

// system param
#define PKTLAB_VMEMADDR_SYSPARAM                (0x10000000)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4NO          (PKTLAB_VMEMADDR_SYSPARAM)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6NO          (PKTLAB_VMEMADDR_SYSPARAM+0x1)
#define PKTLAB_VMEMADDR_SYSPARAM_TRANSSUP       (PKTLAB_VMEMADDR_SYSPARAM+0x2)
#define PKTLAB_VMEMADDR_SYSPARAM_BUFMAXDUP      (PKTLAB_VMEMADDR_SYSPARAM+0x6)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4LS          (PKTLAB_VMEMADDR_SYSPARAM+0x100)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6LS          (PKTLAB_VMEMADDR_SYSPARAM+0x1000)
#define PKTLAB_VMEMADDR_SYSPARAM_TIME           (PKTLAB_VMEMADDR_SYSPARAM+0x10000)
#define PKTLAB_VMEMADDR_SYSPARAM_BUFMAX         (PKTLAB_VMEMADDR_SYSPARAM+0x10010)
#define PKTLAB_VMEMADDR_SYSPARAM_BUFUSED        (PKTLAB_VMEMADDR_SYSPARAM+0x10014)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4DNSNO       (PKTLAB_VMEMADDR_SYSPARAM+0x20000)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6DNSNO       (PKTLAB_VMEMADDR_SYSPARAM+0x20001)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4DNSLS       (PKTLAB_VMEMADDR_SYSPARAM+0x20010)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6DNSLS       (PKTLAB_VMEMADDR_SYSPARAM+0x20100)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4HDRMOD      (PKTLAB_VMEMADDR_SYSPARAM+0x20200)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6HDRMOD      (PKTLAB_VMEMADDR_SYSPARAM+0x20210)
#define PKTLAB_VMEMADDR_SYSPARAM_HOSTID         (PKTLAB_VMEMADDR_SYSPARAM+0x30000)
#define PKTLAB_VMEMADDR_SYSPARAM_LATLONG        (PKTLAB_VMEMADDR_SYSPARAM+0x30100)
#define PKTLAB_VMEMADDR_SYSPARAM_OSINFO         (PKTLAB_VMEMADDR_SYSPARAM+0x30200)

#define PKTLAB_VMEMADDR_SYSPARAM_SL             (0x30400)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4NO_FL       (sizeof(uint8_t))
#define PKTLAB_VMEMADDR_SYSPARAM_IP6NO_FL       (sizeof(uint8_t))
#define PKTLAB_VMEMADDR_SYSPARAM_TRANSSUP_FL    (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_SYSPARAM_IP4LS_FL       (sizeof(uint8_t)*PKTLAB_IPV4_W_MSK_ADDR_LEN*0x100)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6LS_FL       (sizeof(uint8_t)*PKTLAB_IPV6_ADDR_LEN*0x100)
#define PKTLAB_VMEMADDR_SYSPARAM_TIME_FL        (sizeof(pktlab_time_t))
#define PKTLAB_VMEMADDR_SYSPARAM_BUFMAX_FL      (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_SYSPARAM_BUFUSED_FL     (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_SYSPARAM_IP4DNSNO_FL    (sizeof(uint8_t))
#define PKTLAB_VMEMADDR_SYSPARAM_IP6DNSNO_FL    (sizeof(uint8_t))
#define PKTLAB_VMEMADDR_SYSPARAM_IP4DNSLS_FL    (sizeof(uint8_t)*PKTLAB_IPV4_WO_MSK_ADDR_LEN*0x10)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6DNSLS_FL    (sizeof(uint8_t)*PKTLAB_IPV6_ADDR_LEN*0x10)
#define PKTLAB_VMEMADDR_SYSPARAM_IP4HDRMOD_FL   (sizeof(uint8_t)*0xC)
#define PKTLAB_VMEMADDR_SYSPARAM_IP6HDRMOD_FL   (sizeof(uint8_t)*0x8)
#define PKTLAB_VMEMADDR_SYSPARAM_HOSTID_FL      (sizeof(char)*0x100)
#define PKTLAB_VMEMADDR_SYSPARAM_LATLONG_FL     (sizeof(char)*0x40)
#define PKTLAB_VMEMADDR_SYSPARAM_OSINFO_FL      (sizeof(char)*0x200)

// skt info
#define PKTLAB_VMEMADDR_SKTINFO                 (0x20000000)
#define PKTLAB_VMEMADDR_SKTINFO_BLKLEN          (0x400)
#define PKTLAB_VMEMADDR_SKTINFO_FAMILY          (0x0)
#define PKTLAB_VMEMADDR_SKTINFO_PROTO           (0x1)
#define PKTLAB_VMEMADDR_SKTINFO_STAT            (0x2)
#define PKTLAB_VMEMADDR_SKTINFO_LADDR           (0x10)
#define PKTLAB_VMEMADDR_SKTINFO_RADDR           (0x20)
#define PKTLAB_VMEMADDR_SKTINFO_LPORT           (0x30)
#define PKTLAB_VMEMADDR_SKTINFO_RPORT           (0x32)
#define PKTLAB_VMEMADDR_SKTINFO_RBUFSZ          (0x40)
#define PKTLAB_VMEMADDR_SKTINFO_RBUFUSED        (0x44)
#define PKTLAB_VMEMADDR_SKTINFO_DROPSTAT        (0x50)
#define PKTLAB_VMEMADDR_SKTINFO_NSENDERR        (0x60)
#define PKTLAB_VMEMADDR_SKTINFO_NSENDERRTAG     (0x61)
#define PKTLAB_VMEMADDR_SKTINFO_NOTIFMASK       (0x70)
#define PKTLAB_VMEMADDR_SKTINFO_CTFL            (0x100)

#define PKTLAB_VMEMADDR_SKTINFO_SL              (PKTLAB_VMEMADDR_SKTINFO_BLKLEN*0x100)
#define PKTLAB_VMEMADDR_SKTINFO_PROTO_FL        (sizeof(uint8_t))
#define PKTLAB_VMEMADDR_SKTINFO_STAT_FL         (sizeof(int8_t))
#define PKTLAB_VMEMADDR_SKTINFO_LADDR_FL        (sizeof(uint8_t)*PKTLAB_ADDRLEN_MAX)
#define PKTLAB_VMEMADDR_SKTINFO_RADDR_FL        (sizeof(uint8_t)*PKTLAB_ADDRLEN_MAX)
#define PKTLAB_VMEMADDR_SKTINFO_LPORT_FL        (sizeof(uint16_t))
#define PKTLAB_VMEMADDR_SKTINFO_RPORT_FL        (sizeof(uint16_t))
#define PKTLAB_VMEMADDR_SKTINFO_RBUFSZ_FL       (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_SKTINFO_RBUFUSED_FL     (sizeof(uint32_t))
#define PKTLAB_VMEMADDR_SKTINFO_DROPSTAT_FL     (sizeof(uint32_t)*2)
#define PKTLAB_VMEMADDR_SKTINFO_NSENDERR_FL     (sizeof(int8_t))
#define PKTLAB_VMEMADDR_SKTINFO_NSENDERRTAG_FL  (sizeof(uint16_t))
#define PKTLAB_VMEMADDR_SKTINFO_NOTIFMASK_FL    (sizeof(uint16_t))
#define PKTLAB_VMEMADDR_SKTINFO_CTFL_FL         (sizeof(uint8_t)*0x80)

// other segments
#define PKTLAB_VMEMADDR_NSENDTSTP               (0x30000000)
#define PKTLAB_VMEMADDR_MONSCRATCH              (0x40000000)
#define PKTLAB_VMEMADDR_MONPERSIST              (0x50000000)

#define PKTLAB_VMEMADDR_NSENDTSTP_SL            (sizeof(pktlab_time_t)*0x10000)
#define PKTLAB_VMEMADDR_MONSCRATCH_SL           (sizeof(uint8_t)*0x10000000)
#define PKTLAB_VMEMADDR_MONPERSIST_SL           (sizeof(uint8_t)*0x10000000)

// endpoint supported (trans)proto field (TRANSSUP) proto bit indices
//

#define PKTLAB_RAW_SUP_BIT_INDX 0
#define PKTLAB_TCP_SUP_BIT_INDX 1
#define PKTLAB_UDP_SUP_BIT_INDX 2

// endpoint raw socket pkts OS header field modification behavior (IP4HDRMOD/IP6HDRMOD) values
//

enum pktlab_rawhdr_info {
	PKTLAB_RAWHDR_NOCHG     = 0,
	PKTLAB_RAWHDR_CHG       = 1,
	PKTLAB_RAWHDR_0FILL     = 2
};

// endpoint skt info skt state field (STAT) values
//

enum pktlab_socket_state {
	PKTLAB_SKTST_FREE        = 0,
	PKTLAB_SKTST_OPENING     = 1,
	PKTLAB_SKTST_OPEN        = 2,
	PKTLAB_SKTST_EOF         = 3,
	PKTLAB_SKTST_WFIN        = 4,
	PKTLAB_SKTST_END         = 5,
	PKTLAB_SKTST_REFUSED     = -1,
	PKTLAB_SKTST_RESET       = -2,
	PKTLAB_SKTST_TIMEDOUT    = -3,
	PKTLAB_SKTST_UNREACH     = -4,
	PKTLAB_SKTST_UNKFAULT    = -128
};

// endpoint skt info skt nsend err field (NSENDERR) values
//

enum pktlab_nsend_err {
	PKTLAB_NSEND_SUCCESS    = 0,
	PKTLAB_NSEND_NORES      = 1,
	PKTLAB_NSEND_BADPKT     = 2,
	PKTLAB_NSEND_TIMEDOUT   = 3,
	PKTLAB_NSEND_RESET      = 4,
	PKTLAB_NSEND_UNREACH    = 5,
	PKTLAB_NSEND_WFIN       = 6,
	PKTLAB_NSEND_UNKFAULT   = 127
};

// endpoint skt info skt notification mask (NOTIFMASK) indices
//

#define PKTLAB_NOTIFMASK_NTAG    (0x1 << 1)
#define PKTLAB_NOTIFMASK_NSTAT   (0x1 << 2)
#define PKTLAB_NOTIFMASK_NDATA   (0x1 << 3)
#define PKTLAB_NOTIFMASK_NDROP   (0x1 << 4)

// endpoint vmem impl. utilities
//

struct pktlab_vmem_region; // forward declaration

typedef void (*pktlab_vmem_reader_t) (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict dst);

typedef void (*pktlab_vmem_writer_t) (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict src);

struct pktlab_vmem_region {
	uint32_t start, end;
	pktlab_vmem_reader_t read;
	pktlab_vmem_writer_t write;
	uintptr_t aux;
};

extern void pktlab_vmem_read (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len, void * restrict dst);

extern void pktlab_vmem_write (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len, const void * restrict src);

extern void pktlab_buffer_reader (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t addr, uint_fast32_t len, void * restrict dst);

extern void pktlab_buffer_writer (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t addr, uint_fast32_t len, const void * restrict src);

//
// MESSAGE-RELATED DECLARATIONS & DEFINITIONS
//

// message length restriction values
//

#define PKTLAB_MREAD_MAX            UINT32_C(0x10000)
#define PKTLAB_NDATA_MAX            UINT32_C(0x10000)

// message family and proto constants
//

/**
 * @def PKTLAB_IP4_PROTO
 * @brief Defined IPv4 protocol family value.
 *
 * For setting the "family" fields in the pktlab_message struct
 */
/**
 * @def PKTLAB_IP6_PROTO
 * @brief Defined IPv6 protocol family value.
 *
 * For setting the "family" fields in the pktlab_message struct
 */
#define PKTLAB_IP4_PROTO            0x4
#define PKTLAB_IP6_PROTO            0x6

/**
 * @def PKTLAB_RAW_PROTO
 * @brief Defined raw socket protocol value.
 *
 * For setting the "proto" fields in the pktlab_message struct
 */
/**
 * @def PKTLAB_TCP_PROTO
 * @brief Defined TCP socket protocol value.
 *
 * For setting the "proto" fields in the pktlab_message struct
 */
/**
 * @def PKTLAB_UDP_PROTO
 * @brief Defined UDP socket protocol value.
 *
 * For setting the "proto" fields in the pktlab_message struct
 */
#define PKTLAB_RAW_PROTO            0x00
#define PKTLAB_TCP_PROTO            0x06
#define PKTLAB_UDP_PROTO            0x11

// nctl command type
//

/**
 * @def PKTLAB_NCTL_TCP_FIN
 * @brief Defined nctl TCP fin command.
 *
 * For setting the nctl message "command" field in the pktlab_message struct. \n
 * The command requests the endpoint to shutdown the writing end of some TCP socket.
 */
#define PKTLAB_NCTL_TCP_FIN         0x1

// nstat code values
//

/**
 * @def PKTLAB_TCPEV_ESTABLISHED
 * @brief Defined nstat code value - TCP connection established event.
 */
/**
 * @def PKTLAB_TCPEV_RESET
 * @brief Defined nstat code value - TCP connection reset event.
 */
/**
 * @def PKTLAB_TCPEV_TIMEOUT
 * @brief Defined nstat code value - TCP connection timeout event.
 */
/**
 * @def PKTLAB_TCPEV_PEERCLOSED
 * @brief Defined nstat code value - TCP connection peer closed event.
 */
/**
 * @def PKTLAB_TCPEV_UNKNOWN
 * @brief Defined nstat code value - TCP connection unknown event.
 */
#define PKTLAB_TCPEV_ESTABLISHED    0x0
#define PKTLAB_TCPEV_RESET          0x1
#define PKTLAB_TCPEV_TIMEOUT        0x2
#define PKTLAB_TCPEV_PEERCLOSED     0x3
#define PKTLAB_TCPEV_UNKNOWN        0xFF

// message type values
//

/**
 * @enum pktlab_message_type
 * @brief pktlab defined message types.
 *
 * For setting the "type" field in the pktlab_message struct.
 */
enum pktlab_message_type {
	PKTLAB_UNDEF_MESSAGE        = 0x00,

	// Requests 0x20 - 0x3F
	PKTLAB_CDATA_MESSAGE        = 0x20,
	PKTLAB_START_MESSAGE        = 0x21,
	PKTLAB_END_MESSAGE          = 0x22,
	PKTLAB_YIELD_MESSAGE        = 0X23,
	PKTLAB_CONT_MESSAGE         = 0X24,

	PKTLAB_MREAD_MESSAGE        = 0x28,
	PKTLAB_MWRITE_MESSAGE       = 0x29,
	PKTLAB_NOPEN_MESSAGE        = 0x2A,
	PKTLAB_NCLOSE_MESSAGE       = 0x2B,
	PKTLAB_NSEND_MESSAGE        = 0x2C,
	PKTLAB_NCAP_MESSAGE         = 0x2D,
	PKTLAB_NCTL_MESSAGE         = 0x2E,

	// publisher to broker request
	PKTLAB_XCERT_MESSAGE        = 0x30,
	PKTLAB_XPUB_MESSAGE         = 0x31,

	// endpoint to broker request
	PKTLAB_XSUB_MESSAGE         = 0x38,

	// Responses 0x40 - 0x5F
	PKTLAB_RESULT_MESSAGE       = 0x40,
	PKTLAB_MDATA_MESSAGE        = 0x41,

	// Notifications 0x60 - 0x7F
	PKTLAB_NTAG_MESSAGE         = 0x60,
	PKTLAB_NSTAT_MESSAGE        = 0x61,
	PKTLAB_NDATA_MESSAGE        = 0x62,
	PKTLAB_NDROP_MESSAGE        = 0x63,

	PKTLAB_SUSPD_MESSAGE        = 0x68,
	PKTLAB_RESUMD_MESSAGE       = 0x69,

	PKTLAB_XNOTIFY_MESSAGE      = 0x70,

	// Proxy requests 0x80 - 0x8F
	PKTLAB_XREG_MESSAGE         = 0x80,

	// Private Use 0x90 - 0xff
};

// result message errid values
//

/**
 * @enum pktlab_status
 * @brief pktlab defined errid values.
 *
 * For setting the "errid" field in the pktlab_message struct.
 */
enum pktlab_status {
	PKTLAB_SUCCESS          = 0,

	PKTLAB_ECTLBADMSG       = 0x10,
	PKTLAB_ECTLNOTSUP       = 0x11,

	PKTLAB_ECRTNOMATCH      = 0x20,
	PKTLAB_ECRTATTACH       = 0x21,
	PKTLAB_ECRTBADFRM       = 0x22,
	PKTLAB_ECRTNOSPACE      = 0x23,

	PKTLAB_ESYSNOBUFS       = 0x30,
	PKTLAB_ESYSNOPERM       = 0x31,
	PKTLAB_ESKTINUSE        = 0x32,
	PKTLAB_ESKTNOTOPEN      = 0x33,
	PKTLAB_ESKTNOPRFAM      = 0x34,
	PKTLAB_ESKTNOPROTO      = 0x35,
	PKTLAB_ESKTNOADDR       = 0x36,
	PKTLAB_ESKTNOMATCH      = 0x37,
	PKTLAB_ESKTBADFILT      = 0x38,

	PKTLAB_ETCPNOPORT       = 0x40,
	PKTLAB_ETCPNOSEND       = 0x41,
	PKTLAB_EUDPNOPORT       = 0x42,

	PKTLAB_EPUBBADCHL       = 0x50,
	PKTLAB_EPUBBADCHN       = 0x51,
	PKTLAB_EPUBBADADDR      = 0x52,
	PKTLAB_EPUBBADPR        = 0x53,
	PKTLAB_EPUBBADXD        = 0x54,

	PKTLAB_ESUBBADCHL       = 0x60,
	PKTLAB_ESUBBADCHN       = 0x61,
	PKTLAB_ESUBBADDA        = 0x62,

	PKTLAB_EUNKFAULT        = 0xFFFF
};

// message value structure
//

/**
 * @struct pktlab_message
 * @brief Structure for storing the decoded form of pktlab messages.
 *
 * The pktlab_message struct should be set by:
 * -# Setting the msg type in the "type" field.
 * -# Setting the struct within the union based on the msg type.
 *    E.g. For PKTLAB_NOPEN_MESSAGE, one should set "type" to PKTLAB_NOPEN_MESSAGE,
 *    and fill out the "nopen" struct with the correct values.
 *    See the pktlab protocol documentation on struct value requirements for a msg type.
 */
struct pktlab_message {
	enum pktlab_message_type type;

	union {
		struct {
			const void * ptr;
			uint32_t len;
			bool malformed;
		} raw;

		struct {
			uint32_t hint;
			const void* data;
			uint32_t len;
		} cdata;

		struct {
		} start;

		struct {
		} end;

		struct {
			pktlab_time_t rhint;
		} yield;

		struct {
		} cont;

		struct {
			uint16_t errid;
		} result;

		struct {
			uint32_t addr, len;
			const void * ptr;
		} mdata;

		struct {
			uint32_t addr, len;
		} mread;

		struct {
			uint32_t addr, len;
			const void * ptr;
		} mwrite;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			uint32_t rbufsz;

			uint8_t laddrlen;
			uint8_t lportlen;
			uint8_t raddrlen;
			uint8_t rportlen;
			const void* laddrptr;
			const void* lportptr;
			const void* raddrptr;
			const void* rportptr;
		} nopen;

		struct {
			uint8_t sktid;
		} nclose;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t time;
			uint16_t tag;
			union {
				struct {
					uint8_t raddrlen;
					const void* raddrptr;
					uint8_t rportlen;
					const void* rportptr;
				} udp;
			};
			uint32_t len;
			const void * ptr;
		} nsend;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t endtime;
			union {
				struct {
					uint8_t ftype;
					const void* filter;
					uint32_t filterlen;
				} raw;
			};
		} ncap;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t time;
			union {
				struct {
					uint8_t command;
				} tcp;
			};
		} nctl;

		struct {
			uint8_t sktid;
			uint16_t tag;
			pktlab_time_t time;
			uint16_t errid;
		} ntag;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t time;
			uint8_t code;
			union {
				struct {
					uint8_t raddrlen;
					const void* raddrptr;
					uint8_t rportlen;
					const void* rportptr;
				} tcp_established;
			};
		} nstat;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t time;
			union {
				struct {
					uint8_t raddrlen;
					const void* raddrptr;
					uint8_t rportlen;
					const void* rportptr;
				} udp;
			};
			const void * ptr;
			uint32_t len;
		} ndata;

		struct {
			uint8_t sktid;
			uint8_t family;
			uint8_t proto;
			pktlab_time_t tfirst, tlast;
			uint32_t unitcnt, bytecnt;
		} ndrop;

		struct {
			const void * derptr;
			uint32_t derlen;
		} xcert;

		struct {
			const void * chlistptr;
			uint32_t chlistlen;
			const void * eopkey;
			const void * xdescrptr;
			uint32_t xdescrlen;
		} xpub;

		struct {
			const void * chlistptr;
			uint32_t chlistlen;
			const void * eopkey;
			const void * dattrptr;
			uint32_t dattrlen;
		} xsub;

		struct {
		} suspd;

		struct {
		} resumd;

		struct {
			const void * channelptr;
			uint8_t channellen;
			const void * xdescrptr;
			uint32_t xdescrlen;
		} xnotify;

		struct {
			const void * snikeyptr;
			uint32_t snikeylen;
		} xreg;
	};
};

// message encoding/decoding utilities
//

/**
 * @def PKTLAB_HLEN
 * @brief Encoded pktlab message header length.
 */
#define PKTLAB_HLEN          4

/**
 * @brief Decode pktlab message.
 * @param[out] msg Pointer to a struct for returning decoded message content.
 * @param[in]  ptr Encoded message bytes.
 * @param[in]  len Length of encoded message bytes.
 * @return         The number of bytes in ptr used for decoding.
 *                 0 if not enough bytes supplied.
 *                 msg is set when > 0 bytes are used.
 *
 * - Note pktlab_decode_message only checks for message well-formedness as defined in the pktlab protocol documentation.
 * - When receiving pktlab messages from a socket, rather than directly calling this function with the received bytes, it is recommended to use the pktctrl module (pktctrl_read_message()) instead.
 * - Note the msg fields rely on the passed ptr. If the content in ptr is changed after the call to pktlab_decode_message(), the msg fields may change as well.
 */
extern size_t pktlab_decode_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, size_t len);

/**
 * @def PKTLAB_ENCODE_IOVCNT
 * @brief Minimum required iovec elements for pktlab_encode_message().
 */
#define PKTLAB_ENCODE_IOVCNT 5
/**
 * @def PKTLAB_ENCODE_BUFSZ
 * @brief Minimum required buffer size for pktlab_encode_message().
 */
#define PKTLAB_ENCODE_BUFSZ  (PKTLAB_HLEN+32) // note: ndrop msg is 27 bytes long

/**
 * @brief Encode pktlab message.
 * @param[in]  msg Pointer to a fields-set msg struct for message encoding.
 * @param[out] buf Buffer of at least PKTLAB_ENCODE_BUFSZ size for msg encoding.
 * @param[out] iov Pointer to an array of PKTLAB_ENCODE_IOVCNT iovec elements for msg encoding.
 * @return         The number of iovec elements used in iov to encode msg.
 *                 < 0 if encoding failed.
 *
 * - Note for how to fill the msg struct, refer to the pktlab protocol documentation.
 * - In case of successful encoding, one can use writev() in sys/uio.h to send the encoded bytes.
 * - When sending pktlab messages via a socket, rather than directly calling this function and afterwards writev() to send the encoded bytes, it is recommended to use the pktctrl module (pktctrl_write_message()) instead.
 */
extern int pktlab_encode_message (
	const struct pktlab_message * restrict msg,
	void * restrict buf, struct iovec * restrict iov);

// Functions of the form create_XXX_message create a message of the given
// type with the given parameters. They combine memory allocation and
// pktlab_message structure initialization into one call.

/**
 * @brief Get fields-set pktlab result message.
 * @param[in] status Result message errid.
 * @return           An allocated pktlab result message with errid set.
 *
 * - The returned message pointer should be freed with free() in stdlib.h.
 */
extern struct pktlab_message * pktlab_create_result_message(enum pktlab_status status);

//
// READER-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @struct pktlab_reader
 * @brief pktlab reader opaque struct.
 */
struct pktlab_reader; // opaque

/**
 * @brief Function pointer type for reader read function.
 *
 * - The expected behavior of a pktlab_read_t function: per function call with valid input, the function should either (1) read in x \in [1, buflen] consecutive bytes and place them in buf in order from the start of buf (returning the number of bytes read), (2) return 0 for EOF, or (3) return a negative value for other failures (potentially setting errno). If no byte is read due to the system being busy (e.g. read would block), the function should set errno to EAGAIN or EWOULDBLOCK. If no byte is read due to signal interruption, the function should set errno to EINTR.
 */
typedef ssize_t (*pktlab_read_t) (void * aux, void * buf, size_t buflen);

/**
 * @brief Get initialized pktlab reader struct.
 * @param[in] read Read function to use for this reader.
 * @param[in] aux  Auxiliary information needed by read.
 * @return         An allocated and initialized pktlab reader struct.
 *
 * - Note to use read() in unistd.h with reader, one will need to wrap read() so that the fd is taken in via a pointer to an int variable storing the fd instead.
 * - The returned allocated struct should be freed with pktlab_close_reader().
 * - Normally, one would use the pktctrl module instead to read/recv pktlab messages rather than using the pktlab reader utilities.
 */
extern struct pktlab_reader * pktlab_create_reader(pktlab_read_t read, void * aux);
/**
 * @brief Close and free pktlab reader struct.
 * @param[in,out] r Allocated pktlab reader struct to free.
 *
 * - Note reader aux (passed in during pktlab_create_reader()) is not freed or closed.
 */
extern void pktlab_close_reader(struct pktlab_reader * r);
/**
 * @brief Get pktlab reader struct aux information.
 * @param[in] r Initialized pktlab reader struct to get aux from.
 * @return      Reader aux (passed in during pktlab_create_reader()).
 */
extern void * pktlab_reader_readaux(const struct pktlab_reader * r);

/**
 * @brief pktlab reader read message.
 * @param[in,out] r      Initialized pktlab reader struct.
 * @param[out]    msgptr Pointer to return an allocated msg that was read.
 * @return
 *  - When msgptr is not NULL:
 *   -# 1 for successful read with decoded read msg returned via msgptr. If EOF is encountered, a NULL is returned via msgptr.
 *   -# 0 for try again later.
 *   -# < 0 for read errors. Check errno for more information.
 *  - When msgptr is NULL:
 *   -# 1 for there exists new msg available for reading.
 *   -# 0 for not enough data for a new msg.
 *   -# < 0 for reader is in error state.
 *
 * - To obtain an initialized pktlab reader struct, see pktlab_create_reader().
 * - Note whenever < 0 is returned, r should not be called with msgptr being non-NULL afterwards.
 */
extern int pktlab_read_message (
	struct pktlab_reader * restrict r,
	struct pktlab_message ** restrict msgptr);

//
// WRITER-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @struct pktlab_writer
 * @brief pktlab writer opaque struct.
 */
struct pktlab_writer; // opaque

/**
 * @brief Function pointer type for writer write function.
 *
 * - The expected behavior of a pktlab_write_t function: per function call with valid input, the function should either send out x \in [1, nbyte] bytes stored in buf in order from the start of buf (returning the number of bytes sent) or fail with a negative return value (potentially setting errno). If no byte is sent due to the system being busy (e.g. write would block), the function should set errno to EAGAIN or EWOULDBLOCK. If no byte is sent due to signal interruption, the function should set errno to EINTR.
 */
typedef ssize_t (*pktlab_write_t) (void * aux, const void * buf, size_t nbyte);

/**
 * @brief Get initialized pktlab writer struct.
 * @param[in] write Write function to use for this writer.
 * @param[in] aux   Auxiliary information needed by write.
 * @return          An allocated and initialized pktlab writer struct.
 *
 * - Note to use write() in unistd.h with writer, one will need to wrap write() so that the fd is taken in via a pointer to an int variable storing the fd instead.
 * - The returned allocated struct should be freed with pktlab_close_writer().
 * - Normally, one would use the pktctrl module instead to write/send pktlab messages rather than using the pktlab writer utilities.
 */
extern struct pktlab_writer * pktlab_create_writer(pktlab_write_t write, void * aux);
/**
 * @brief Close and free pktlab writer struct.
 * @param[in,out] w Allocated pktlab writer struct to free.
 *
 * - Note writer aux (passed in during pktlab_create_writer()) is not freed or closed.
 */
extern void pktlab_close_writer(struct pktlab_writer * w);
/**
 * @brief Flush pktlab writer internal buffer.
 * @param[in,out] w Initialized pktlab writer struct to be flushed.
 * @return
 *  -# If success, return the number of bytes flushed out of writer buffer (can be 0).
 *  -# < 0 for write errors. Check errno for more information.
 *
 * - Note it is possible for pktlab_flush_writer() to only flush a portion of the internally buffered bytes. To ensure all internally buffered bytes are flushed, one should use pktlab_flush_writer() in conjunction with pktlab_writer_unsent() to check whether after a flush there are no internally buffered bytes left.
 * - w should be closed afterwards if pktlab_flush_writer() failed with an error.
 */
extern int pktlab_flush_writer(struct pktlab_writer * w);
/**
 * @brief Get writer internal buffered content length.
 * @param[in] w Initialized pktlab writer struct.
 * @return      The number of buffered bytes in w.
 *
 * - pktlab_writer_unsent() is often used in conjunction with pktlab_flush_writer() to flush out all writer-internally buffered bytes. See pktlab_flush_writer() for more information.
 */
extern size_t pktlab_writer_unsent(const struct pktlab_writer * w);

/**
 * @brief Get pktlab writer struct aux information.
 * @param[in] w pktlab writer struct to get aux from.
 * @return      Writer aux (passed in during pktlab_create_writer()).
 */
extern void * pktlab_writer_writeaux(const struct pktlab_writer * w);

/**
 * @brief pktlab writer write message.
 * @param[in,out] w   Initialized pktlab writer struct.
 * @param[in]     msg Pointer to an initialized msg struct.
 * @return
 *  -# 1 for successful encoding and buffering of msg (some message bytes have been sent).
 *  -# 0 for try again later (message bytes are not buffered).
 *  -# < 0 for write errors. Check errno for more information.
 *
 * - To obtain an initialized pktlab writer struct, see pktlab_create_writer().
 * - Note even though the function signature is similar to pktlab_read_message(), msg must NOT be NULL.
 * - pktlab_write_message() always first tries to flush any buffered bytes within the writer before working on sending the new message bytes. It is therefore fine to perform a consecutive call of pktlab_write_message() on a series of messages, while only stopping when pktlab_write_message() returns <= 0.
 * - Note in case there isn't any other message to be sent, to flush the internal buffered unsent bytes and ensure that all message bytes are sent, one can use a combination of pktlab_flush_writer() and pktlab_writer_unsent() to make sure buffered bytes are flushed.
 * - w should be closed afterwards if pktlab_write_message() failed with an error.
 */
extern int pktlab_write_message (
	struct pktlab_writer * restrict w,
	const struct pktlab_message * restrict msg);

//
// MESSAGE-FORMATING FUNCTION DECLARATIONS
//

// TODO: formating support
// The pktlab_format_message function formats a message as an ASCII string.
// On entry, buf must be a pointer to a buffer of size bufsz and msg much
// be a valid message. On return, buf will contain up to bufsz bytes of the
// textual representation of the message. The string is terminating with a
// '\0' character (unless bufsz == 0). The number of characters that would
// be necessary to represent the message completely (excluding the
// terminaing '\0' character) is returned.

// extern int pktlab_format_message (
// 	char * restrict buf, size_t bufsz,
// 	const struct pktlab_message * restrict msg);

// extern int pktlab_parse_message (
// 	const char * restrict str,
// 	struct pktlab_message * restrict msg, void ** restrict data);

// extern int pktlab_print_message (
// 	FILE * restrict file, const struct pktlab_message * restrict msg);

// extern int pktlab_scan_message (
// 	FILE * restrict file,
// 	struct pktlab_message * restrict msg, void ** restrict data);

// extern const char * pktlab_status_name(enum pktlab_status status);
// extern const char * pktlab_status_descr(enum pktlab_status status);
// extern const char * pktlab_msgtype_name(enum pktlab_message_type type);

/**
 * @brief Get text description of pktlab endpoint skt state.
 * @param[in] state pktlab endpoint skt state.
 * @return          Pointer to the text description string for pktlab endpoint skt state.
 */
extern const char * pktlab_sktstate_name(enum pktlab_socket_state state);

//
// KEY-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @def PKTLAB_PUBLICKEY_LEN
 * @brief Raw public key length for pktlab keys in bytes.
 *
 * I.e. Raw Ed25519 public key length.
 */
#define PKTLAB_PUBLICKEY_LEN       32
/**
 * @def PKTLAB_PRIVATEKEY_LEN
 * @brief Raw private key length for pktlab keys in bytes.
 *
 * I.e. Raw Ed25519 private key length.
 */
#define PKTLAB_PRIVATEKEY_LEN      32
/**
 * @def PKTLAB_KEYID_LEN
 * @brief Key identifier length for pktlab keys in bytes.
 *
 * The key identifier for a pktlab key is the SHA-256 checksum of the pktlab key raw public key. PKTLAB_KEYID_LEN is thus the length of a SHA-256 checksum.
 */
#define PKTLAB_KEYID_LEN           PKTLAB_SHA256_DIGEST_LEN
/**
 * @def PKTLAB_SIGNATURE_LEN
 * @brief Raw signature length for pktlab keys in bytes.
 *
 * I.e. Raw Ed25519 signature length.
 */
#define PKTLAB_SIGNATURE_LEN       PKTLAB_ED25519_SIG_LEN

/**
 * @struct pktlab_publickey
 * @brief pktlab public key opaque struct.
 *
 * We abbreviate pktlab key public key to pktlab public key for brevity.
 */
struct pktlab_publickey;      // opaque

/**
 * @brief Allocate initialized pktlab public key struct.
 * @return Pointer to an allocated initialized pktlab public key struct.
 *
 * - The allocated pktlab public key struct should be freed with pktlab_cleanup_publickey().
 */
extern struct pktlab_publickey * pktlab_create_publickey(void);
/**
 * @brief Load pktlab public key struct via PEM-encoded public key char array.
 * @param[in]     pem    PEM-encoded public key char array.
 * @param[in]     pemlen PEM-encoded public key char array length.
 * @param[in,out] k      Pointer to an initialized pktlab public key struct.
 * @return               0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab public key struct, see pktlab_create_publickey().
 * - Note k remains initialized if pktlab_load_publickey_pem() failed;
 * - pktlab_load_publickey_pem() should NOT be called on an already loaded pktlab public key struct.
 * - The underlying content being PEM-encoded should be an Ed25519 public key in DER-encoded SubjectPublicKeyInfo format.
 */
extern int pktlab_load_publickey_pem (
	const char * pem, uint_fast32_t pemlen,
	struct pktlab_publickey * k);
/**
 * @brief Load pktlab public key struct via raw SubjectPublicKeyInfo byte array.
 * @param[in]     der    Raw SubjectPublicKeyInfo byte array.
 * @param[in]     derlen Raw SubjectPublicKeyInfo byte array length.
 * @param[in,out] k      Pointer to an initialized pktlab public key struct.
 * @return               0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab public key struct, see pktlab_create_publickey().
 * - Note k remains initialized if pktlab_load_publickey_der() failed;
 * - pktlab_load_publickey_der() should NOT be called on an already loaded pktlab public key struct.
 * - The raw SubjectPublicKeyInfo byte array should be an Ed25519 public key in DER-encoded SubjectPublicKeyInfo format.
 */
extern int pktlab_load_publickey_der (
	const uint8_t * der, uint_fast32_t derlen,
	struct pktlab_publickey * k);
/**
 * @brief Load pktlab public key struct via raw public key byte array.
 * @param[in]     bytes Raw public key byte array.
 * @param[in]     len   Raw public key byte array length.
 * @param[in,out] k     Pointer to an initialized pktlab public key struct.
 * @return              0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab public key struct, see pktlab_create_publickey().
 * - Note k remains initialized if pktlab_load_publickey_raw() failed;
 * - pktlab_load_publickey_raw() should NOT be called on an already loaded pktlab public key struct.
 * - Normally, len should be equal to PKTLAB_PUBLICKEY_LEN.
 */
extern int pktlab_load_publickey_raw (
	const uint8_t * bytes, uint_fast32_t len,
	struct pktlab_publickey * k);
/**
 * @brief Free an allocated pktlab public key struct.
 * @param[in,out] k Allocated pktlab public key struct to free.
 * @return          0 if success. < 0 if failed.
 *
 * - Do not call pktlab_cleanup_publickey() again if failed.
 */
extern int pktlab_cleanup_publickey(struct pktlab_publickey * k);
/**
 * @brief Get raw public key byte array from loaded pktlab public key struct.
 * @param[in]  k      Pointer to a loaded pktlab public key struct.
 * @param[out] buf    Pointer to buffer for storing raw public key bytes.
 * @param[in]  buflen Size of buffer, should be at least PKTLAB_PUBLICKEY_LEN large.
 * @return            0 if success. < 0 if failed.
 */
extern int pktlab_get_publickey_bytes (
	const struct pktlab_publickey * k,
	void * buf, uint_fast32_t buflen);

/**
 * @brief Get key identifier for a loaded pktlab public key struct.
 * @param[in]  k      Pointer to a loaded pktlab public key struct.
 * @param[out] buf    Pointer to buffer for storing computed key identifier.
 * @param[in]  buflen Size of buffer, should be at least PKTLAB_KEYID_LEN large.
 * @return            0 if success. < 0 if failed.
 */
extern int pktlab_get_key_identifier (
	const struct pktlab_publickey * k,
	void * buf, uint_fast32_t buflen);

/**
 * @struct pktlab_privatekey
 * @brief pktlab private key opaque struct.
 *
 * We abbreviate pktlab key private key to pktlab private key for brevity.
 */
struct pktlab_privatekey;     // opaque

/**
 * @brief Allocate initialized pktlab private key struct.
 * @return Pointer to an allocated initialized pktlab private key struct.
 *
 * - The allocated pktlab private key struct should be freed with pktlab_cleanup_privatekey().
 */
extern struct pktlab_privatekey * pktlab_create_privatekey(void);
/**
 * @brief Load pktlab private key struct via PEM-encoded private key char array.
 * @param[in]     pem        Pointer to PEM-encoded private key char array.
 * @param[in]     pemlen     PEM-encoded private key char array length.
 * @param[in]     passphrase Pointer to '\0'-terminated passphrase string if the loaded private key is encrypted. For unencrypted private key one should pass in NULL.
 * @param[in,out] k          Pointer to an initialized pktlab private key struct.
 * @return                   0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab private key struct, see pktlab_create_privatekey().
 * - Note k remains initialized if pktlab_load_privatekey_pem() failed;
 * - pktlab_load_privatekey_pem() should NOT be called on an already loaded pktlab private key struct.
 * - The underlying content being PEM-encoded should be an Ed25519 private key in DER-encoded PKCS8 format.
 */
extern int pktlab_load_privatekey_pem (
	const char * pem, uint_fast32_t pemlen,
	const char * passphrase, struct pktlab_privatekey * k);
/**
 * @brief Load pktlab private key struct via raw PKCS8 byte array.
 * @param[in]     der        Pointer to the raw PKCS8 byte array.
 * @param[in]     derlen     Raw PKCS8 byte array length.
 * @param[in]     passphrase Pointer to '\0'-terminated passphrase string if the loaded private key is encrypted. For unencrypted private key one should pass in NULL.
 * @param[in,out] k          Pointer to an initialized pktlab private key struct.
 * @return                   0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab private key struct, see pktlab_create_privatekey().
 * - Note k remains initialized if pktlab_load_privatekey_der() failed;
 * - pktlab_load_privatekey_der() should NOT be called on an already loaded pktlab private key struct.
 * - The raw PKCS8 byte array should be an Ed25519 private key in DER-encoded PKCS8 format.
 */
extern int pktlab_load_privatekey_der (
	const uint8_t * der, uint_fast32_t derlen,
	const char * passphrase, struct pktlab_privatekey * k);
/**
 * @brief Load pktlab private key struct via raw private key byte array.
 * @param[in]     bytes Pointer to the raw private key byte array.
 * @param[in]     len   Raw private key byte array length.
 * @param[in,out] k     Pointer to an initialized pktlab private key struct.
 * @return              0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab private key struct, see pktlab_create_privatekey().
 * - Note k remains initialized if pktlab_load_privatekey_raw() failed;
 * - pktlab_load_privatekey_raw() should NOT be called on an already loaded pktlab private key struct.
 * - Normally, len should be equal to PKTLAB_PRIVATEKEY_LEN.
 */
extern int pktlab_load_privatekey_raw (
	const uint8_t * bytes, uint_fast32_t len,
	struct pktlab_privatekey * k);
/**
 * @brief Free an allocated pktlab private key struct.
 * @param[in,out] k Pointer to an allocated pktlab private key struct to free.
 * @return          0 if success. < 0 if failed.
 *
 * - Do not call pktlab_cleanup_privatekey() again if failed.
 */
extern int pktlab_cleanup_privatekey(struct pktlab_privatekey * k);
/**
 * @brief Get raw private key byte array from loaded pktlab private key struct.
 * @param[in]  k      Pointer to a loaded pktlab private key struct.
 * @param[out] buf    Pointer to buffer for storing raw private key bytes.
 * @param[in]  buflen Size of buffer, should be at least PKTLAB_PRIVATEKEY_LEN large.
 * @return            0 if success. < 0 if failed.
 */
extern int pktlab_get_privatekey_bytes (
	const struct pktlab_privatekey * k,
	void * buf, uint_fast32_t buflen);

/**
 * @brief Get loaded pktlab public key struct from loaded pktlab private key struct.
 * @param[in] k Pointer to a loaded pktlab private key struct.
 * @return      Pointer to an allocated loaded pktlab public key struct if success. Otherwise NULL.
 */
extern struct pktlab_publickey * pktlab_get_publickey_from_privatekey (
	const struct pktlab_privatekey * k);

//
// CERTIFICATE-RELATED DECLARATIONS & DEFINITIONS
//

/**
 * @enum pktlab_cert_type
 * @brief pktlab defined certificate types.
 */
enum pktlab_cert_type {
	PKTLAB_CERT_SUBCMD    = 0,
	PKTLAB_CERT_PUBCMD    = 1,
	PKTLAB_CERT_EXPPRIV   = 2,
	PKTLAB_CERT_DELPRIV   = 3,
	PKTLAB_CERT_AGENT     = 4,
	PKTLAB_CERT_UNKNOWN   = 127
};

/**
 * @def PKTLAB_DEL_TYPE_EXPPRIV
 * @brief Defined delegated privilege type value - experiment privilege.
 */
/**
 * @def PKTLAB_DEL_TYPE_REPPRIV
 * @brief Defined delegated privilege type value - representation privilege.
 */
#define PKTLAB_DEL_TYPE_EXPPRIV       0x1
#define PKTLAB_DEL_TYPE_REPPRIV       0x2

/**
 * @def PKTLAB_FILTER_DIGEST_LEN
 * @brief pktlab filter program digest length.
 *
 * In pktlab, the filter program digest of some filter program is the SHA256 hash of the filter program bytes.
 */
/**
 * @def PKTLAB_MONITOR_DIGEST_LEN
 * @brief pktlab monitor program digest length.
 *
 * In pktlab, the monitor program digest of some monitor program is the SHA256 hash of the monitor program bytes.
 */
#define PKTLAB_FILTER_DIGEST_LEN   PKTLAB_SHA256_DIGEST_LEN
#define PKTLAB_MONITOR_DIGEST_LEN  PKTLAB_SHA256_DIGEST_LEN

/**
 * @enum pktlab_decode_rst
 * @brief pktlab certificate decoding result values.
 *
 * Returned by pktlab_decode_certificate() to indicate pktlab certificate decoding result.
 */
enum pktlab_decode_rst {
	PKTLAB_DECODE_SUCCESS              =  0,  /**< Success. */
	PKTLAB_DECODE_INVAL                =  1,  /**< Bad arguments passed to decoding function */
	PKTLAB_DECODE_BAD_SIGALG           =  2,  /**< Not using Ed25519 signature algorithm. Note this is used for both signed and unsigned sigalg.  */
	PKTLAB_DECODE_BAD_SIGNATURE        =  3,  /**< Bad cert signature. */
	PKTLAB_DECODE_BAD_X509_VER         =  4,  /**< Bad X509 ver. */
	PKTLAB_DECODE_USING_UNUSED_FIELD   =  5,  /**< Cert contains fields that should not be used. */
	PKTLAB_DECODE_BAD_CERT_TYPE        =  6,  /**< Bad cert type. */
	PKTLAB_DECODE_BAD_KEYUSAGE         =  7,  /**< Bad keyusage. */
	PKTLAB_DECODE_BAD_SERIAL           =  8,  /**< Bad serial. */
	PKTLAB_DECODE_BAD_VALIDITY         =  9,  /**< Bad validity (i.e. not_before/not_after). */
	PKTLAB_DECODE_BAD_SUBJ_PUBKEY      = 10,  /**< Bad subject public key. */
	PKTLAB_DECODE_BAD_AID              = 11,  /**< Bad authority key identifier. */
	PKTLAB_DECODE_BAD_SID              = 12,  /**< Bad subject key identifier. */
	PKTLAB_DECODE_BAD_BC               = 13,  /**< Bad basic constraints. */
	PKTLAB_DECODE_BAD_CERT_DESC        = 14,  /**< Bad pktlab certificate description. */
	PKTLAB_DECODE_BAD_PRIORITY         = 15,  /**< Bad pktlab priority string. */
	PKTLAB_DECODE_BAD_FILTER_DIGESTS   = 16,  /**< Bad pktlab filter digests. */
	PKTLAB_DECODE_BAD_MONITOR_DIGESTS  = 17,  /**< Bad pktlab monitor digests. */
	PKTLAB_DECODE_BAD_DEL_TYPE         = 18,  /**< Bad pktlab delegation type. */
	PKTLAB_DECODE_UNKNOWN_FAULT        = 127  /**< Unknwon error during decoding. */
};

/**
 * @struct pktlab_cert_info
 * @brief Structure for storing decoded pktlab certificate information.
 */
struct pktlab_cert_info {
	enum pktlab_cert_type cert_type;

	uint8_t * serialno;
	uint32_t serialno_len;

	pktlab_time_t valid_not_before;
	pktlab_time_t valid_not_after;

	uint8_t publickey[PKTLAB_PUBLICKEY_LEN];

	uint8_t authority_key_id[PKTLAB_KEYID_LEN];
	uint8_t subject_key_id[PKTLAB_KEYID_LEN];

	char * cert_desc;

	union {
		struct {
			char * priority;
			uint8_t * filter_digests;
			uint8_t * monitor_digests;
			uint_fast32_t ftcnt;
			uint_fast32_t mtcnt;
			int_fast32_t pathlen;
		} exppriv;

		struct {
			char * priority;
			uint8_t * filter_digests;
			uint8_t * monitor_digests;
			uint_fast32_t ftcnt;
			uint_fast32_t mtcnt;
			int_fast32_t pathlen;
			uint8_t del_type;
		} delpriv;

		struct {
			char * priority;
		} pubcmd;

		// no subcmd struct
		// no agent struct
	};
};

// TODO: register OID with IANA at https://pen.iana.org/pen/PenApplication.page; also fix this
// pktlab extension OIDs
#define PKTLAB_EXT_CERT_TYPE           "1.2.3.1"
#define PKTLAB_EXT_CERT_DESCRIPTION    "1.2.3.3"
#define PKTLAB_EXT_FILTER_DIGESTS      "1.2.3.5"
#define PKTLAB_EXT_MONITOR_DIGESTS     "1.2.3.6"
#define PKTLAB_EXT_PRIORITY            "1.2.3.7"
#define PKTLAB_EXT_DEL_TYPE            "1.2.3.8"

// pktlab certificate type string (present in cert)
#define PKTLAB_CERTTYPE_STR_SUBCMD     "subcmd"
#define PKTLAB_CERTTYPE_STR_PUBCMD     "pubcmd"
#define PKTLAB_CERTTYPE_STR_EXPPRIV    "exppriv"
#define PKTLAB_CERTTYPE_STR_DELPRIV    "delpriv"
#define PKTLAB_CERTTYPE_STR_AGENT      "agent"
#define PKTLAB_CERTTYPE_STR_UNKNOWN    "unknown"

// utilities for loading and decoding pktlab certificates
//

/**
 * @struct pktlab_certificate
 * @brief pktlab certificate opaque struct.
 */
struct pktlab_certificate; // opaque

/**
 * @brief Allocate initialized pktlab certificate struct.
 * @return Pointer to an allocated initialized pktlab certificate struct.
 *
 * - The allocated pktlab certificate struct should be freed with pktlab_cleanup_cert().
 */
extern struct pktlab_certificate * pktlab_create_cert(void);

/**
 * @brief Load pktlab certificate struct via PEM-encoded pktlab certificate char array.
 * @param[in]     pem    Pointer to the PEM-encoded pktlab certificate char array.
 * @param[in]     pemlen PEM-encoded pktlab certificate char array length.
 * @param[in,out] cert   Pointer to an initialized pktlab certificate struct.
 * @return               0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab certificate struct, see pktlab_create_cert().
 * - Note cert remains initialized if pktlab_load_cert_pem() failed;
 * - pktlab_load_cert_pem() should NOT be called on an already loaded pktlab certificate struct.
 * - The underlying content being PEM-encoded should be a DER-encoded pktlab certificate.
 */
extern int pktlab_load_cert_pem (
	const char * pem, uint_fast32_t pemlen,
	struct pktlab_certificate * cert);
/**
 * @brief Load pktlab certificate struct via DER-encode pktlab certificate byte array.
 * @param[in]     der    Pointer to the DER-encode pktlab certificate byte array.
 * @param[in]     derlen DER-encode pktlab certificate byte array length.
 * @param[in,out] cert   Pointer to an initialized pktlab certificate struct.
 * @return               0 if success. < 0 if failed.
 *
 * - To obtain an initialized pktlab certificate struct, see pktlab_create_cert().
 * - Note cert remains initialized if pktlab_load_cert_der() failed;
 * - pktlab_load_cert_der() should NOT be called on an already loaded pktlab certificate struct.
 */
extern int pktlab_load_cert_der (
	const uint8_t * der, uint_fast32_t derlen,
	struct pktlab_certificate * cert);
/**
 * @brief Get DER-encoded pktlab certificate bytes from loaded pktlab certificate struct.
 * @param[in]  cert   Pointer to a loaded pktlab certificate struct.
 * @param[out] der    Pointer to return pointer to an allocated array storing DER-encoded pktlab certificate bytes.
 * @param[out] derlen Pointer to return DER-encoded pktlab certificate byte array length.
 * @return            0 if success. < 0 if failed.
 *
 * - This function is useful when setting pktlab_message struct fields for xcert messages.
 * - The returned der should be freed with free() in stdlib.h.
 */
extern int pktlab_get_cert_der (
	const struct pktlab_certificate * cert,
	void ** der, uint_fast32_t * derlen);
/**
 * @brief Decode pktlab certificate information from loaded pktlab certificate struct.
 * @param[in]  cert    Pointer to a loaded pktlab certificate struct.
 * @param[in]  signkey Pointer to a loaded pktlab public key struct for verifying certificate signature.
 * @param[out] ptr     Pointer to return an allocated struct storing decoded certificate information.
 * @return             One of the enum pktlab_decode_rst defined values representing the decoding result. Decoded certificate information struct is returned via ptr when decoding is successful.
 *
 * - The returned ptr should be freed with free() in stdlib.h.
 */
extern int pktlab_decode_certificate (
	const struct pktlab_certificate * cert,
	const struct pktlab_publickey * signkey,
	struct pktlab_cert_info ** ptr);
/**
 * @brief Verify the pktlab certificate signature.
 * @param[in] cert    Pointer to a loaded pktlab certificate struct.
 * @param[in] signkey Pointer to a loaded pktlab public key struct for verifying pktlab certificate signature.
 * @return            0 if verification success. < 0 if verification failed.
 *
 * - Note invalid input argument is considered verification failure as well.
 */
extern int pktlab_verify_certificate_signature (
	const struct pktlab_certificate * cert,
	const struct pktlab_publickey * signkey);
/**
 * @brief Free an allocated pktlab certificate struct.
 * @param[in,out] cert Pointer to an allocated pktlab certificate struct to free.
 * @return        0 if success. < 0 if failed.
 *
 * - Do not call pktlab_cleanup_cert() again if failed.
 */
extern int pktlab_cleanup_cert(struct pktlab_certificate * cert);

/**
 * @brief Get pktlab certificate type string from pktlab certificate type value.
 * @param[in] cert_type pktlab certificate type value.
 * @return              Pointer to a pktlab certificate type string or NULL if undefined cert_type value.
 */
extern const char * pktlab_cert_type_name(int cert_type);
/**
 * @brief Get pktlab certificate type value from pktlab certificate type string.
 * @param[in] name Pointer to a '\0'-terminated pktlab certificate type string.
 * @return         pktlab certificate type value corresponding to name or PKTLAB_CERT_UNKNOWN for undefined pktlab certificate type value.
 */
extern int pktlab_cert_type_name_to_id(const char * name);

/**
 * @brief Get pktlab agent certificate subject (signee) public key.
 * @param[in]  agent_cert   Pointer to a loaded pktlab agent certificate struct.
 * @param[out] agent_pubkey Pointer to buffer for storing raw subject (signee) public key. The buffer size must be at least PKTLAB_PUBLICKEY_LEN bytes large.
 * @return                  0 if success. < 0 if failed.
 */
extern int pktlab_get_agent_key (
	const struct pktlab_certificate * agent_cert,
	uint8_t * agent_pubkey);

// utilities for verifying pktlab certificate chains
//

/**
 * @enum pktlab_auth_mode
 * @brief pktlab certificate chain verification mode values.
 *
 * - PKTLAB_AUTH_AGENT is used for authentication between broker and controller/endpoint (both directions).
 */
enum pktlab_auth_mode {
	PKTLAB_CONTROLLER_AUTH_ENDPOINT  = 0,  /**< Controller authenticate endpoint case. */
	PKTLAB_ENDPOINT_AUTH_CONTROLLER  = 1,  /**< Endpoint authenticate controller case. */
	PKTLAB_AUTH_AGENT                = 2,  /**< Agent authentication case. */
	PKTLAB_NO_VERIFY                 = 127 /**< No verify case (accept all certificates and return them; USE AT YOUR OWN RISK!) */
};

/**
 * @enum pktlab_verify_rst
 * @brief pktlab certificate chain verification result values.
 *
 * Returned by pktlab_verify_cert_chain() to indicate pktlab certificate chain verification result.
 */
enum pktlab_verify_rst {
	PKTLAB_VERIFY_SUCCESS                  = 0,  /**< Success. */
	PKTLAB_VERIFY_INVAL                    = 1,  /**< Bad arguments passed to verification function. */
	PKTLAB_VERIFY_BAD_CERT                 = 2,  /**< Bad certificate passed (general). */
	PKTLAB_VERIFY_NOT_ENOUGH_CERT          = 3,  /**< Cert chain too short (i.e. passed chain shorter than minimum chain len). */
	PKTLAB_VERIFY_TOO_MANY_CERT            = 4,  /**< Cert chain too long (i.e. passed chain longer than maximum chain len). */
	PKTLAB_VERIFY_UNEXPECTED_CERT          = 5,  /**< Cert with unexpected type appearing in chain. */
	PKTLAB_VERIFY_EXPIRED_CERT             = 6,  /**< Cert expired. */
	PKTLAB_VERIFY_NO_MATCHING_SIGN_KEY     = 7,  /**< Cannot find the signing key for a cert in the cert chain. */
	PKTLAB_VERIFY_PATHLEN_EXCEEDED         = 8,  /**< Pathlen constraint for a cert exceeded in the chain. */
	PKTLAB_VERIFY_END_OF_PHASES            = 9,  /**< No more phases left in the checking process. */
	PKTLAB_VERIFY_BAD_DEL_TYPE             = 10, /**< Privilege delegation cert having incorrect delegation type. */
	PKTLAB_VERIFY_UNKNOWN_FAULT            = 127 /**< Unknown fault in verification function. */
};

/**
 * @brief Verify pktlab certificate chain.
 * @param[in]  auth_mode        Verification mode to use when verifying certificate chain. Must be one of enum pktlab_auth_mode values.
 * @param[in]  cert_ls          Array of pointers to loaded pktlab certificate structs that should be verified.
 * @param[in]  root_ls          Array of pointers to loaded pktlab public key structs that could serve as the certificate chain root.
 * @param[out] verified_cert_ls Pointer to return the verified certificate chain (in the form of an allocated array of pointers to loaded pktlab certificate structs).
 * @param[in]  certnum          The number of loaded pktlab certificate struct pointers in cert_ls.
 * @param[in]  rootnum          The number of loaded pktlab public key struct pointers in root_ls.
 * @param[out] verified_certnum Pointer to return the verified certificate chain length.
 * @param[out] used_root_indx   Pointer to return the verified certificate chain root (in the form of indx to root_ls).
 * @return                      One of the enum pktlab_verify_rst defined values representing verification result. Verified certificate chain information (verified_cert_ls/verified_certnum/used_root_indx) returned only when verification successful.
 *
 * - The returned verified_cert_ls pointer should be freed with free() in stdlib.h. Note the pointers to loaded pktlab certificate structs in verified_cert_ls are the same ones as in cert_ls (i.e. if one frees all certificate struct in cert_ls, the certificate structs in verified_cert_ls are freed as well).
 * - It is allowed to pass in NULL for cert_ls/root_ls/verified_cert_ls/verified_certnum/used_root_indx. If cert_ls/root_ls is NULL, the corresponding certnum/rootnum must be 0 and vice versa. If verified_cert_ls/verified_certnum/used_root_indx is NULL, no value is returned and no freeing is needed.
 */
extern int pktlab_verify_cert_chain (
	int auth_mode,
	struct pktlab_certificate ** cert_ls,
	struct pktlab_publickey ** root_ls,
	struct pktlab_certificate *** verified_cert_ls,
	uint_fast32_t certnum,
	uint_fast32_t rootnum,
	uint_fast32_t * verified_certnum,
	uint_fast32_t * used_root_indx);

// utilities for extracting setup info from cert chain
//

/**
 * @enum pktlab_parse_cert_chain_rst
 * @brief pktlab certificate chain parsing result values.
 *
 * Returned by pktlab_parse_endpoint_rep_cert_chain() and pktlab_parse_controller_exp_cert_chain() to indicate pktlab certificate chain parsing result.
 */
enum pktlab_parse_cert_chain_rst {
	PKTLAB_PARSE_CHAIN_SUCCESS        = 0,
	PKTLAB_PARSE_CHAIN_INVAL          = 1,
	PKTLAB_PARSE_CHAIN_BAD_CHAIN      = 2,
	PKTLAB_PARSE_CHAIN_BAD_KEY        = 3,
	PKTLAB_PARSE_CHAIN_UNKNOWN_FAULT  = 127,
};

/**
 * @brief Parse pktlab endpoint representation privilege certificate chain for subscribable channel information.
 * @param[in]  cert_ls          A potential endpoint representation privilege chain (in the form of an array of pointers to loaded pktlab certificate structs consisting) that should be parsed.
 * @param[in]  certnum          The number of loaded pktlab certificate struct pointers in cert_ls.
 * @param[in]  endpoint_key     Raw pktlab public key bytes for checking if the certificate chain leaf entity is some expected key. Should point to an array of at least PKTLAB_PUBLICKEY_LEN bytes long.
 * @param[in]  root_eop_key     A loaded pktlab public key struct for checking if the certificate chain root entity is some expected key.
 * @param[out] subable_channels Pointer to return a list of private channel IDs allowed to be subscribed based on cert_ls.
 * @param[out] channelnum       Pointer to return the number of channel IDs in subable_channels.
 * @return                      One of the enum pktlab_parse_cert_chain_rst defined values representing the parsing result. subable_channels & channelnum returned when parsing successful.
 *
 * - subable_channels is returned with all channel IDs back-to-back concatenated. Note the channel IDs returned are all PKTLAB_CHANNELID_LEN_MAX bytes long.
 * - It is allowed to pass in NULL for endpoint_key/root_eop_key. If endpoint_key/root_eop_key is NULL, the corresponding leaf/root entity check is not conducted.
 * - Note the first certificate in cert_ls is expected to be a subcmd certificate (the others need not be in order). See PPKS documentation for more information on the expected format for an endpoint representation privilege chain.
 */
extern int pktlab_parse_endpoint_rep_cert_chain (
	struct pktlab_certificate ** cert_ls,
	uint_fast32_t certnum, const uint8_t * endpoint_key,
	struct pktlab_publickey * root_eop_key,
	uint8_t ** subable_channels, uint_fast32_t * channelnum);

/**
 * @brief Parse pktlab controller experiment privilege certificate chain for subscribable channel and experiment privilege information.
 * @param[in]  cert_ls         A potential controller experiment privilege chain (in the form of an array of pointers to loaded pktlab certificate structs consisting) that should be parsed.
 * @param[in]  certnum         The number of loaded pktlab certificate struct pointers in cert_ls.
 * @param[in]  controller_key  Raw pktlab public key bytes for checking if the certificate chain leaf entity is some expected key. Should point to an array of at least PKTLAB_PUBLICKEY_LEN bytes long.
 * @param[in]  trusted_eop_key A loaded pktlab public key struct for checking if the certificate chain root entity is some expected key.
 * @param[out] ftdigests       Pointer to return a list of filter digests contained in cert_ls.
 * @param[out] ftcnt           Pointer to return the number of filter digests in ftdigests.
 * @param[out] mtdigests       Pointer to return a list of monitor digests contained in cert_ls.
 * @param[out] mtcnt           Pointer to return the number of monitor digests in mtdigests.
 * @param[out] priorities      Pointer to return a list of priority strings contained in cert_ls.
 * @param[out] pcnt            Pointer to return the number of priority strings in priorities.
 * @param[out] subable_channel Pointer to return a private channel ID allowed to be subscribed based on cert_ls.
 * @return                     One of the enum pktlab_parse_cert_chain_rst defined values representing the parsing result. Digests, priority strings, and channel information returned when parsing successful.
 *
 * - It is allowed to pass in NULL for controller_key/trusted_eop_key. If controller_key/trusted_eop_key is NULL, the corresponding leaf/root entity check is not conducted.
 * - It is allowed to pass in NULL for ftdigests & ftcnt / mtdigests & mtcnt / priorities & pcnt (Note if one field is NULL, their counterpart must be NULL as well. E.g. if ftdigests is NULL, ftcnt must be NULL and vice versa). If a field is NULL, no value is returned for the field.
 * - Note the first certificate in cert_ls is expected to be a pubcmd certificate (the others need not be in order). See PPKS documentation for more information on the expected format for a controller experiment privilege chain.
 */
extern int pktlab_parse_controller_exp_cert_chain (
	struct pktlab_certificate ** cert_ls,
	uint_fast32_t certnum,
	const uint8_t * controller_key,
	struct pktlab_publickey * trusted_eop_key,
	uint8_t ** ftdigests, uint_fast32_t * ftcnt,
	uint8_t ** mtdigests, uint_fast32_t * mtcnt,
	char *** priorities, uint_fast32_t * pcnt,
	uint8_t * subable_channel);

//
// BYTE/ADDRESS INVARIANT MEMORY ACCESS FUNCTION DECLARATIONS
//

/**
 * @brief Get 8-bit unsigned integer from byte array.
 * @param[in] ptr Target byte array.
 * @return        8 bit unsigned integer.
 *
 * - Note there also exist similar functions (pktlab_getN[b|l|n]) that gets N-bit unsigned integer from byte array (N being either 16, 24, 32 or 64). The b/l/n suffix specifies the function treats the byte array as in big endian/little endian/network byte order, respectively.
 */
static inline uint_fast8_t pktlab_get8(const void * ptr);
static inline uint_fast16_t pktlab_get16b(const void * ptr);
static inline uint_fast16_t pktlab_get16l(const void * ptr);
static inline uint_fast32_t pktlab_get24b(const void * ptr);
static inline uint_fast32_t pktlab_get24l(const void * ptr);
static inline uint_fast32_t pktlab_get32b(const void * ptr);
static inline uint_fast32_t pktlab_get32l(const void * ptr);
static inline uint_fast64_t pktlab_get64b(const void * ptr);
static inline uint_fast64_t pktlab_get64l(const void * ptr);

#define pktlab_get16n pktlab_get16b
#define pktlab_get24n pktlab_get24b
#define pktlab_get32n pktlab_get32b
#define pktlab_get64n pktlab_get64b

/**
 * @brief Set 8-bit unsigned integer to byte array.
 * @param[in] ptr Target byte array.
 * @param[in] val Target set value.
 *
 * - Note there also exist similar functions (pktlab_setN[b|l|n]) that sets N-bit unsigned integer to byte array (N being either 16, 24, 32 or 64). The b/l/n suffix specifies the function treats the byte array as in big endian/little endian/network byte order, respectively.
 */
static inline void pktlab_set8(void * ptr, uint_fast8_t val);
static inline void pktlab_set16b(void * ptr, uint_fast16_t val);
static inline void pktlab_set16l(void * ptr, uint_fast16_t val);
static inline void pktlab_set24b(void * ptr, uint_fast32_t val);
static inline void pktlab_set24l(void * ptr, uint_fast32_t val);
static inline void pktlab_set32b(void * ptr, uint_fast32_t val);
static inline void pktlab_set32l(void * ptr, uint_fast32_t val);
static inline void pktlab_set64b(void * ptr, uint_fast64_t val);
static inline void pktlab_set64l(void * ptr, uint_fast64_t val);

#define pktlab_set16n pktlab_set16b
#define pktlab_set24n pktlab_set24b
#define pktlab_set32n pktlab_set32b
#define pktlab_set64n pktlab_set64b

//
// BYTE ORDER CONVERSION FUNCTION DECLARATIONS
//

/**
 * @brief Convert 16-bit unsigned integer from host byte order to network byte order.
 * @param[in] x Target value to be converted.
 * @return      Converted value.
 *
 * - Note there also exist similar functions (pktlab_htonN and pktlab_ntohN) that convert unsigned integer from host byte order to network byte order and vice versa (N being either 16, 32, or 64).
 */
static inline uint_fast16_t pktlab_hton16(uint_fast16_t x);
static inline uint_fast32_t pktlab_hton32(uint_fast32_t x);
static inline uint_fast64_t pktlab_hton64(uint_fast64_t x);
static inline uint_fast16_t pktlab_ntoh16(uint_fast16_t x);
static inline uint_fast32_t pktlab_ntoh32(uint_fast32_t x);
static inline uint_fast64_t pktlab_ntoh64(uint_fast64_t x);

//
// BIT ACCESS FUNCTION DECLARATIONS
//

/**
 * @brief Get bit from unsigned integer at bit position.
 * @param[in] bits Target unsigned interger to get bit from.
 * @param[in] pos  Target bit position (0-indexed).
 * @return         Bit.
 *
 * - Note there also exist similar functions (pktlab_getbitN) that get bit from larger unsigned integer (N being either 16, 32, or 64).
 * - Getting bit for pos >= N will result in false.
 */
static inline bool pktlab_getbit8(uint_fast8_t bits, uint_fast8_t pos);
static inline bool pktlab_getbit16(uint_fast16_t bits, uint_fast8_t pos);
static inline bool pktlab_getbit32(uint_fast32_t bits, uint_fast8_t pos);
static inline bool pktlab_getbit64(uint_fast64_t bits, uint_fast8_t pos);

/**
 * @brief Set bit in unsigned integer at bit position.
 * @param[in] bits Target unsigned interger to set bit.
 * @param[in] pos  Target bit position (0-indexed).
 * @return         Set result.
 *
 * - Note there also exist similar functions (pktlab_setbitN) that set bit to larger unsigned integers (N being either 16, 32, or 64).
 * - Setting bit for pos >= N will be ignored with unchanged bits value returned.
 */
static inline uint_fast8_t pktlab_setbit8(uint_fast8_t bits, uint_fast8_t pos);
static inline uint_fast16_t pktlab_setbit16(uint_fast16_t bits, uint_fast8_t pos);
static inline uint_fast32_t pktlab_setbit32(uint_fast32_t bits, uint_fast8_t pos);
static inline uint_fast64_t pktlab_setbit64(uint_fast64_t bits, uint_fast8_t pos);

/**
 * @brief Clear bit in unsigned integer at bit position.
 * @param[in] bits Target unsigned interger to clear bit.
 * @param[in] pos  Target bit position (0-indexed).
 * @return         Clear result.
 *
 * - Note there also exist similar functions (pktlab_clrbitN) that clear bit in larger unsigned integers (N being either 16, 32, or 64).
 * - Clearing bit for pos >= N will be ignored with unchanged bits value returned.
 */
static inline uint_fast8_t pktlab_clrbit8(uint_fast8_t bits, uint_fast8_t pos);
static inline uint_fast16_t pktlab_clrbit16(uint_fast16_t bits, uint_fast8_t pos);
static inline uint_fast32_t pktlab_clrbit32(uint_fast32_t bits, uint_fast8_t pos);
static inline uint_fast64_t pktlab_clrbit64(uint_fast64_t bits, uint_fast8_t pos);

//
// INLINE FUNCTION DEFINITIONS
//

static inline pktlab_time_t pktlab_time_sec(uint_fast32_t sec) {
	return (uint64_t) sec * PKTLAB_TICKS_PER_SECOND;
}

static inline pktlab_time_t pktlab_timeval_to_time(const struct timeval * tv) {
	return (uint64_t) tv->tv_sec * PKTLAB_TICKS_PER_SECOND
		+ (uint64_t) tv->tv_usec * PKTLAB_TICKS_PER_SECOND / 1000000;
}

static inline void pktlab_time_to_timeval (
	pktlab_time_t t, struct timeval * tv)
{
	const uint64_t t_us = t / (PKTLAB_TICKS_PER_SECOND / 1000000);
	tv->tv_sec = t_us / 1000000;
	tv->tv_usec = t_us % 1000000;
}

static inline uint_fast32_t pktlab_time_to_unix_time(pktlab_time_t t) {
	return t / PKTLAB_TICKS_PER_SECOND;
}

static inline uint_fast8_t pktlab_get8(const void * ptr) {
	return *(const uint8_t*)ptr;
}

static inline uint_fast16_t pktlab_get16b(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast16_t val;

	val = (uint_fast16_t) u8ptr[0] << 8;
	val |= u8ptr[1];
	return val;
}

static inline uint_fast16_t pktlab_get16l(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast16_t val;

	val = (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[0];
	return val;
}

static inline uint_fast32_t pktlab_get24b(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast32_t val;

	val = (uint_fast32_t) u8ptr[0] << 16;
	val |= (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[2];
	return val;
}

static inline uint_fast32_t pktlab_get24l(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast32_t val;

	val = (uint_fast32_t) u8ptr[2] << 16;
	val |= (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[0];
	return val;
}

static inline uint_fast32_t pktlab_get32b(const void * ptr) {
	uint_fast32_t val;

	val = (uint_fast32_t) pktlab_get16b(ptr) << 16;
	val |= pktlab_get16b(ptr+2);
	return val;
}

static inline uint_fast32_t pktlab_get32l(const void * ptr) {
	uint_fast32_t val;

	val = (uint_fast32_t) pktlab_get16l(ptr+2) << 16;
	val |= pktlab_get16l(ptr);
	return val;
}

static inline uint_fast64_t pktlab_get64b(const void * ptr) {
	uint_fast64_t val;

	val = (uint_fast64_t) pktlab_get32b(ptr) << 32;
	val |= pktlab_get32b(ptr+4);
	return val;
}

static inline uint_fast64_t pktlab_get64l(const void * ptr) {
	uint_fast64_t val;

	val = (uint_fast64_t) pktlab_get32l(ptr+4) << 32;
	val |= pktlab_get32l(ptr);
	return val;
}

static inline void pktlab_set8(void * ptr, uint_fast8_t val) {
	*(uint8_t*)ptr = val;
}

static inline void pktlab_set16b(void * ptr, uint_fast16_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[0] = val >> 8;
	u8ptr[1] = val >> 0;
}

static inline void pktlab_set16l(void * ptr, uint_fast16_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[1] = val >> 8;
	u8ptr[0] = val >> 0;
}

static inline void pktlab_set24b(void * ptr, uint_fast32_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[0] = val >> 16;
	u8ptr[1] = val >> 8;
	u8ptr[2] = val >> 0;
}

static inline void pktlab_set24l(void * ptr, uint_fast32_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[2] = val >> 16;
	u8ptr[1] = val >> 8;
	u8ptr[0] = val >> 0;
}

static inline void pktlab_set32b(void * ptr, uint_fast32_t val) {
	pktlab_set16b(ptr, val >> 16);
	pktlab_set16b(ptr+2, val);
}

static inline void pktlab_set32l(void * ptr, uint_fast32_t val) {
	pktlab_set16l(ptr+2, val >> 16);
	pktlab_set16l(ptr, val);
}

static inline void pktlab_set64b(void * ptr, uint_fast64_t val) {
	pktlab_set32b(ptr, val >> 32);
	pktlab_set32b(ptr+4, val);
}

static inline void pktlab_set64l(void * ptr, uint_fast64_t val) {
	pktlab_set32l(ptr+4, val >> 32);
	pktlab_set32l(ptr, val);
}

static inline uint_fast16_t pktlab_hton16(uint_fast16_t x) {
	return htons(x);
}

static inline uint_fast32_t pktlab_hton32(uint_fast32_t x) {
	return htonl(x);
}

static inline uint_fast64_t pktlab_hton64(uint_fast64_t x) {
	uint_fast32_t hi, lo;

	hi = x >> 32;
	lo = x & UINT32_C(0xffffffff);
	return ((uint_fast64_t) pktlab_hton32(lo) << 32) | pktlab_hton32(hi);
}

static inline uint_fast16_t pktlab_ntoh16(uint_fast16_t x) {
	return ntohs(x);
}

static inline uint_fast32_t pktlab_ntoh32(uint_fast32_t x) {
	return ntohl(x);
}

static inline uint_fast64_t pktlab_ntoh64(uint_fast64_t x) {
	uint_fast32_t hi, lo;

	lo = pktlab_ntoh32(x >> 32);
	hi = pktlab_ntoh32(x & UINT32_C(0xffffffff));
	return ((uint_fast64_t) hi << 32) | lo;
}

static inline bool pktlab_getbit8(uint_fast8_t bits, uint_fast8_t pos) {
	return pktlab_getbit64(bits, pos);
}

static inline bool pktlab_getbit16(uint_fast16_t bits, uint_fast8_t pos) {
	return pktlab_getbit64(bits, pos);
}

static inline bool pktlab_getbit32(uint_fast32_t bits, uint_fast8_t pos) {
	return pktlab_getbit64(bits, pos);
}

static inline bool pktlab_getbit64(uint_fast64_t bits, uint_fast8_t pos) {
	return (pos >= 0x40) ? false : (bits & ((uint_fast64_t) 1 << pos));
}


static inline uint_fast8_t pktlab_setbit8(uint_fast8_t bits, uint_fast8_t pos) {
	return pktlab_setbit64(bits, pos);
}

static inline uint_fast16_t pktlab_setbit16(uint_fast16_t bits, uint_fast8_t pos) {
	return pktlab_setbit64(bits, pos);
}

static inline uint_fast32_t pktlab_setbit32(uint_fast32_t bits, uint_fast8_t pos) {
	return pktlab_setbit64(bits, pos);
}

static inline uint_fast64_t pktlab_setbit64(uint_fast64_t bits, uint_fast8_t pos) {
	return (pos >= 0x40) ? bits : (bits | ((uint_fast64_t) 1 << pos));
}


static inline uint_fast8_t pktlab_clrbit8(uint_fast8_t bits, uint_fast8_t pos) {
	return pktlab_clrbit64(bits, pos);
}

static inline uint_fast16_t pktlab_clrbit16(uint_fast16_t bits, uint_fast8_t pos) {
	return pktlab_clrbit64(bits, pos);
}

static inline uint_fast32_t pktlab_clrbit32(uint_fast32_t bits, uint_fast8_t pos) {
	return pktlab_clrbit64(bits, pos);
}

static inline uint_fast64_t pktlab_clrbit64(uint_fast64_t bits, uint_fast8_t pos) {
	return (pos >= 0x40) ? bits : (bits & ~((uint_fast64_t) 1 << pos));
}

#endif