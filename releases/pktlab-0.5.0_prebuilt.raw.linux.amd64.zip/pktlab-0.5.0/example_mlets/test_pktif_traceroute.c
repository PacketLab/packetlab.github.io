// test_pktif_traceroute.c
// PacketLab Raw Socket Experiment Controller Example Program aka test_pktif_traceroute
// Use pktlab measurement endpoint to run traceroute (for IPv4 only)
//

#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>

#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <pktif.h>

#define BUFSZ 0x10000

#define IP4_ADDRLEN PKTLAB_IPV4_WO_MSK_ADDR_LEN
#define IP_HDRLEN 20
#define UDP_HDRLEN 8
#define DNS_HDRLEN 12
#define ICMP_PROTO 1
#define UDP_PROTO 17
#define ICMP_TIMEEXCEED_TYPE 11
#define ICMP_DSTUNREACH_TYPE 3
#define ICMP_PORTUNREACH_CODE 3
#define DONT_PRINT ICMP_PORTUNREACH_CODE

#define RR_CLASS_IN 1
#define RR_TYPE_A 1
#define RR_TYPE_CNAME 5

#define DNSHDR_STDQUERY_OPCODE 0

#define DEFAULT_WELCOME_PORT 20556
#define DEFAULT_WAIT_TIME 4
#define DEFAULT_MAX_TTL 30

#define TRACERT_DPORT_START 33434
#define TRACERT_SPORT_START 32768
#define TRACERT_SPORT_END 60999

#define DNS_PORT 53

#define PROBENUM 3
#define MAXPROBENUM (UINT8_MAX * PROBENUM)

#define RAW_SKTID 0
#define DNS_SKTID 1

#define SRC_INTF_INDX 0
#define DNS_QUERYID 20556
#define DNS_TIMEOUT 10

#define MAX_SKTID 256
#define MAX_IPLIST_LEN 256
#define MAX_DNSLIST_LEN 256

#define errprint(fmt, ...)                                                     \
    do {                                                                       \
        if (debug)                                                             \
            fprintf(stderr, (fmt), __VA_ARGS__);                               \
    } while (0)
#define errprint_ret(ret, fmt, ...)                                            \
    do {                                                                       \
        if (debug)                                                             \
            fprintf(stderr, (fmt), __VA_ARGS__);                               \
        return (ret);                                                          \
    } while (0)

#define EBPF_TRACEROUTE_RECV_FILTER()                                          \
    {                                                                          \
        {0xbf, 0x6, 0x1, 0x0000, 0x00000000},                                  \
            {0xb7, 0x7, 0x0, 0x0000, 0x00000000},                              \
            {0x30, 0x0, 0x0, 0x0000, 0x00000000},                              \
            {0xbf, 0x9, 0x0, 0x0000, 0x00000000},                              \
            {0xbf, 0x1, 0x9, 0x0000, 0x00000000},                              \
            {0x57, 0x1, 0x0, 0x0000, 0xfffffff0},                              \
            {0x55, 0x1, 0x0, 0x004c, 0x00000040},                              \
            {0x30, 0x0, 0x0, 0x0000, 0x00000003},                              \
            {0xbf, 0x8, 0x0, 0x0000, 0x00000000},                              \
            {0x30, 0x0, 0x0, 0x0000, 0x00000002},                              \
            {0x67, 0x9, 0x0, 0x0000, 0x00000002},                              \
            {0x57, 0x9, 0x0, 0x0000, 0x0000003c},                              \
            {0xb7, 0x1, 0x0, 0x0000, 0x00000014},                              \
            {0x2d, 0x1, 0x9, 0x0045, 0x00000000},                              \
            {0x67, 0x0, 0x0, 0x0000, 0x00000004},                              \
            {0x0f, 0x0, 0x8, 0x0000, 0x00000000},                              \
            {0x7b, 0xa, 0x0, 0xfff8, 0x00000000},                              \
            {0x30, 0x0, 0x0, 0x0000, 0x00000009},                              \
            {0x67, 0x0, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x0, 0x0, 0x0000, 0x00000020},                              \
            {0x15, 0x0, 0x0, 0x0021, 0x00000006},                              \
            {0x79, 0x2, 0xa, 0xfff8, 0x00000000},                              \
            {0x55, 0x0, 0x0, 0x003c, 0x00000001},                              \
            {0xbf, 0x1, 0x9, 0x0000, 0x00000000},                              \
            {0x07, 0x1, 0x0, 0x0000, 0x00000008},                              \
            {0x67, 0x2, 0x0, 0x0000, 0x00000020},                              \
            {0xc7, 0x2, 0x0, 0x0000, 0x00000020},                              \
            {0x6d, 0x1, 0x2, 0x0037, 0x00000000},                              \
            {0xbf, 0x8, 0x9, 0x0000, 0x00000000},                              \
            {0x67, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x50, 0x0, 0x8, 0x0000, 0x00000000},                              \
            {0xbf, 0x8, 0x0, 0x0000, 0x00000000},                              \
            {0x47, 0x9, 0x0, 0x0000, 0x00000001},                              \
            {0x67, 0x9, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x9, 0x0, 0x0000, 0x00000020},                              \
            {0x50, 0x0, 0x9, 0x0000, 0x00000000},                              \
            {0x79, 0x2, 0xa, 0xfff8, 0x00000000},                              \
            {0xbf, 0x1, 0x8, 0x0000, 0x00000000},                              \
            {0x67, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x15, 0x1, 0x0, 0x0028, 0x00000003},                              \
            {0xbf, 0x1, 0x0, 0x0000, 0x00000000},                              \
            {0x4f, 0x1, 0x8, 0x0000, 0x00000000},                              \
            {0x67, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x15, 0x1, 0x0, 0x0023, 0x00000000},                              \
            {0x67, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x55, 0x8, 0x0, 0x0021, 0x0000000b},                              \
            {0x67, 0x0, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x0, 0x0, 0x0000, 0x00000020},                              \
            {0x55, 0x0, 0x0, 0x001e, 0x00000000},                              \
            {0x05, 0x0, 0x0, 0x001c, 0x00000000},                              \
            {0xbf, 0x8, 0x9, 0x0000, 0x00000000},                              \
            {0x07, 0x8, 0x0, 0x0000, 0x0000000c},                              \
            {0x67, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x50, 0x0, 0x8, 0x0000, 0x00000000},                              \
            {0x77, 0x0, 0x0, 0x0000, 0x00000002},                              \
            {0x18, 0x1, 0x0, 0x0000, 0xfffffffc},                              \
            {0x00, 0x0, 0x0, 0x0000, 0x00000000},                              \
            {0x5f, 0x0, 0x1, 0x0000, 0x00000000},                              \
            {0xbf, 0x8, 0x9, 0x0000, 0x00000000},                              \
            {0x0f, 0x8, 0x0, 0x0000, 0x00000000},                              \
            {0x07, 0x9, 0x0, 0x0000, 0x0000000d},                              \
            {0x67, 0x9, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x9, 0x0, 0x0000, 0x00000020},                              \
            {0x50, 0x0, 0x9, 0x0000, 0x00000000},                              \
            {0x79, 0x2, 0xa, 0xfff8, 0x00000000},                              \
            {0xbf, 0x1, 0x2, 0x0000, 0x00000000},                              \
            {0x67, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x67, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0xc7, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0xc7, 0x8, 0x0, 0x0000, 0x00000020},                              \
            {0x6d, 0x8, 0x1, 0x0007, 0x00000000},                              \
            {0xbf, 0x1, 0x0, 0x0000, 0x00000000},                              \
            {0x67, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x77, 0x1, 0x0, 0x0000, 0x00000020},                              \
            {0x15, 0x1, 0x0, 0x0002, 0x00000012},                              \
            {0x57, 0x0, 0x0, 0x0000, 0x00000004},                              \
            {0x15, 0x0, 0x0, 0x0001, 0x00000000},                              \
            {0xbf, 0x7, 0x2, 0x0000, 0x00000000},                              \
            {0xbf, 0x0, 0x7, 0x0000, 0x00000000},                              \
            {0x95, 0x0, 0x0, 0x0000, 0x00000000},                              \
    }

struct IPHdr {
    uint8_t ihl : 4;
    uint8_t ver : 4;
    uint8_t tos;
    uint16_t len;
    uint16_t id;
    uint16_t frag;
    uint8_t ttl;
    uint8_t proto;
    uint16_t cksum;
    uint32_t src;
    uint32_t dst;
};

struct ICMPHdr {
    uint8_t type;
    uint8_t code;
    uint16_t cksum;
    uint32_t _unused;
};

struct UDPHdr {
    uint16_t sport;
    uint16_t dport;
    uint16_t len;
    uint16_t cksum;
};

struct DNSHdr {
    uint16_t ID;

    uint16_t rd : 1;
    uint16_t tc : 1;
    uint16_t aa : 1;
    uint16_t opcode : 4;
    uint16_t qr : 1;
    uint16_t rcode : 4;
    uint16_t zero : 3;
    uint16_t ra : 1;

    uint16_t qcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t adcount;
};

int debug = 0;

static void usage(void);

// static void perror_exit(const char *str, int exit_val);
static void print_err_exit(int exit_val, const char *fmt, ...);

static int process_dns(struct pktif *pktif, struct sockaddr *dnsaddr,
                       void *ansaddr, size_t addrlen, uint8_t sktid,
                       uint16_t dnsID, uint8_t RD, const char *domain,
                       size_t domainlen);
static int setup_icmp_cap(struct pktif *pktif);
static int process_packets(struct pktif *pktif,
                           pktlab_time_t icmp_recv_tstp[MAXPROBENUM],
                           uint8_t errip_ls[MAXPROBENUM][IP4_ADDRLEN],
                           uint8_t code_ls[MAXPROBENUM],
                           int_fast32_t *min_portunreach_dport,
                           size_t total_probenum, uint16_t start_dport);
static void comp_print_struct(
    pktlab_time_t icmp_send_tstp[MAXPROBENUM],
    pktlab_time_t icmp_recv_tstp[MAXPROBENUM],
    uint8_t errip_ls[MAXPROBENUM][IP4_ADDRLEN], uint8_t code_ls[MAXPROBENUM],
    int_fast32_t min_dstunreach_dport, uint16_t start_port,
    size_t total_probenum, double hop_delay_ls[UINT8_MAX][PROBENUM],
    uint8_t hop_errip_ls[UINT8_MAX][PROBENUM][IP4_ADDRLEN],
    uint8_t hop_code_ls[UINT8_MAX][PROBENUM], uint16_t *hopcnt);
static void run_traceroute(struct pktif *pktif, uint8_t maxttl, uint16_t ipid,
                           uint_fast32_t waittime, const char *addr,
                           size_t addrlen);

static ssize_t create_ip4_pkt(uint8_t *buf, size_t buflen, uint16_t ID,
                              uint8_t ttl, uint8_t proto, uint16_t payloadlen,
                              const void *src, const void *dst);
static ssize_t create_udp_seg(uint8_t *buf, size_t buflen, uint16_t sport,
                              uint16_t dport, const void *payload,
                              size_t payloadlen, const void *src,
                              const void *dst);
static ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID,
                                uint8_t RD, const char *domain,
                                size_t domainlen);
static ssize_t create_whole_pkt(uint8_t *buf, size_t buflen, uint16_t ipid,
                                uint8_t ttl, const void *src, const void *dst,
                                uint16_t sport, uint16_t dport,
                                const void *data, size_t datalen);
static ssize_t create_icmp_filter(void **buf, uint_fast32_t *buflen);

// static int check_special_ip(const uint8_t *addr);
static const uint8_t *decode_question(const uint8_t *rr, size_t len,
                                      const uint8_t **qname,
                                      const uint8_t **qtype,
                                      const uint8_t **qclass);
static uint8_t *domain2name(uint8_t *buf, size_t buflen, const char *domain,
                            size_t domainlen);
static int cmp_domain_dnslabel(const char *domain, size_t domainlen,
                               const uint8_t *dnslabel, size_t labellen);
static const uint8_t *decode_rrecord(const uint8_t *rr, size_t len,
                                     const uint8_t **name, int *compressed,
                                     const uint8_t **type,
                                     const uint8_t **class, uint32_t *ttl,
                                     uint16_t *rdlen, const uint8_t **rdata);
static int search_dns_rr_section(const uint8_t *sections, size_t secslen,
                                 uint16_t rrcnt, const uint8_t *name,
                                 size_t namelen, uint16_t pointer,
                                 const uint8_t **found_rdata,
                                 const uint8_t **remainder);
static int get_resolved_addr(void *addr, size_t addrlen, uint16_t ID,
                             uint8_t opcode, const char *domain,
                             size_t domainlen, const uint8_t *rsp, size_t len);
static int is_icmp_timeexceed(const uint8_t *pkt, size_t len);
static int is_icmp_dstunreach(const uint8_t *pkt, size_t len);
static void get_icmp_info(uint8_t *errip, uint8_t *icmptype, uint8_t *icmpcode,
                          uint16_t *dport, const uint8_t *pkt, size_t len);
static uint16_t u16_rand(void);
static uint16_t get_randport(uint16_t startport, uint16_t endport);
static uint16_t calcksum(const uint8_t *buf, size_t len);
static uint16_t calcksum_udp(const uint8_t *src, const uint8_t *dst,
                             uint16_t udplen, struct UDPHdr *udphdr,
                             const void *payload, size_t payloadlen);

static void err_print_pkt(const uint8_t *ptr, size_t len);
static void print_traceroute(
    const char * epaddr, const uint8_t localsrcip[IP4_ADDRLEN],
    const char *targetdomain, const uint8_t targetip[IP4_ADDRLEN],
    const uint8_t dnsip[IP4_ADDRLEN], uint8_t maxttl, size_t probesz,
    uint8_t hopnum, const double delay_arr[UINT8_MAX][PROBENUM],
    const uint8_t errip_arr[UINT8_MAX][PROBENUM][IP4_ADDRLEN],
    const uint8_t flag_arr[UINT8_MAX][PROBENUM]);
static bool is_good_fd(int fd);

int main(int argc, char *argv[]) {
    int optch;
    uint8_t maxttl = DEFAULT_MAX_TTL;
    uint16_t ipid = DEFAULT_WELCOME_PORT;
    uint_fast32_t waittime = DEFAULT_WAIT_TIME;
    // uint16_t welcome_port = DEFAULT_WELCOME_PORT;
    int econnfd;

    while ((optch = getopt(argc, argv, "dm:p:t:")) != -1) {
        switch (optch) {
        case 'd':
            debug = 1;
            break;
        case 'm':
            maxttl = strtoul(optarg, NULL, 0);
            break;
        case 't':
            waittime = strtoul(optarg, NULL, 0);
            break;
        default:
            goto usage_error;
        }
    }

    argc -= optind;
    argv += optind;

    if (argc != 1)
        goto usage_error;

    if (getenv("EPADDR") == NULL) {
        fprintf(stderr, "EPADDR not set " \
            "(are you running this mlet using pktxpmgr?)\n");
        exit(EXIT_FAILURE);
    }

    const char *addr = argv[0];
    const size_t addrlen = strlen(addr);

    fprintf(stderr,
            "> PacketLab Measurement Applet: traceroute example (with pktif)"
            " (tracerouting to '%s') using pktxpmgr\n",
            addr);

    econnfd = 0;
    assert(is_good_fd(econnfd));

    struct pktif *pktif = pktif_init(econnfd, NULL);

    run_traceroute(pktif, maxttl, ipid, waittime, addr, addrlen);
    return 0;

usage_error:
    usage();
    return -1;
}

// void perror_exit(const char *str, int exit_val) {
//     perror(str);
//     exit(exit_val);
// }

void print_err_exit(int exit_val, const char *fmt, ...) {
    char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s", buf);

    exit(exit_val);
}

bool is_good_fd(int fd) { return (fcntl(fd, F_GETFD) >= 0); }

void usage(void) {
    fprintf(stderr, "Usage:\n");
    fprintf(stderr,
            "  test_pktif_traceroute [-d] [ -m max_ttl ] [ -p listen_port ] [ -t "
            "poll_wait_time ] host\n");
    fprintf(stderr, "Options:\n");
    fprintf(stderr,
            "  -d\n                              Print debug information");
    fprintf(stderr, "  -m max_ttl\n");
    fprintf(stderr,
            "                              Set the max number of hops (max TTL "
            "to be\n");
    fprintf(stderr, "                              reached). Default is %d.\n",
            DEFAULT_MAX_TTL);
    fprintf(stderr, "  -t poll_wait_time\n");
    fprintf(
        stderr,
        "                              Set the wait time before polling the "
        "endpoint\n");
    fprintf(
        stderr,
        "                              for icmp responses. Default is %d.\n",
        DEFAULT_WAIT_TIME);
    fprintf(stderr, "Argument:\n");
    fprintf(stderr, "+     host          The host to traceroute to.\n");
}

int process_dns(struct pktif *pktif, struct sockaddr *dnsaddr, void *ansaddr,
                size_t addrlen, uint8_t sktid, uint16_t dnsID, uint8_t RD,
                const char *domain, size_t domainlen) {
    assert(addrlen >= IP4_ADDRLEN);

    // construct and send dns query
    uint8_t query[BUFSZ];
    ssize_t querylen;
    querylen =
        create_dns_query(query, sizeof(query), dnsID, RD, domain, domainlen);
    if (querylen < 0)
        errprint_ret(-1, "%s: failed to create DNS query\n", __func__);

    assert(pktif_send_sync(pktif, DNS_SKTID, query, querylen, PKTLAB_UDP_PROTO,
                           0, 0, dnsaddr, NULL) == querylen);

    uint8_t dnsrsp[BUFSZ];
    size_t rsplen = 0;

    if ((rsplen = pktif_recv_sync(pktif, DNS_SKTID, dnsrsp, sizeof(dnsrsp),
                                  NULL, NULL)) < 0)
        errprint_ret(-1, "%s: endpoint communication failed\n", __func__);
    if (get_resolved_addr(ansaddr, addrlen, dnsID, DNSHDR_STDQUERY_OPCODE,
                          domain, domainlen, dnsrsp, rsplen) < 0)
        return -1;

    return 0;
}

int setup_icmp_cap(struct pktif *pktif) {
    pktlab_time_t time = PKTLAB_TIME_MAX; // raw socket recv forever
    uint8_t *filter = NULL;
    uint_fast32_t filtlen = 0;
    int rv;

    rv = create_icmp_filter((void **)&filter, &filtlen);
    assert(rv == filtlen);

    rv = pktif_ncap_sync(pktif, RAW_SKTID, PKTLAB_IP4_PROTO, PKTLAB_RAW_PROTO,
                         time, filter, filtlen);
    free(filter);
    return rv;
}

int process_packets(struct pktif *pktif,
                    pktlab_time_t icmp_recv_tstp[MAXPROBENUM],
                    uint8_t errip_ls[MAXPROBENUM][IP4_ADDRLEN],
                    uint8_t code_ls[MAXPROBENUM],
                    int_fast32_t *min_portunreach_dport, size_t total_probenum,
                    uint16_t start_dport) {

    memset(icmp_recv_tstp, 0, sizeof(pktlab_time_t) * total_probenum);
    memset(errip_ls, 0, sizeof(uint8_t) * IP4_ADDRLEN * total_probenum);
    memset(code_ls, 0, sizeof(uint8_t) * total_probenum);
    *min_portunreach_dport = INT32_MAX;

    int extract;
    uint8_t errip[IP4_ADDRLEN];
    uint8_t icmptype;
    uint8_t icmpcode;
    uint16_t dport;
    uint16_t indx;
    uint8_t recvbuf[1024];
    size_t recvlen;
    pktlab_time_t recv_time;
    int cnt = 0;

    while ((recvlen = pktif_recv_async(pktif, RAW_SKTID, recvbuf,
                                       sizeof(recvbuf), NULL, &recv_time))) {

        if (is_icmp_timeexceed(recvbuf, recvlen)) {
            extract = 1;
        } else if (is_icmp_dstunreach(recvbuf, recvlen)) {
            extract = 2;
        } else {
            errprint("%s: Got non-targeted data. Ignoring\n", __func__);
            errprint("%s: Raw pkt:\n", __func__);
            err_print_pkt(recvbuf, recvlen);
            break;
        }

        get_icmp_info(errip, &icmptype, &icmpcode, &dport, recvbuf, recvlen);

        if (extract == 1) {
            assert(icmptype == ICMP_TIMEEXCEED_TYPE);
            icmpcode = DONT_PRINT;
        } else if (extract == 2) {
            assert(icmptype == ICMP_DSTUNREACH_TYPE);
        }

        indx = dport - start_dport;
        if (dport < start_dport || indx >= total_probenum) {
            errprint("%s: Got unexpected destination port number (%u). "
                     "Ignoring\n",
                     __func__, dport);
            errprint("%s: Raw pkt:\n", __func__);
            err_print_pkt(recvbuf, recvlen);
            break;
        }

        if (icmp_recv_tstp[indx] != 0) {
            errprint("%s: Got repetitive icmp response. Ignoring\n", __func__);
            errprint("%s: Raw pkt:\n", __func__);
            err_print_pkt(recvbuf, recvlen);
            break;
        }

        if (extract == 2 && *min_portunreach_dport > dport)
            *min_portunreach_dport = dport;

        icmp_recv_tstp[indx] = recv_time;
        memcpy(errip_ls[indx], errip, IP4_ADDRLEN);
        code_ls[indx] = icmpcode;
        ++cnt;
    }

    if (*min_portunreach_dport == INT32_MAX)
        *min_portunreach_dport = -1;
    fprintf(stderr, "> processed %d packets\n", cnt);
    return 0;
}

void comp_print_struct(pktlab_time_t icmp_send_tstp[MAXPROBENUM],
                       pktlab_time_t icmp_recv_tstp[MAXPROBENUM],
                       uint8_t errip_ls[MAXPROBENUM][IP4_ADDRLEN],
                       uint8_t code_ls[MAXPROBENUM],
                       int_fast32_t min_dstunreach_dport, uint16_t start_port,
                       size_t total_probenum,
                       double hop_delay_ls[UINT8_MAX][PROBENUM],
                       uint8_t hop_errip_ls[UINT8_MAX][PROBENUM][IP4_ADDRLEN],
                       uint8_t hop_code_ls[UINT8_MAX][PROBENUM],
                       uint16_t *hopcnt) {
    size_t valid_probenum;

    assert(min_dstunreach_dport < 0 || min_dstunreach_dport >= start_port);
    valid_probenum = (min_dstunreach_dport < 0)
                         ? total_probenum
                         : (min_dstunreach_dport - start_port + 1);
    *hopcnt = (valid_probenum % PROBENUM == 0)
                  ? (valid_probenum / PROBENUM)
                  : (valid_probenum / PROBENUM + 1);

    for (size_t i = 0; i * PROBENUM < valid_probenum; ++i)
        for (size_t j = 0; j < PROBENUM; ++j) {
            if (icmp_recv_tstp[i * PROBENUM + j] != 0) {
                hop_delay_ls[i][j] = (icmp_recv_tstp[i * PROBENUM + j] -
                                      icmp_send_tstp[i * PROBENUM + j]) /
                                     (double)PKTLAB_TICKS_PER_SECOND;
                memcpy(hop_errip_ls[i][j], errip_ls[i * PROBENUM + j],
                       IP4_ADDRLEN);
                hop_code_ls[i][j] = code_ls[i * PROBENUM + j];
            } else {
                hop_delay_ls[i][j] = -1;
            }
        }
}

void err_print_pkt(const uint8_t *ptr, size_t len) {
    if (!debug)
        return;

    for (size_t i = 0; i < len; ++i) {
        fprintf(stderr, "%02x ", (unsigned int)ptr[i]);

        if (i % 16 == 7)
            fprintf(stderr, " ");
        if (i % 16 == 15)
            fprintf(stderr, "\n");
    }

    if (len % 16 != 15)
        fprintf(stderr, "\n");
}

void print_traceroute(const char * epaddr,
                      const uint8_t localsrcip[IP4_ADDRLEN],
                      const char *targetdomain,
                      const uint8_t targetip[IP4_ADDRLEN],
                      const uint8_t dnsip[IP4_ADDRLEN], uint8_t maxttl,
                      size_t probesz, uint8_t hopnum,
                      const double delay_arr[UINT8_MAX][PROBENUM],
                      const uint8_t errip_arr[UINT8_MAX][PROBENUM][IP4_ADDRLEN],
                      const uint8_t flag_arr[UINT8_MAX][PROBENUM]) {
    char targetstr[BUFSZ];
    char dnsstr[BUFSZ];

    if (targetdomain == NULL) {
        snprintf(targetstr, sizeof(targetstr), "%u.%u.%u.%u",
                 (unsigned)targetip[0], (unsigned)targetip[1],
                 (unsigned)targetip[2], (unsigned)targetip[3]);

        dnsstr[0] = '\0';
    } else {
        snprintf(targetstr, sizeof(targetstr), "%s%s%u.%u.%u.%u%s",
                 targetdomain, " (", (unsigned)targetip[0],
                 (unsigned)targetip[1], (unsigned)targetip[2],
                 (unsigned)targetip[3], ")");

        snprintf(dnsstr, sizeof(dnsstr), "; DNS %u.%u.%u.%u",
                 (unsigned)dnsip[0], (unsigned)dnsip[1], (unsigned)dnsip[2],
                 (unsigned)dnsip[3]);
    }

    printf("test_pktif_traceroute to %s (from %s; locally %u.%u.%u.%u%s),"
           " %u hops max, %u byte packets\n", targetstr, epaddr,
           (unsigned)localsrcip[0], (unsigned)localsrcip[1],
           (unsigned)localsrcip[2], (unsigned)localsrcip[3], dnsstr,
           (unsigned)maxttl, (unsigned)probesz);

    for (size_t i = 0; i < hopnum; ++i) {
        printf("%2d", (int)i + 1);
        for (size_t j = 0; j < PROBENUM; ++j) {
            if (delay_arr[i][j] < 0) {
                if (j == 0)
                    printf(" ");
                printf(" *");
            } else {
                if (j == 0 || memcmp(errip_arr[i][j - 1], errip_arr[i][j],
                                     IP4_ADDRLEN) != 0)
                    printf("  %u.%u.%u.%u",
                           (unsigned)errip_arr[i][j][0],
                           (unsigned)errip_arr[i][j][1],
                           (unsigned)errip_arr[i][j][2],
                           (unsigned)errip_arr[i][j][3]);

                printf("  %.3lf ms", delay_arr[i][j] * 1000);

                /*
                 * Flag/Code meaning
                 *
                 * 0 	Net Unreachable 	[RFC792]
                 * 1 	Host Unreachable 	[RFC792]
                 * 2 	Protocol Unreachable 	[RFC792]
                 * 3 	Port Unreachable 	[RFC792]
                 * 4 	Fragmentation Needed and Don't Fragment was Set
                 * [RFC792] 5 	Source Route Failed 	[RFC792] 6
                 * Destination Network Unknown 	[RFC1122] 7 	Destination Host
                 * Unknown 	[RFC1122] 8 	Source Host Isolated [RFC1122]
                 * 9 	Communication with Destination Network is
                 * Administratively Prohibited 	[RFC1122] 10 	Communication
                 * with Destination Host is Administratively Prohibited
                 * [RFC1122]
                 * 11 	Destination Network Unreachable for Type of Service
                 * [RFC1122] 12 	Destination Host Unreachable for Type of
                 * Service 	[RFC1122] 13 	Communication Administratively
                 * Prohibited 	[RFC1812] 14 	Host Precedence Violation
                 * [RFC1812] 15 	Precedence cutoff in effect [RFC1812]
                 */

                switch (flag_arr[i][j]) {
                case 0:
                case 6:
                case 8:
                case 11:
                    printf(" !N");
                    break;
                case 1:
                case 7:
                case 12:
                    printf(" !H");
                    break;
                case 2:
                    printf(" !P");
                    break;
                case 3:
                    break;
                case 4:
                    printf(" !F"); // May need to print more
                    break;
                case 5:
                    printf(" !S");
                    break;
                case 9:
                case 10:
                case 13:
                    printf(" !X");
                    break;
                case 14:
                    printf(" !V");
                    break;
                case 15:
                    printf(" !C");
                    break;
                default:
                    printf(" !<%u>", (unsigned)flag_arr[i][j]);
                    break;
                }
            }
        }
        printf("\n");
    }
}

uint16_t calcksum(const uint8_t *buf, size_t len) {
    uint32_t rst = 0xffff;
    uint16_t tmp;

    for (size_t i = 0; i < len - 1; i += 2) {
        memcpy(&tmp, buf + i, 2);
        rst = (rst + pktlab_ntoh16(tmp)) % 0xffff;
    }

    // Handle any partial block at the end of the data.
    if (len % 2 == 1) {
        tmp = 0;
        memcpy(&tmp, buf + len - 1, 1);
        rst = (rst + pktlab_ntoh16(tmp)) % 0xffff;
    }

    // Return the checksum in network byte order.
    return pktlab_hton16(~rst);
}

ssize_t create_ip4_pkt(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t ttl,
                       uint8_t proto, uint16_t payloadlen, const void *src,
                       const void *dst) {
    /*
     * Refer to RFC 791 for more information on the fields of ipv4
     *
     *   0                   1                   2                   3
     *   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |Version|  IHL  |Type of Service|          Total Length         |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |         Identification        |Flags|      Fragment Offset    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |  Time to Live |    Protocol   |         Header Checksum       |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                       Source Address                          |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Destination Address                        |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Options                    |    Padding    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */

    if (buflen < IP_HDRLEN)
        return -1;

    struct IPHdr *iphdr = (struct IPHdr *)buf;
    iphdr->ihl = 5;
    iphdr->ver = 4;
    iphdr->tos = 0;
    iphdr->len = pktlab_hton16(IP_HDRLEN + payloadlen);
    iphdr->id = pktlab_hton16(ID);
    iphdr->frag = 0;
    iphdr->ttl = ttl;
    iphdr->proto = proto;
    iphdr->cksum = 0;
    memcpy(&iphdr->src, src, IP4_ADDRLEN);
    memcpy(&iphdr->dst, dst, IP4_ADDRLEN);
    iphdr->cksum = calcksum(buf, IP_HDRLEN);

    return IP_HDRLEN + payloadlen;
}

ssize_t create_udp_seg(uint8_t *buf, size_t buflen, uint16_t sport,
                       uint16_t dport, const void *payload, size_t payloadlen,
                       const void *src, const void *dst) {
    /*
     * Refer to RFC 768 for more information on the fields of udp segments
     *
     *         0      7 8     15 16    23 24    31
     *        +--------+--------+--------+--------+
     *        |     Source      |   Destination   |
     *        |      Port       |      Port       |
     *        +--------+--------+--------+--------+
     *        |                 |                 |
     *        |     Length      |    Checksum     |
     *        +--------+--------+--------+--------+
     */

    /*
     * UDP cksum pseudo-header format
     *         0      7 8     15 16    23 24    31
     *        +--------+--------+--------+--------+
     *        |          source address           |
     *        +--------+--------+--------+--------+
     *        |        destination address        |
     *        +--------+--------+--------+--------+
     *        |  zero  |protocol|   UDP length    |
     *        +--------+--------+--------+--------+
     */

    if (buflen < UDP_HDRLEN + payloadlen)
        return -1;

    struct UDPHdr *udphdr = (struct UDPHdr *)buf;
    udphdr->sport = pktlab_hton16(sport);
    udphdr->dport = pktlab_hton16(dport);
    udphdr->len = pktlab_hton16(UDP_HDRLEN + payloadlen);
    udphdr->cksum = 0;
    if (payloadlen != 0)
        memcpy(udphdr + 1, payload, payloadlen);

    udphdr->cksum =
        calcksum_udp(src, dst, udphdr->len, udphdr, payload, payloadlen);

    return UDP_HDRLEN + payloadlen;
}

uint16_t calcksum_udp(const uint8_t *src, const uint8_t *dst, uint16_t udplen,
                      struct UDPHdr *udphdr, const void *payload,
                      size_t payloadlen) {
    uint8_t *len_ptr = (uint8_t *)&udplen;
    uint8_t tmp[BUFSZ] = {src[0], src[1],    src[2],     src[3],
                          dst[0], dst[1],    dst[2],     dst[3],
                          0,      UDP_PROTO, len_ptr[0], len_ptr[1]};
    memcpy(tmp + 12, udphdr, sizeof(struct UDPHdr) + payloadlen);

    return calcksum(tmp, 12 + sizeof(struct UDPHdr) + payloadlen);
}

ssize_t create_whole_pkt(uint8_t *buf, size_t buflen, uint16_t ipid,
                         uint8_t ttl, const void *src, const void *dst,
                         uint16_t sport, uint16_t dport, const void *data,
                         size_t datalen) {
    if (buflen < IP_HDRLEN + UDP_HDRLEN || buf == NULL)
        return -1;

    ssize_t udpseg_len;
    udpseg_len = create_udp_seg(buf + IP_HDRLEN, buflen - IP_HDRLEN, sport,
                                dport, data, datalen, src, dst);
    if (udpseg_len < 0)
        return -1;

    ssize_t ippkt_len;
    ippkt_len =
        create_ip4_pkt(buf, buflen, ipid, ttl, UDP_PROTO, udpseg_len, src, dst);
    if (ippkt_len < 0)
        return -1;

    return ippkt_len;
}

ssize_t create_dns_query(uint8_t *buf, size_t buflen, uint16_t ID, uint8_t RD,
                         const char *domain, size_t domainlen) {
    /*
     * Refer to RFC 1035 for more information on the fields of DNS msgs
     *
     *                                 1  1  1  1  1  1
     *   0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                      ID                       |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    QDCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ANCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    NSCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ARCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    if (buflen < 12 + domainlen + 2 + 4)
        return -1;

    uint16_t tmp;

    ID = pktlab_hton16(ID);
    memcpy(buf, &ID, sizeof(ID));

    tmp = pktlab_hton16(0 | ((uint16_t)RD) << 8);
    memcpy(buf + 2, &tmp, sizeof(tmp));

    tmp = pktlab_hton16(1);
    memcpy(buf + 4, &tmp, sizeof(tmp));

    tmp = 0;
    memcpy(buf + 6, &tmp, sizeof(tmp));
    memcpy(buf + 8, &tmp, sizeof(tmp));
    memcpy(buf + 10, &tmp, sizeof(tmp));

    uint8_t *ptr;

    ptr = domain2name(buf + 12, buflen - 12, domain, domainlen);
    if (ptr == NULL)
        return -1;

    tmp = pktlab_hton16(1);
    memcpy(ptr, &tmp, sizeof(tmp));
    memcpy(ptr + 2, &tmp, sizeof(tmp));

    return ptr + 4 - buf;
}

ssize_t create_icmp_filter(void **buf, uint_fast32_t *buflen) {
    static struct pktlab_ebpf_instr filter[] = EBPF_TRACEROUTE_RECV_FILTER();

    if (pktlab_encode_program(PKTLAB_EBPF, filter, sizeof(filter), buf,
                              buflen) != 0)
        print_err_exit(-1, "error: encode_ebpf_filter");

    return *buflen;
}

int get_resolved_addr(void *addr, size_t addrlen, uint16_t ID, uint8_t opcode,
                      const char *domain, size_t domainlen, const uint8_t *rsp,
                      size_t len) {
    assert(DNS_HDRLEN == sizeof(struct DNSHdr));
    assert(addrlen >= IP4_ADDRLEN);

    if (len < DNS_HDRLEN)
        errprint_ret(-1, "%s: DNS response too short (%d bytes)\n", __func__,
                     (int)len);

    const struct DNSHdr *dnshdr = (struct DNSHdr *)rsp;
    if (pktlab_ntoh16(dnshdr->ID) != ID || dnshdr->qr != 1 ||
        dnshdr->opcode != opcode || dnshdr->rcode != 0 ||
        pktlab_ntoh16(dnshdr->ancount) == 0)
        errprint_ret(-1, "%s: non-matching DNS response\n", __func__);

    // bypass query section, also getting byte offset to target qname
    const uint8_t *payload = (uint8_t *)(dnshdr + 1);
    uint_fast32_t nameptr = 0;
    const uint8_t *next, *name, *type, *class;
    for (uint_fast32_t i = 0; i < pktlab_ntoh16(dnshdr->qcount); ++i) {
        next = decode_question(payload, len - (payload - rsp), &name, &type,
                               &class);
        if (next == NULL)
            errprint_ret(-1,
                         "%s: decode DNS response question section failed\n",
                         __func__);

        if (nameptr == 0 &&
            cmp_domain_dnslabel(domain, domainlen, name, type - name))
            nameptr = payload - rsp;

        payload = next;
    }

    // locate target address
    const uint8_t *ans_sec_save = payload;
    int ret;
    const uint8_t *found_rdata;
    const uint8_t *remainder;
    size_t namelen = type - name;
    while (1) {
        assert(len >= payload - rsp);
        ret = search_dns_rr_section(payload, len - (payload - rsp),
                                    pktlab_ntoh16(dnshdr->ancount), name,
                                    namelen, nameptr, &found_rdata, &remainder);

        switch (ret) {
        case -1: // one final search in additional section for A record
            ret = search_dns_rr_section( // skip authority section
                remainder, len - (remainder - rsp),
                pktlab_ntoh16(dnshdr->nscount), NULL, 0, 0, &found_rdata,
                &remainder);
            assert(ret == -1);
            ret = search_dns_rr_section( // parse additional section
                remainder, len - (remainder - rsp),
                pktlab_ntoh16(dnshdr->adcount), name, namelen, nameptr,
                &found_rdata, &remainder);
            if (ret == 0) { // found target type A
                memcpy(addr, found_rdata, IP4_ADDRLEN);
                return 0;
            }

            errprint("%s: cannot find address for target domain\n", __func__);
            errprint("%s: raw DNS response:\n", __func__);
            err_print_pkt(rsp, len);
            return -1;
        case 0: // found target A record
            memcpy(addr, found_rdata, IP4_ADDRLEN);
            return 0;
        case 1: // found target CNAME record, continue further search
            if (remainder - found_rdata == namelen &&
                memcmp(name, found_rdata, namelen) == 0)
                errprint_ret(-1,
                             "%s: DNS response has self-referring CNAME record",
                             __func__);

            payload = ans_sec_save;
            name = found_rdata;
            namelen = remainder - found_rdata;
            nameptr = found_rdata - rsp;
            break;
        }
    }
}

// int check_special_ip(const uint8_t *addr) {
//     if (addr[0] == 127) {
//         return 0; // loopback
//     } else if (addr[0] == 169 && addr[1] == 254) {
//         return 1; // link local
//     } else if (addr[0] == 10 ||
//                (addr[0] == 172 && 16 <= addr[1] && addr[1] <= 31) ||
//                (addr[0] == 192 && addr[1] == 168)) {
//         return 2; // private
//     }

//     return 3; // otherwise
// }

const uint8_t *decode_question(const uint8_t *rr, size_t len,
                               const uint8_t **qname, const uint8_t **qtype,
                               const uint8_t **qclass) {
    if (len == 0)
        return NULL;

    *qname = rr;
    *qtype = memchr(rr, 0, len);
    if (*qtype == NULL)
        return NULL;
    ++(*qtype);

    if ((*qtype - rr + 2) > len)
        return NULL;

    *qclass = *qtype + 2;
    if ((*qclass - rr + 2) > len)
        return NULL;

    return *qclass + 2;
}

uint8_t *domain2name(uint8_t *buf, size_t buflen, const char *domain,
                     size_t domainlen) {
    if (buflen < domainlen + 1)
        return NULL;

    char copy[BUFSZ];
    memcpy(copy, domain, domainlen + 1);

    char *ptr;
    size_t off = 0;
    size_t toklen;
    for (ptr = strtok(copy, "."); ptr != NULL; ptr = strtok(NULL, ".")) {
        toklen = strlen(ptr);

        *(buf + off) = toklen;
        memcpy(buf + off + 1, ptr, toklen);
        off += toklen + 1;
    }

    *(buf + off) = '\0';
    return buf + off + 1;
}

int cmp_domain_dnslabel(const char *domain, size_t domainlen,
                        const uint8_t *dnslabel, size_t labellen) {
    uint8_t expected_labels[BUFSZ];
    uint8_t *next;

    next = domain2name(expected_labels, sizeof(expected_labels), domain,
                       domainlen);
    assert(next != NULL);

    return (next - expected_labels) == labellen &&
           memcmp(expected_labels, dnslabel, labellen) == 0;
}

const uint8_t *decode_rrecord(const uint8_t *rr, size_t len,
                              const uint8_t **name, int *compressed,
                              const uint8_t **type, const uint8_t **class,
                              uint32_t *ttl, uint16_t *rdlen,
                              const uint8_t **rdata) {
    if (len < 1)
        return NULL;
    *name = rr;

    if (*rr >= 192) {
        *compressed = 1;
        if (len < 2)
            return NULL;

        *type = rr + 2;
    } else {
        *compressed = 0;
        *type = (uint8_t *)memchr(rr, 0, len);
        if (*type == NULL)
            return NULL;
        ++(*type);
    }

    if ((*type - rr + 2) > len)
        return NULL;

    *class = *type + 2;
    if ((*class - rr + 2) > len)
        return NULL;

    if ((*class - rr + 2 + 4) > len)
        return NULL;
    *ttl = pktlab_get32n(*class + 2);

    if ((*class - rr + 2 + 4 + 2) > len)
        return NULL;
    *rdlen = pktlab_get16n(*class + 2 + 4);

    *rdata = *class + 2 + 4 + 2;
    if ((*rdata - rr + *rdlen) > len)
        return NULL;

    return *rdata + *rdlen;
}

int search_dns_rr_section(const uint8_t *sections, size_t secslen,
                          uint16_t rrcnt, const uint8_t *name, size_t namelen,
                          uint16_t pointer, const uint8_t **found_rdata,
                          const uint8_t **remainder) {
    const uint8_t *ptr;
    size_t remlen;
    const uint8_t *rrname;
    int compressed;
    const uint8_t *type;
    const uint8_t *class;
    uint32_t ttl;
    uint16_t rdlen;
    const uint8_t *rdata;
    const uint8_t *next;
    int found = 0;

    ptr = sections;
    remlen = secslen;
    for (uint_fast32_t i = 0; i < rrcnt; ++i) {
        next = decode_rrecord(ptr, remlen, &rrname, &compressed, &type, &class,
                              &ttl, &rdlen, &rdata);
        if (next == NULL)
            return -1;

        if (compressed) {
            if (pointer >= DNS_HDRLEN &&
                pointer == pktlab_get16n(rrname) - 0xc000)
                found = 1;
        } else {
            if (name != NULL && (type - rrname) == namelen &&
                memcmp(name, rrname, namelen) == 0)
                found = 1;
        }

        if (found) { // found RR for target address
            if (pktlab_get16n(class) !=
                RR_CLASS_IN) { // weird RR class, ignore and continue
                found = 0;
            } else {
                switch (pktlab_get16n(type)) {
                case RR_TYPE_A:
                    *found_rdata = rdata;
                    *remainder = next;
                    return 0;
                case RR_TYPE_CNAME:
                    *found_rdata = rdata;
                    *remainder = next;
                    return 1;
                default: // weird RR type, ignore and continue
                    found = 0;
                }
            }
        }

        assert(next - ptr <= remlen);
        remlen -= next - ptr;
        ptr = next;
    }

    return -1;
}

int is_icmp_timeexceed(const uint8_t *pkt, size_t len) {
    struct IPHdr *iphdr;
    struct ICMPHdr *icmphdr;

    iphdr = (struct IPHdr *)pkt;
    icmphdr = (struct ICMPHdr *)(pkt + iphdr->ihl * 4);

    if (len < IP_HDRLEN || len < pktlab_ntoh16(iphdr->len) ||
        iphdr->proto != ICMP_PROTO || icmphdr->type != ICMP_TIMEEXCEED_TYPE ||
        icmphdr->code != 0) // ignoring fragment reassembly error
        return 0;

    return 1;
}

int is_icmp_dstunreach(const uint8_t *pkt, size_t len) {
    struct IPHdr *iphdr;
    struct ICMPHdr *icmphdr;

    iphdr = (struct IPHdr *)pkt;
    icmphdr = (struct ICMPHdr *)(pkt + iphdr->ihl * 4);

    if (len < IP_HDRLEN || len < pktlab_ntoh16(iphdr->len) ||
        iphdr->proto != ICMP_PROTO || icmphdr->type != ICMP_DSTUNREACH_TYPE)
        return 0;

    return 1;
}

void get_icmp_info(uint8_t *errip, uint8_t *icmptype, uint8_t *icmpcode,
                   uint16_t *dport, const uint8_t *pkt, size_t len) {
    struct IPHdr *iphdr;
    struct ICMPHdr *icmphdr;
    struct IPHdr *probeiphdr;
    struct UDPHdr *udphdr;

    iphdr = (struct IPHdr *)pkt;
    memcpy(errip, &iphdr->src, IP4_ADDRLEN);

    icmphdr = (struct ICMPHdr *)(pkt + iphdr->ihl * 4);
    *icmptype = icmphdr->type;
    *icmpcode = icmphdr->code;

    probeiphdr = (struct IPHdr *)(icmphdr + 1);
    udphdr = (struct UDPHdr *)(((uint8_t *)probeiphdr) + probeiphdr->ihl * 4);
    *dport = pktlab_ntoh16(udphdr->dport);
}

uint16_t u16_rand(void) {
    if (RAND_MAX < UINT16_MAX)
        return (((uint16_t)rand() << 15) + (uint16_t)rand());
    else
        return rand();
}

uint16_t get_randport(uint16_t startport, uint16_t endport) {
    uint16_t ret = u16_rand();
    while (ret < startport || ret >= endport)
        ret = u16_rand();
    return ret;
}

void run_traceroute(struct pktif *pktif, uint8_t maxttl, uint16_t ipid,
                    uint_fast32_t waittime, const char *addr, size_t addrlen) {
    // Perform potential required DNS resolving
    int isdomain = 0;
    int rv;
    uint8_t targetip[IP4_ADDRLEN];
    uint8_t dnscnt;
    static const struct sockaddr_in sin_init = {.sin_family = AF_INET};
    struct sockaddr_in laddr;
    struct sockaddr_in dnsaddr;
    // dns query for passed domain
    // read the dns address configured on the endpoint

    if ((rv =
             pktif_mread_sync(pktif, PKTLAB_VMEMADDR_SYSPARAM_IP4DNSNO,
                              PKTLAB_VMEMADDR_SYSPARAM_IP4DNSNO_FL, &dnscnt))) {
        print_err_exit(-1, "Failed to read IPv4 DNS server number\n");
    }
    if (dnscnt == 0) {
        fprintf(stderr,
            "> No IPv4 DNS server configured on the endpoint, using 8.8.8.8 as fallback\n");
        dnsaddr.sin_family = AF_INET;
        dnsaddr.sin_port = htons(53);
        dnsaddr.sin_addr.s_addr = inet_addr("8.8.8.8");
    } else {
        if ((rv = pktif_mread_ipv4_dns_addr_sync(pktif, 0, &dnsaddr))) {
            print_err_exit(-1, "Failed to read DNS server addr\n");
        }
    }

    if (inet_pton(AF_INET, addr, targetip) != 1) {
        laddr = sin_init;
        if ((rv = pktif_connect_sync(pktif, DNS_SKTID, PKTLAB_UDP_PROTO,
                                     (struct sockaddr *)&laddr, NULL, BUFSZ,
                                     NULL))) {
            print_err_exit(
                -1, "Failed to open DNS socket on endpoint with status %d\n",
                rv);
        }

        if (process_dns(pktif, (struct sockaddr *)&dnsaddr, targetip,
                        sizeof(targetip), DNS_SKTID, DNS_QUERYID, 1, addr,
                        addrlen) < 0) {
            char buf[16];
            print_err_exit(
                -1, "Failed to resolve domain \"%s\" against %s:53\n", addr,
                inet_ntop(dnsaddr.sin_family, &dnsaddr.sin_addr.s_addr, buf,
                          sizeof(buf)));
        }
        isdomain = 1;
        if ((rv = pktif_close_sync(pktif, DNS_SKTID))) {
            print_err_exit(
                -1, "Failed to close DNS socket on endpoint with status %d\n",
                rv);
        }
    }
    char buf[16];
    fprintf(stderr, "> finished resolving domain, target ip is %s\n",
            inet_ntop(AF_INET, targetip, buf, 16));

    // Raw socket configuration
    laddr = sin_init;
    if ((rv = pktif_connect_sync(pktif, RAW_SKTID, PKTLAB_RAW_PROTO,
                                 (struct sockaddr *)&laddr, NULL, BUFSZ,
                                 NULL)) != 0) {
        print_err_exit(-1, "Raw socket open failed with status %d.\n", rv);
    }
    fprintf(stderr, "> raw socket opened\n");

    if ((rv = setup_icmp_cap(pktif)) != 0)
        print_err_exit(-1, "ICMP filter failed with status %d.\n", rv);
    fprintf(stderr, "> filter installed\n");

    // Send probe traffic
    uint8_t probe[BUFSZ];
    ssize_t probelen;
    uint8_t srcip[IP4_ADDRLEN];
    uint16_t dport = TRACERT_DPORT_START;
    pktlab_time_t icmp_send_tstp[UINT8_MAX * PROBENUM];
    int cnt = 0;

    const uint8_t
        probe_data[] = {0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
                        0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50, 0x51,
                        0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a,
                        0x5b, 0x5c, 0x5d, 0x5e, 0x5f}; // same as org traceroute

    if ((rv = pktif_mread_sync(pktif,
                               PKTLAB_VMEMADDR_SKTINFO +
                                   PKTLAB_VMEMADDR_SKTINFO_BLKLEN * RAW_SKTID +
                                   PKTLAB_VMEMADDR_SKTINFO_LADDR,
                               sizeof(srcip), srcip)) != 0)
        print_err_exit(-1, "Get src ip failed\n");
    for (uint16_t ttl = 1; ttl < maxttl + 1; ++ttl) {
        for (uint16_t j = 0; j < PROBENUM; ++j) {
            // create udp probe
            probelen = create_whole_pkt(
                probe, sizeof(probe), ipid, ttl, srcip, targetip,
                get_randport(TRACERT_SPORT_START, TRACERT_SPORT_END), dport,
                probe_data, sizeof(probe_data));
            assert(probelen >= 0);

            if ((rv = pktif_send_sync(
                     pktif, RAW_SKTID, probe, probelen, PKTLAB_RAW_PROTO, 0,
                     dport, NULL, &icmp_send_tstp[(ttl - 1) * PROBENUM + j])) !=
                probelen) {
                print_err_exit(-1, "pktif_send_sync failed with rv %d\n", rv);
            }
            ++cnt;

            assert(dport++ < UINT16_MAX); // die when dport == UINT16_MAX
        }
    }
    fprintf(stderr, "> %d packets sent\n", cnt);

    // wait for icmp response
    sleep(waittime);

    // get icmp response & timestamps
    pktlab_time_t icmp_recv_tstp[UINT8_MAX * PROBENUM];
    uint8_t errip_ls[UINT8_MAX * PROBENUM][IP4_ADDRLEN];
    uint8_t code_ls[UINT8_MAX * PROBENUM];
    int_fast32_t min_portunreach_dport;
    if (process_packets(pktif, icmp_recv_tstp, errip_ls, code_ls,
                        &min_portunreach_dport, maxttl * PROBENUM,
                        TRACERT_DPORT_START) < 0)
        print_err_exit(-1, "Process packets failed\n");
    fprintf(stderr, "> all response processed\n");

    // match and compute results as in traceroute algorithm
    double hop_delay_ls[UINT8_MAX][PROBENUM];
    uint8_t hop_errip_ls[UINT8_MAX][PROBENUM][IP4_ADDRLEN];
    uint8_t hop_code_ls[UINT8_MAX][PROBENUM];
    uint16_t hopcnt;
    comp_print_struct(icmp_send_tstp, icmp_recv_tstp, errip_ls, code_ls,
                      min_portunreach_dport, TRACERT_DPORT_START,
                      maxttl * PROBENUM, hop_delay_ls, hop_errip_ls,
                      hop_code_ls, &hopcnt);

    // print results in traceroute format
    print_traceroute(getenv("EPADDR"), srcip, (isdomain) ? addr : NULL, targetip,
                     (const uint8_t *) &dnsaddr.sin_addr.s_addr, maxttl, probelen,
                     hopcnt, hop_delay_ls, hop_errip_ls, hop_code_ls);

    // cleanup everything
    if ((rv = pktif_close_sync(pktif, RAW_SKTID))) {
        print_err_exit(
            -1, "Failed to close raw socket on endpoint with status %d\n", rv);
    }
    assert(pktif_teardown(pktif) == 0);
}